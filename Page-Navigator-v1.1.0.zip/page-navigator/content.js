(() => {
  'use strict';
  if (window.top !== window || globalThis.__pageNavigatorInstalled) return;
  globalThis.__pageNavigatorInstalled = true;

  const DEFAULTS = Object.freeze({ enabled: true, smooth: true, position: 'bottom-right', showProgress: true, avoidTyping: true });
  const HOST_ID = 'page-navigator-extension';
  const SETTINGS_KEY = 'pnSettings';
  const SPOT_PREFIX = 'pnSpot:';
  const MAX_HEADINGS = 1000;
  const MAX_MATCHES = 500;
  const MAX_SEARCH_CHARS = 2000000;
  const MAX_SEARCH_NODES = 30000;
  const ALL_MATCHES = 'page-navigator-found-7f';
  const ACTIVE_MATCH = 'page-navigator-active-7f';
  const MAX_SELECTION_CHARS = 200000;
  const SELECTION_CACHE_MS = 120000;
  let settings = { ...DEFAULTS };
  let disabledSites = [];
  let collapsed = false;
  let temporarilyHidden = false;
  let forcedVisible = false;
  let panelOpen = false;
  let pageIdentity = identity();
  let savedSpot = null;
  let manualRoot = null;
  let activeRoot = null;
  let recentRoot = null;
  let roots = [];
  let rootNumber = 0;
  const rootIds = new WeakMap();
  const headingButtons = new WeakMap();
  const history = [];
  let headingCache = [];
  let headingsDirty = true;
  let scanNeeded = true;
  let framePending = false;
  let refreshTimer;
  let toastTimer;
  let lastHeading = null;
  let lastHeadingDestination = null;
  let headingJumpAt = 0;
  let lastPercent = -1;
  let searchQuery = '';
  let searchMatches = [];
  let searchIndex = -1;
  let searchBusy = false;
  let searchLimited = false;
  let searchRoot = null;
  let searchGeneration = 0;
  let searchHasJumped = false;
  let searchInputTimer;
  let searchRefreshTimer;
  let searchEditToken = 0;
  let searchComposing = false;
  let pageSelection = null;
  let selectionTooLong = false;
  let copyingSelection = false;
  let companionBusy = false;

  const host = document.createElement('div');
  host.id = HOST_ID;
  host.setAttribute('data-page-navigator', '1');
  host.style.cssText = 'all:initial!important;position:fixed!important;inset:auto 16px 18px auto!important;z-index:2147483646!important;display:block!important;width:auto!important;height:auto!important;max-width:calc(100vw - 24px)!important;isolation:isolate!important;color-scheme:light!important;';
  const shadow = host.attachShadow({ mode: 'open' });
  const style = document.createElement('style');
  style.textContent = `
    :host{color-scheme:light}
    .pn-shell{font:14px/1.4 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#142f3b;direction:ltr;color-scheme:light;text-align:left}
    *,*::before,*::after{box-sizing:border-box} [hidden]{display:none!important}
    button,input,select{font:inherit} button{cursor:pointer} button:disabled{cursor:default;opacity:.45}
    button:focus-visible,input:focus-visible,select:focus-visible{outline:3px solid #0b766e;outline-offset:3px}
    button{border:0;color:inherit;background:transparent} svg{width:19px;height:19px;stroke:currentColor;stroke-width:1.8;fill:none;stroke-linecap:round;stroke-linejoin:round;flex-shrink:0;pointer-events:none}
    .rail{width:64px;padding:5px;border:1px solid #cbd9dd;border-radius:17px;background:#fff;box-shadow:0 7px 28px #122e3b24;display:flex;flex-direction:column;gap:3px;max-height:calc(100dvh - 36px);overflow-y:auto;scrollbar-width:thin}
    .rail .nav{width:52px;min-height:46px;border-radius:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;font-size:10px;font-weight:650;line-height:1.25}
    .nav:hover,.utility:hover,.mini:hover,.list-button:hover{background:#eaf3f3;color:#064f4a}
    .rail .nav.primary{background:#eef6f5}.rail .nav.primary:hover{background:#d9edea}
    .rail .nav.more[aria-expanded=true]{background:#0f6561;color:white}
    .mini{display:flex;align-items:center;justify-content:center;width:100%;height:24px;border-radius:8px}
    .mini svg{width:15px;height:15px}
    .progress{font-size:11px;color:#48616a;text-align:center;font-variant-numeric:tabular-nums;padding:5px 0 2px;border-top:1px solid #e3ebed}
    .compact{width:49px;height:49px;border-radius:16px;background:#fff;border:1px solid #cbd9dd;box-shadow:0 6px 24px #122e3b24;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:10px;font-weight:650;gap:1px}
    .compact:hover{background:#eef6f5}.compact svg{width:18px;height:18px}
    .panel{position:absolute;right:76px;bottom:0;width:310px;max-width:calc(100vw - 106px);max-height:calc(100dvh - 36px);overflow:auto;overscroll-behavior:contain;border:1px solid #cbd9dd;border-radius:17px;background:#fff;box-shadow:0 9px 36px #122e3b2b;padding:16px;scrollbar-width:thin}
    .left .panel{right:auto;left:76px}.top .panel{top:0;bottom:auto}
    .panel-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:13px}.panel-head h2{margin:0;font-size:16px;letter-spacing:-.3px;font-weight:750}.close{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center}
    .hint{font-size:11px;color:#526974;margin:6px 0 0;line-height:1.5}.section{margin-top:14px;padding-top:12px;border-top:1px solid #e3ebed}.section h3{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#526974;margin:0 0 8px;font-weight:750}
    .row{display:flex;align-items:center;gap:7px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}.utility{min-height:36px;padding:8px 10px;border:1px solid #d5e0e3;border-radius:9px;font-size:12px;font-weight:600;text-align:center;display:flex;align-items:center;justify-content:center;gap:6px}.utility svg{width:16px;height:16px}.full{width:100%}
    label{display:block;font-size:12px;font-weight:600;margin-bottom:6px}select,input[type=search]{width:100%;min-height:36px;padding:7px 9px;border:1px solid #bdcdd2;border-radius:8px;background:#fff;color:#142f3b;font-size:12px}input[type=range]{width:100%;height:24px;margin:0;accent-color:#0f6561;cursor:pointer}
    .range-label{display:flex;justify-content:space-between;align-items:center;margin:0 0 3px}.range-label output{font-size:12px;font-variant-numeric:tabular-nums;color:#0b645e}
    .search-box{position:relative}.search-box input{padding-right:33px}.search-clear{position:absolute;right:3px;top:3px;width:29px;height:29px;border-radius:6px;display:flex;align-items:center;justify-content:center}.search-clear svg{width:14px;height:14px}.search-tools{display:flex;align-items:center;gap:6px;margin:7px 0 0}.search-count{font-size:11px;color:#526974;flex:1;line-height:1.4}.search-tools .utility{min-width:35px;min-height:32px;padding:5px}.search-section{padding-bottom:12px;margin-bottom:12px;border-bottom:1px solid #e3ebed}
    .companion-section{padding:0 0 12px;margin:0 0 12px;border-bottom:1px solid #e3ebed}.companion-section h3{margin:0 0 7px;font-size:12px}.companion-section .copy-open{margin-top:7px;background:#eef6f5}.companion-note{font-size:10px;color:#526974;margin:5px 0 0;line-height:1.45}
    #pn-page-search::-webkit-search-cancel-button{display:none}
    .percent-ticks{display:flex;justify-content:space-between;font-size:10px;color:#526974;margin:0 0 6px}
    .outline{margin-top:8px;max-height:185px;overflow:auto;overscroll-behavior:contain;list-style:none;padding:0;scrollbar-width:thin}.outline li{margin:0;padding:0}.list-button{display:block;text-align:left;width:100%;font-size:12px;border-radius:7px;padding:8px 6px;line-height:1.4;overflow-wrap:anywhere}.level{font-size:9px;border:1px solid #c3d3d7;border-radius:4px;padding:1px 3px;color:#526974;margin-right:6px;white-space:nowrap}
    .empty{padding:8px 2px;margin:0;font-size:12px;color:#526974}.link{font-size:11px;text-decoration:underline;text-underline-offset:2px;padding:4px;color:#526974}.footer{display:flex;justify-content:space-between;align-items:center;margin-top:10px}
    .toast{position:absolute;right:76px;bottom:0;min-width:160px;max-width:min(300px,calc(100vw - 110px));padding:10px 13px;border-radius:11px;background:#153843;color:#fff;font-size:12px;box-shadow:0 5px 20px #122e3b20;line-height:1.45;pointer-events:none}.left .toast{right:auto;left:76px}.top .toast{top:0;bottom:auto}.panel:not([hidden])~.toast{bottom:auto;top:-51px}.top .panel:not([hidden])~.toast{top:auto;bottom:-51px}
    .sr{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}
    @media(max-width:420px){.panel{padding:12px;width:280px;max-width:calc(100vw - 100px)}.utility{padding:7px 4px;font-size:11px}.panel-head h2{font-size:14px}}
    @media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important}}
    @media(forced-colors:active){.rail,.panel,.compact,.toast{border:1px solid CanvasText}.utility,.nav{border:1px solid ButtonText}.nav.primary{background:ButtonFace}.progress{color:CanvasText}}
    @media print{:host{display:none!important}}
  `;
  shadow.append(style);
  const icons = {
    top: '<path d="M5 4h14M7 13l5-5 5 5M12 8v12"/>',
    middle: '<path d="M5 12h14M8 4l4 4 4-4M8 20l4-4 4 4"/>',
    end: '<path d="M5 20h14M7 11l5 5 5-5M12 4v12"/>',
    up: '<path d="m6 14 6-6 6 6"/>',
    down: '<path d="m6 10 6 6 6-6"/>',
    back: '<path d="m9 6-5 5 5 5M4 11h10a5 5 0 0 1 0 10"/>',
    mark: '<path d="M6 4h12v17l-6-4-6 4Z"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
    chat: '<path d="M20 11.5a8 8 0 0 1-8 8 8.8 8.8 0 0 1-3.5-.7L4 20l1.2-4.4A8 8 0 1 1 20 11.5Z"/><path d="M8 10h8M8 14h5"/>',
    copy: '<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h3"/>',
    more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
    fold: '<path d="m9 6 6 6-6 6"/>',
    close: '<path d="m6 6 12 12M6 18 18 6"/>',
    nav: '<path d="m8 6 4-4 4 4M12 2v20m-4-4 4 4 4-4M4 12h16"/>'
  };
  const icon = (name) => `<svg viewBox="0 0 24 24" aria-hidden="true">${icons[name] || icons.nav}</svg>`;
  const shell = document.createElement('div');
  shell.innerHTML = `
    <div class="rail" role="group" aria-label="Page navigation">
      <button class="mini" type="button" data-action="collapse" aria-label="Collapse page navigator" title="Collapse to a small button">${icon('fold')}</button>
      <button class="nav primary" type="button" data-action="top" title="Go to the top">${icon('top')}<span>Top</span></button>
      <button class="nav primary" type="button" data-action="middle" title="Go halfway through the scrolling area">${icon('middle')}<span>Middle</span></button>
      <button class="nav primary" type="button" data-action="end" title="Go to the end of loaded content">${icon('end')}<span>End</span></button>
      <button class="nav" type="button" data-action="open-search" title="Search page text as you type">${icon('search')}<span>Search</span></button>
      <button class="nav" type="button" data-action="open-chatgpt" data-companion title="Open or focus a separate ChatGPT window">${icon('chat')}<span>ChatGPT</span></button>
      <button class="nav more" type="button" data-action="more" aria-controls="pn-panel" aria-expanded="false" title="More navigation options">${icon('more')}<span>More</span></button>
      <div class="progress" aria-label="Scroll position"><span id="pn-percent">0%</span></div>
    </div>
    <button class="compact" type="button" data-action="expand" aria-label="Expand page navigator" title="Expand page navigator" hidden>${icon('nav')}<span id="pn-compact-percent">0%</span></button>
    <section class="panel" id="pn-panel" aria-label="More page navigation options" hidden>
      <div class="panel-head"><h2>Page Navigator</h2><button class="close utility" type="button" data-action="close-panel" aria-label="Close more options">${icon('close')}</button></div>
      <div class="search-section">
        <label for="pn-page-search">Search this page</label>
        <div class="search-box"><input type="search" id="pn-page-search" placeholder="Start typing to find text…" maxlength="200" autocomplete="off" spellcheck="false" aria-describedby="pn-search-count pn-search-help"><button class="search-clear" type="button" data-action="clear-search" aria-label="Clear page search" title="Clear search" hidden>${icon('close')}</button></div>
        <div class="search-tools"><span class="search-count" id="pn-search-count" role="status" aria-live="polite" aria-atomic="true">Type to search. No Go button needed.</span><button class="utility" type="button" data-action="previous-match" aria-label="Previous search match" title="Previous match (Shift+Enter)" disabled>${icon('up')}</button><button class="utility" type="button" data-action="next-match" aria-label="Next search match" title="Next match (Enter)" disabled>${icon('down')}</button></div>
        <p class="hint" id="pn-search-help">Enter: next match · Shift+Enter: previous. Searches the selected scrolling area.</p>
      </div>
      <div class="companion-section">
        <h3>ChatGPT companion</h3>
        <div class="grid"><button class="utility" type="button" data-action="open-chatgpt" data-companion>${icon('chat')}<span>Open ChatGPT</span></button><button class="utility" type="button" data-action="copy-selection" data-companion>${icon('copy')}<span>Copy selected text</span></button></div>
        <button class="utility full copy-open" type="button" data-action="copy-open-chatgpt" data-companion>Copy &amp; open ChatGPT</button>
        <p class="hint" id="pn-selection-hint">Highlight page text to copy it.</p>
        <p class="companion-note">Paste in ChatGPT when ready. Messages are not sent automatically.</p>
      </div>
      <button class="utility full" type="button" data-action="previous-spot" title="Return to the position before your last jump">${icon('back')}<span>Previous position</span></button>
      <div class="grid" style="margin-top:7px">
        <button class="utility" type="button" data-action="page-up">${icon('up')}<span>Screen up</span></button>
        <button class="utility" type="button" data-action="page-down">${icon('down')}<span>Screen down</span></button>
      </div>
      <div class="section">
        <div class="range-label"><label for="pn-range">Jump to position</label><output id="pn-range-value" for="pn-range">0%</output></div>
        <input id="pn-range" type="range" min="0" max="100" step="1" value="0" aria-label="Position in scrolling area" aria-valuetext="0 percent">
        <div class="percent-ticks" aria-hidden="true"><span>Top</span><span>Middle</span><span>End</span></div>
        <div class="row"><button class="utility full" type="button" data-action="percent" data-value="25">25%</button><button class="utility full" type="button" data-action="percent" data-value="75">75%</button></div>
      </div>
      <div class="section">
        <h3>Reading spot</h3>
        <div class="grid"><button class="utility" type="button" data-action="save-spot">${icon('mark')}<span>Save spot</span></button><button class="utility" type="button" data-action="restore-spot">Return to spot</button></div>
        <div class="footer"><span class="hint" id="pn-saved-label">No saved spot on this page.</span><button class="link" type="button" data-action="clear-spot" hidden>Clear</button></div>
      </div>
      <div class="section">
        <h3>Page headings</h3>
        <div class="grid"><button class="utility" type="button" data-action="previous-heading">${icon('up')}<span>Previous</span></button><button class="utility" type="button" data-action="next-heading">${icon('down')}<span>Next</span></button></div>
        <label class="sr" for="pn-search">Filter page headings</label><input type="search" id="pn-search" placeholder="Find a heading…" autocomplete="off" style="margin-top:8px">
        <ul class="outline" id="pn-outline" aria-label="Page headings"></ul>
        <p class="hint" id="pn-heading-count"></p>
      </div>
      <div class="section"><label for="pn-area">Scrolling area</label><select id="pn-area"></select><p class="hint">Automatic follows the main page or a large panel you scroll.</p></div>
      <div class="footer"><button class="link" type="button" data-action="switch-side">Move to other side</button><button class="link" type="button" data-action="hide">Hide on this page</button></div>
      <p class="hint">Reopen from the extension icon. On infinite pages, End goes to the bottom of content loaded so far.</p>
    </section>
    <div class="toast" role="status" aria-live="polite" aria-atomic="true" hidden></div>
  `;
  shadow.append(shell);
  const $ = (selector) => shadow.querySelector(selector);
  const $$ = (selector) => [...shadow.querySelectorAll(selector)];
  const rail = $('.rail');
  const panel = $('.panel');
  const moreButton = $('[data-action="more"]');
  const range = $('#pn-range');
  const headingList = $('#pn-outline');
  const areaSelect = $('#pn-area');
  const pageSearchInput = $('#pn-page-search');

  function identity() {
    // Ordinary anchors belong to the same document. Hash-router routes do not.
    const url = new URL(location.href);
    if (!/^#!?\//.test(url.hash)) url.hash = '';
    return url.href;
  }
  function pageRoot() { return document.scrollingElement || document.documentElement; }
  function isPage(el) { return el === pageRoot(); }
  function isOwn(el) { return el === host || (el && shadow.contains(el)); }
  function rectFor(el) {
    return isPage(el) ? { top: 0, left: 0, right: innerWidth, bottom: innerHeight, width: innerWidth, height: innerHeight } : el.getBoundingClientRect();
  }
  function metrics(el) {
    const view = isPage(el)
      ? (document.compatMode === 'BackCompat' ? innerHeight : document.documentElement.clientHeight || innerHeight)
      : el.clientHeight;
    const max = Math.max(0, el.scrollHeight - view);
    return { top: Math.max(0, Math.min(max, el.scrollTop)), max, view, percent: max ? Math.round(Math.max(0, Math.min(1, el.scrollTop / max)) * 100) : 0 };
  }
  function visibleArea(el) {
    const r = rectFor(el);
    return Math.max(0, Math.min(innerWidth, r.right) - Math.max(0, r.left)) * Math.max(0, Math.min(innerHeight, r.bottom) - Math.max(0, r.top));
  }
  function scrollable(el, small = false) {
    if (!(el instanceof Element) || !el.isConnected || isOwn(el)) return false;
    if (isPage(el)) return metrics(el).max > 2;
    const r = el.getBoundingClientRect();
    if (r.width < (small ? 120 : 220) || r.height < (small ? 100 : 160) || visibleArea(el) < 10000) return false;
    const s = getComputedStyle(el);
    return s.visibility !== 'hidden' && s.display !== 'none' && /(auto|scroll|overlay)/.test(s.overflowY) && el.scrollHeight - el.clientHeight > 2;
  }
  function areaId(el) {
    if (isPage(el)) return 'document';
    if (!rootIds.has(el)) rootIds.set(el, `area-${++rootNumber}`);
    return rootIds.get(el);
  }
  function rootLabel(el) {
    if (isPage(el)) return 'Whole page';
    const named = el.getAttribute('aria-label');
    if (named) return named.slice(0, 55);
    if (el.matches('main,[role="main"]') || el.querySelector('main,[role="main"]')) return 'Main content panel';
    if (el.matches('article') || el.querySelector('article')) return 'Article or conversation panel';
    if (el.matches('nav,aside,[role="navigation"]')) return 'Sidebar panel';
    return `Scrollable panel ${areaId(el).replace('area-', '')}`;
  }
  function discoverRoots() {
    const found = new Set([pageRoot()]);
    const walk = (start) => {
      let el = start;
      for (let depth = 0; el && depth < 24; depth++, el = el.parentElement) {
        if (scrollable(el)) found.add(el);
      }
    };
    [...document.querySelectorAll('main,[role="main"],article')].slice(0, 40).forEach(walk);
    for (const x of [.22, .5, .78]) {
      for (const y of [.25, .5, .75]) walk(document.elementFromPoint(Math.round(innerWidth * x), Math.round(innerHeight * y)));
    }
    if (manualRoot && scrollable(manualRoot, true)) found.add(manualRoot);
    if (recentRoot && scrollable(recentRoot)) found.add(recentRoot);
    roots = [...found];
    scanNeeded = false;
    if (manualRoot && (!manualRoot.isConnected || (!isPage(manualRoot) && !scrollable(manualRoot, true)))) manualRoot = null;
    return roots;
  }
  function resolveRoot(force = false) {
    if (force || scanNeeded || !activeRoot?.isConnected) discoverRoots();
    let chosen;
    if (manualRoot?.isConnected) chosen = manualRoot;
    else if (recentRoot && scrollable(recentRoot) && visibleArea(recentRoot) >= innerWidth * innerHeight * .25) chosen = recentRoot;
    else {
      const doc = pageRoot();
      if (metrics(doc).max > 8) chosen = doc;
      else {
        chosen = roots.filter(el => !isPage(el) && scrollable(el)).sort((a, b) => {
          const score = el => visibleArea(el) * (el.matches('main,[role="main"]') || el.querySelector('main,[role="main"]') ? 1.2 : 1);
          return score(b) - score(a);
        })[0] || doc;
      }
    }
    if (chosen !== activeRoot) {
      activeRoot = chosen;
      headingsDirty = true;
      lastHeading = null;
      lastHeadingDestination = null;
      lastPercent = -1;
      if (searchQuery && searchRoot && searchRoot !== chosen) {
        searchGeneration++;
        searchBusy = false;
        searchMatches = [];
        searchIndex = -1;
        paintSearch();
        scheduleSearchRefresh();
      }
    }
    return activeRoot;
  }
  function enabled() { return settings.enabled && !disabledSites.includes(location.hostname); }
  function permittedVisibility() {
    const m = metrics(resolveRoot());
    return enabled() && !temporarilyHidden && (forcedVisible || m.max > 80 || panelOpen);
  }
  function visible(el) {
    if (!el.isConnected || !el.getClientRects().length || el.closest('[hidden],[inert],[aria-hidden="true"]')) return false;
    const s = getComputedStyle(el);
    return s.visibility !== 'hidden' && s.visibility !== 'collapse' && s.display !== 'none';
  }
  function nearestScrollRoot(el) {
    for (let n = el.parentElement; n && n !== document.body; n = n.parentElement) {
      if (scrollable(n, true)) return n;
    }
    return pageRoot();
  }
  function headings() {
    const root = resolveRoot();
    if (!headingsDirty) return headingCache;
    const scope = isPage(root) ? document : root;
    const candidates = [...scope.querySelectorAll('h1,h2,h3,h4,h5,h6,[role="heading"]')];
    headingCache = [];
    for (const el of candidates) {
      if (headingCache.length >= MAX_HEADINGS) break;
      const label = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (!label || !visible(el) || nearestScrollRoot(el) !== root) continue;
      const level = /^H[1-6]$/.test(el.tagName) ? Number(el.tagName[1]) : Math.max(1, Math.min(6, Number(el.getAttribute('aria-level')) || 2));
      headingCache.push({ el, label: label.slice(0, 240), level });
    }
    headingCache.sort((a, b) => a.el.getBoundingClientRect().top - b.el.getBoundingClientRect().top);
    headingsDirty = false;
    return headingCache;
  }
  function stickyOffset(root) {
    const r = rectFor(root);
    const x = Math.max(1, Math.min(innerWidth - 2, r.left + r.width * .5));
    let limit = Math.max(0, r.top) + 8;
    const start = Math.max(0, r.top);
    // Probe the top strip, not the whole document, to account for fixed headers.
    for (const delta of [2, 24, 55, 90, 130]) {
      const y = start + delta;
      if (y >= Math.min(innerHeight, r.bottom)) continue;
      for (const hit of document.elementsFromPoint(x, y).slice(0, 6)) {
        if (isOwn(hit) || hit === root || hit === document.body || hit === document.documentElement) continue;
        const s = getComputedStyle(hit);
        const box = hit.getBoundingClientRect();
        if ((s.position === 'fixed' || s.position === 'sticky') && box.top <= limit + 18 && box.height < metrics(root).view * .35 && box.width > r.width * .25) limit = Math.max(limit, box.bottom + 8);
      }
    }
    return Math.max(12, Math.min(metrics(root).view * .35, limit - r.top + 10));
  }
  function headingTop(item, root) {
    return metrics(root).top + item.el.getBoundingClientRect().top - rectFor(root).top - (isPage(root) ? 0 : root.clientTop);
  }
  function announce(message) {
    const toast = $('.toast');
    clearTimeout(toastTimer);
    toast.textContent = message;
    toast.hidden = false;
    toastTimer = setTimeout(() => { toast.hidden = true; }, 3200);
  }
  function showPanel(open, focus = false) {
    panelOpen = open;
    panel.hidden = !open;
    moreButton.setAttribute('aria-expanded', String(open));
    if (open) {
      collapsed = false;
      temporarilyHidden = false;
      forcedVisible = true;
      discoverRoots();
      headingsDirty = true;
      renderAreas();
      renderHeadings();
    }
    render();
    if (focus) (open ? $('[data-action="close-panel"]') : moreButton).focus({ preventScroll: true });
  }
  function renderAreas() {
    const current = manualRoot ? areaId(manualRoot) : 'auto';
    areaSelect.replaceChildren();
    const auto = document.createElement('option');
    auto.value = 'auto';
    auto.textContent = `Automatic — ${rootLabel(resolveRoot())}`;
    areaSelect.append(auto);
    roots.forEach(root => {
      const opt = document.createElement('option');
      opt.value = areaId(root);
      opt.textContent = rootLabel(root);
      areaSelect.append(opt);
    });
    areaSelect.value = current;
  }
  function renderHeadings() {
    const items = headings();
    const filter = $('#pn-search').value.toLocaleLowerCase().trim();
    const focusedHeading = headingButtons.get(shadow.activeElement);
    const listScroll = headingList.scrollTop;
    let restoredButton = null;
    headingList.replaceChildren();
    const matching = items.filter(h => h.label.toLocaleLowerCase().includes(filter));
    matching.forEach(item => {
      const li = document.createElement('li');
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'list-button';
      headingButtons.set(button, item.el);
      if (item.el === focusedHeading) restoredButton = button;
      button.style.paddingLeft = `${6 + Math.min(item.level - 1, 3) * 10}px`;
      const level = document.createElement('span');
      level.className = 'level';
      level.textContent = `H${item.level}`;
      level.setAttribute('aria-hidden', 'true');
      button.append(level, document.createTextNode(item.label));
      button.addEventListener('click', () => { jumpHeading(item, 'outline'); });
      li.append(button);
      headingList.append(li);
    });
    if (!matching.length) {
      const li = document.createElement('li');
      li.className = 'empty';
      li.textContent = items.length ? 'No matching headings.' : 'No visible headings in this scrolling area.';
      headingList.append(li);
    }
    $('#pn-heading-count').textContent = `${matching.length} of ${items.length}${items.length === MAX_HEADINGS ? '+' : ''} headings`;
    headingList.scrollTop = listScroll;
    if (focusedHeading) (restoredButton || $('#pn-search')).focus({ preventScroll: true });
    $('[data-action="previous-heading"]').disabled = !items.length;
    $('[data-action="next-heading"]').disabled = !items.length;
  }
  function render() {
    const root = resolveRoot();
    const m = metrics(root);
    host.style.setProperty('display', permittedVisibility() ? 'block' : 'none', 'important');
    host.style.setProperty('inset', 'auto', 'important');
    const left = settings.position.endsWith('left');
    const top = settings.position.startsWith('top');
    host.style.setProperty(left ? 'left' : 'right', '16px', 'important');
    host.style.setProperty(top ? 'top' : 'bottom', '18px', 'important');
    shell.className = `pn-shell ${left ? 'left' : ''} ${top ? 'top' : ''}`;
    rail.hidden = collapsed;
    $('.compact').hidden = !collapsed;
    panel.hidden = !panelOpen || collapsed;
    $('.progress').hidden = !settings.showProgress;
    $('#pn-compact-percent').hidden = !settings.showProgress;
    if (m.percent !== lastPercent) {
      lastPercent = m.percent;
      $('#pn-percent').textContent = `${m.percent}%`;
      $('#pn-compact-percent').textContent = `${m.percent}%`;
      if (shadow.activeElement !== range) {
        range.value = String(m.percent);
        $('#pn-range-value').textContent = `${m.percent}%`;
        range.setAttribute('aria-valuetext', `${m.percent} percent`);
      }
    }
    $$('[data-action="previous-spot"]').forEach(b => { b.disabled = !history.some(h => h.root.isConnected); });
    $$('[data-action="restore-spot"]').forEach(b => { b.disabled = !savedSpot; });
    $('[data-action="clear-spot"]').hidden = !savedSpot;
    $('#pn-saved-label').textContent = savedSpot ? `Saved at ${savedSpot.percent}% on this page.` : 'No saved spot on this page.';
    $('[data-action="save-spot"] span').textContent = savedSpot ? 'Replace spot' : 'Save spot';
    $$('[data-action="top"],[data-action="middle"],[data-action="end"],[data-action="page-up"],[data-action="page-down"]').forEach(b => { b.disabled = m.max < 1; });
    if (panelOpen && headingsDirty) renderHeadings();
    renderSearch();
    renderSelectionHint();
  }
  function queueRender() {
    if (framePending) return;
    framePending = true;
    requestAnimationFrame(() => { framePending = false; render(); });
  }
  function refreshSoon() {
    // Throttle instead of debouncing: streamed content must not postpone updates forever.
    if (refreshTimer) return;
    refreshTimer = setTimeout(async () => {
      refreshTimer = null;
      await checkRoute();
      scanNeeded = true;
      headingsDirty = true;
      render();
      if (panelOpen) renderAreas();
      scheduleSearchRefresh();
    }, 250);
  }
  function remember(root) {
    const top = metrics(root).top;
    const last = history[history.length - 1];
    if (!last || last.root !== root || Math.abs(last.top - top) > 4) {
      history.push({ root, top, manual: Boolean(manualRoot) });
      if (history.length > 30) history.shift();
    }
  }
  function scroll(root, target, saveHistory = true) {
    const m = metrics(root);
    const y = Math.max(0, Math.min(m.max, Number(target) || 0));
    if (Math.abs(m.top - y) < 1) return;
    if (saveHistory) remember(root);
    const motion = settings.smooth && !matchMedia('(prefers-reduced-motion: reduce)').matches;
    const opts = { top: y, left: root.scrollLeft, behavior: motion ? 'smooth' : 'instant' };
    if (isPage(root)) window.scrollTo(opts); else root.scrollTo(opts);
    queueRender();
  }
  function jumpHeading(item, source) {
    if (!item?.el?.isConnected) { headingsDirty = true; announce('That heading changed. Open the heading list again.'); return; }
    const root = resolveRoot(true);
    lastHeading = item.el;
    lastHeadingDestination = Math.max(0, Math.min(metrics(root).max, headingTop(item, root) - stickyOffset(root)));
    headingJumpAt = Date.now();
    scroll(root, lastHeadingDestination);
    announce(item.label.slice(0, 100));
    // Explicit keyboard heading navigation also moves the accessibility focus.
    if (source === 'command' || source === 'outline') {
      const hadTabindex = item.el.hasAttribute('tabindex');
      if (!hadTabindex) item.el.setAttribute('tabindex', '-1');
      item.el.focus({ preventScroll: true });
      if (!hadTabindex) item.el.addEventListener('blur', () => item.el.removeAttribute('tabindex'), { once: true });
      if (source === 'outline') showPanel(false);
    }
  }
  function navigateHeading(direction, source) {
    const root = resolveRoot(true);
    headingsDirty = true;
    const list = headings();
    if (!list.length) { announce('This scrolling area has no visible headings.'); return; }
    const threshold = metrics(root).top + stickyOffset(root);
    // Several headings can share the clamped bottom position. Keep their order,
    // including quick repeated commands while a smooth jump is still in motion.
    const continuingJump = lastHeadingDestination !== null &&
      (Math.abs(metrics(root).top - lastHeadingDestination) < 8 || Date.now() - headingJumpAt < 1000);
    const currentIndex = continuingJump ? list.findIndex(h => h.el === lastHeading) : -1;
    let item;
    if (currentIndex >= 0) item = list[currentIndex + direction];
    else if (direction > 0) item = list.find(h => headingTop(h, root) > threshold + 8);
    else item = [...list].reverse().find(h => headingTop(h, root) < threshold - 8);
    if (item) jumpHeading(item, source);
    else announce(direction > 0 ? 'No more headings below this position.' : 'No more headings above this position.');
  }
  function selectorFor(el) {
    if (isPage(el)) return null;
    if (el.id) return `#${CSS.escape(el.id)}`;
    const parts = [];
    for (let n = el; n && n !== document.body && parts.length < 8; n = n.parentElement) {
      if (n.id) { parts.unshift(`#${CSS.escape(n.id)}`); break; }
      let part = n.localName;
      const siblings = n.parentElement ? [...n.parentElement.children].filter(s => s.localName === n.localName) : [];
      if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(n) + 1})`;
      parts.unshift(part);
    }
    return parts.join(' > ');
  }
  async function saveReadingSpot() {
    const requestedPage = pageIdentity;
    const root = resolveRoot(true);
    const m = metrics(root);
    const anchor = [...headings()].reverse().find(h => headingTop(h, root) <= m.top + stickyOffset(root) + 5);
    const record = {
      version: 1, page: requestedPage, top: m.top, max: m.max, percent: m.percent,
      root: selectorFor(root), rootIsPage: isPage(root), savedAt: Date.now(),
      anchor: anchor ? { id: anchor.el.id || '', label: anchor.label, delta: headingTop(anchor, root) - m.top } : null
    };
    try {
      await chrome.storage.local.set({ [SPOT_PREFIX + requestedPage]: record });
      if (requestedPage === pageIdentity && requestedPage === identity()) {
        savedSpot = record;
        announce(`Reading spot saved at ${m.percent}%.`);
        render();
      }
      return null;
    } catch {
      const error = 'Could not save the spot. Reload this page and try again.';
      announce(error);
      return { error };
    }
  }
  function validSpot(value) {
    return value && value.version === 1 && value.page === pageIdentity && Number.isFinite(value.top) && Number.isFinite(value.max) ? value : null;
  }
  async function loadSpot() {
    const requested = pageIdentity;
    try {
      const stored = await chrome.storage.local.get(SPOT_PREFIX + requested);
      if (requested === pageIdentity && requested === identity()) savedSpot = validSpot(stored[SPOT_PREFIX + requested]);
    } catch { if (requested === pageIdentity) savedSpot = null; }
    render();
  }
  function restoreReadingSpot() {
    if (!savedSpot) { announce('Save a spot on this page first.'); return; }
    let root = resolveRoot(true);
    if (savedSpot.rootIsPage) root = pageRoot();
    else if (savedSpot.root) {
      try {
        const candidate = document.querySelector(savedSpot.root);
        if (candidate && scrollable(candidate, true)) root = candidate;
      } catch { /* A page may have changed its structure since the spot was saved. */ }
    }
    manualRoot = root;
    resolveRoot();
    headingsDirty = true;
    let anchor = null;
    if (savedSpot.anchor) {
      const list = headings();
      anchor = list.find(h => savedSpot.anchor.id && h.el.id === savedSpot.anchor.id) || list.find(h => h.label === savedSpot.anchor.label);
    }
    const m = metrics(root);
    const y = anchor ? headingTop(anchor, root) - savedSpot.anchor.delta : (Math.abs(m.max - savedSpot.max) < 80 ? savedSpot.top : (savedSpot.max ? savedSpot.top / savedSpot.max * m.max : 0));
    scroll(root, y);
    announce('Returned to your saved reading spot.');
    if (panelOpen) renderAreas();
  }

  function searchPattern(query) {
    // Match literal characters, and let ordinary spaces match rendered line breaks.
    // RegExp indexes stay in the original UTF-16 text, unlike lowercased buffers.
    const escape = text => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(query.trim().split(/\s+/u).map(escape).join('\\s+'), 'giu');
  }
  function searchLabel() {
    if (!searchQuery) return 'Type to search. No Go button needed.';
    if (searchBusy) return 'Searching…';
    if (!searchMatches.length) return searchLimited ? 'No matches in scanned text · scan limit reached' : 'No matches';
    return `${searchIndex + 1} of ${searchMatches.length}${searchLimited ? ' · limited' : ''}`;
  }
  function renderSearch() {
    if (shadow.activeElement !== pageSearchInput && pageSearchInput.value !== searchQuery) pageSearchInput.value = searchQuery;
    const label = searchLabel();
    if ($('#pn-search-count').textContent !== label) $('#pn-search-count').textContent = label;
    $$('[data-action="previous-match"],[data-action="next-match"]').forEach(button => { button.disabled = searchBusy || !searchMatches.length; });
    $('[data-action="clear-search"]').hidden = !pageSearchInput.value && !searchQuery;
  }
  function paintSearch() {
    if (typeof Highlight === 'undefined' || !globalThis.CSS?.highlights) return;
    try {
      // Never clear the registry: the page may have its own highlights.
      CSS.highlights.delete(ALL_MATCHES);
      CSS.highlights.delete(ACTIVE_MATCH);
      if (searchMatches.length) {
        CSS.highlights.set(ALL_MATCHES, new Highlight(...searchMatches.map(match => match.range)));
        if (searchIndex >= 0 && searchMatches[searchIndex]) {
          const active = new Highlight(searchMatches[searchIndex].range);
          active.priority = 1;
          CSS.highlights.set(ACTIVE_MATCH, active);
        }
      }
    } catch { /* Position/count navigation remains available if a page invalidates a range. */ }
  }
  function clearSearch() {
    searchEditToken++;
    searchGeneration++;
    clearTimeout(searchInputTimer);
    clearTimeout(searchRefreshTimer);
    searchInputTimer = searchRefreshTimer = null;
    searchQuery = '';
    searchMatches = [];
    searchIndex = -1;
    searchBusy = searchLimited = searchHasJumped = false;
    searchComposing = false;
    searchRoot = null;
    pageSearchInput.value = '';
    paintSearch();
    renderSearch();
  }
  function blockForSearch(node, scope, styleCache) {
    for (let el = node.parentElement; el && el !== scope; el = el.parentElement) {
      let style = styleCache.get(el);
      if (!style) { style = getComputedStyle(el); styleCache.set(el, style); }
      if (!['inline', 'contents', 'ruby', 'ruby-base', 'ruby-text'].includes(style.display)) return el;
    }
    return scope;
  }
  function searchElementExcluded(el, root, styleCache) {
    if (el === host || /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|TEXTAREA|INPUT|SELECT|OPTION|IFRAME|OBJECT|EMBED|CANVAS|SVG)$/.test(el.tagName)) return true;
    if (el.isContentEditable || el.hasAttribute('hidden') || el.hasAttribute('inert') || el.getAttribute('aria-hidden') === 'true') return true;
    let style = styleCache.get(el);
    if (!style) { style = getComputedStyle(el); styleCache.set(el, style); }
    if (style.display === 'none' || ['hidden', 'collapse'].includes(style.visibility) || style.contentVisibility === 'hidden' || style.opacity === '0') return true;
    return el !== root && !isPage(el) && scrollable(el, true);
  }
  function rangesForSearchRun(text, segments, pattern, available) {
    const result = [];
    pattern.lastIndex = 0;
    let match;
    while ((match = pattern.exec(text)) && result.length < available) {
      if (!match[0].length) break;
      const first = match.index;
      const last = first + match[0].length;
      const start = segments.find(segment => segment.node && first >= segment.start && first < segment.end);
      const end = segments.find(segment => segment.node && last > segment.start && last <= segment.end);
      if (!start || !end || !start.node.isConnected || !end.node.isConnected) continue;
      try {
        const range = document.createRange();
        range.setStart(start.node, first - start.start);
        range.setEnd(end.node, last - end.start);
        if (![...range.getClientRects()].some(rect => rect.width > 0 && rect.height > 0)) continue;
        result.push({ range });
      } catch { /* Streamed content may remove a node between traversal and range creation. */ }
    }
    return result;
  }
  async function collectSearchMatches(root, query, generation) {
    const scope = isPage(root) ? document.body || document.documentElement : root;
    const styleCache = new WeakMap();
    const pattern = searchPattern(query);
    const matches = [];
    let inspected = 0;
    const walker = document.createTreeWalker(scope, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        // Return one final node when the budget expires so nextNode can yield control.
        if (++inspected > MAX_SEARCH_NODES) return NodeFilter.FILTER_ACCEPT;
        if (node.nodeType === Node.ELEMENT_NODE && searchElementExcluded(node, root, styleCache)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    let block = null;
    let parts = [];
    let segments = [];
    let runLength = 0;
    let totalLength = 0;
    let nodes = 0;
    let limited = false;
    const flush = () => {
      if (runLength) matches.push(...rangesForSearchRun(parts.join(''), segments, pattern, MAX_MATCHES + 1 - matches.length));
      parts = [];
      segments = [];
      runLength = 0;
    };
    let node;
    while ((node = walker.nextNode())) {
      nodes++;
      if (inspected > MAX_SEARCH_NODES || totalLength >= MAX_SEARCH_CHARS || matches.length > MAX_MATCHES) { limited = true; break; }
      if (nodes % 250 === 0) {
        await new Promise(resolve => setTimeout(resolve, 0));
        if (generation !== searchGeneration || identity() !== pageIdentity || !root.isConnected) return { cancelled: true };
      }
      if (node.nodeType === Node.ELEMENT_NODE) {
        if (node.tagName === 'BR' && runLength) { parts.push('\n'); runLength++; totalLength++; }
        continue;
      }
      if (!node.nodeValue || !node.parentElement) continue;
      const nextBlock = blockForSearch(node, scope, styleCache);
      if (block !== nextBlock) { flush(); block = nextBlock; }
      if (matches.length > MAX_MATCHES) { limited = true; break; }
      const text = node.nodeValue.slice(0, MAX_SEARCH_CHARS - totalLength);
      if (text.length < node.nodeValue.length) limited = true;
      parts.push(text);
      segments.push({ node, start: runLength, end: runLength + text.length });
      runLength += text.length;
      totalLength += text.length;
    }
    flush();
    if (matches.length > MAX_MATCHES) limited = true;
    return { matches: matches.slice(0, MAX_MATCHES), limited };
  }
  function jumpSearchMatch(index, recordHistory = true) {
    if (!searchMatches.length || !searchRoot?.isConnected) return;
    searchIndex = (index + searchMatches.length) % searchMatches.length;
    const item = searchMatches[searchIndex];
    if (!item.range.startContainer.isConnected || !item.range.endContainer.isConnected) { scheduleSearchRefresh(); return; }
    const m = metrics(searchRoot);
    const rect = item.range.getBoundingClientRect();
    const y = m.top + rect.top - rectFor(searchRoot).top - (isPage(searchRoot) ? 0 : searchRoot.clientTop) - stickyOffset(searchRoot);
    if (Math.abs(m.top - Math.max(0, Math.min(m.max, y))) > 1) {
      scroll(searchRoot, y, recordHistory || !searchHasJumped);
      searchHasJumped = true;
    }
    paintSearch();
    renderSearch();
  }
  async function runSearch(value, autoJump = true) {
    const query = String(value ?? '').trim().slice(0, 200);
    if (!query) { clearSearch(); return; }
    const queryChanged = query !== searchQuery;
    const previous = !queryChanged && searchMatches[searchIndex] ? searchMatches[searchIndex].range : null;
    const previousIndex = searchIndex;
    const requestedPage = pageIdentity;
    const root = resolveRoot(true);
    const generation = ++searchGeneration;
    if (!searchQuery) searchHasJumped = false;
    searchQuery = query;
    searchBusy = true;
    searchRoot = root;
    if (queryChanged) { searchMatches = []; searchIndex = -1; paintSearch(); }
    renderSearch();
    try {
      const result = await collectSearchMatches(root, query, generation);
      if (generation !== searchGeneration) return;
      if (result.cancelled || requestedPage !== pageIdentity || requestedPage !== identity() || root !== resolveRoot()) {
        if (generation === searchGeneration) {
          searchBusy = false;
          searchMatches = [];
          searchIndex = -1;
          paintSearch();
          renderSearch();
          await checkRoute();
          scheduleSearchRefresh();
        }
        return;
      }
      searchMatches = result.matches;
      searchLimited = result.limited;
      searchBusy = false;
      searchIndex = searchMatches.length ? 0 : -1;
      if (!autoJump && previous) {
        const same = searchMatches.findIndex(match => match.range.startContainer === previous.startContainer && match.range.startOffset === previous.startOffset);
        searchIndex = same >= 0 ? same : Math.min(Math.max(0, previousIndex), searchMatches.length - 1);
      }
      if (autoJump && searchMatches.length) jumpSearchMatch(0, false);
      else paintSearch();
      renderSearch();
    } catch {
      if (generation !== searchGeneration) return;
      searchBusy = false;
      searchMatches = [];
      searchIndex = -1;
      paintSearch();
      renderSearch();
      const error = 'Search could not read this page. Try another scrolling area or refresh the page.';
      announce(error);
      return { error };
    }
  }
  function scheduleSearchRefresh() {
    if (!searchQuery || searchRefreshTimer) return;
    searchRefreshTimer = setTimeout(async () => {
      searchRefreshTimer = null;
      if (!searchQuery || !enabled()) return;
      if (searchComposing || searchInputTimer) { scheduleSearchRefresh(); return; }
      if (searchBusy) { scheduleSearchRefresh(); return; }
      await runSearch(searchQuery, false);
    }, 600);
  }
  function queuePageSearch(event) {
    if (event?.isComposing || searchComposing) return;
    clearTimeout(searchInputTimer);
    const token = ++searchEditToken;
    const value = pageSearchInput.value;
    const requestedPage = pageIdentity;
    $('[data-action="clear-search"]').hidden = !value;
    if (!value.trim()) { clearSearch(); return; }
    searchGeneration++;
    searchQuery = value.trim().slice(0, 200);
    searchMatches = [];
    searchIndex = -1;
    searchBusy = true;
    paintSearch();
    renderSearch();
    searchInputTimer = setTimeout(async () => {
      searchInputTimer = null;
      if (token !== searchEditToken) return;
      await checkRoute();
      if (token === searchEditToken && requestedPage === pageIdentity && requestedPage === identity() && enabled()) await runSearch(value, true);
    }, 180);
  }
  function typing() {
    let el = document.activeElement;
    if (el === host) el = shadow.activeElement;
    while (el?.shadowRoot?.activeElement) el = el.shadowRoot.activeElement;
    // A cross-origin frame may contain an editor that the extension cannot inspect.
    return Boolean(el && (el.tagName === 'IFRAME' || el.isContentEditable || el.closest('input,textarea,select,[contenteditable="true"],[role="textbox"],[role="combobox"]')));
  }
  function selectionSnapshot() {
    let active = document.activeElement;
    if (isOwn(active)) return { kind: 'own' };
    while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
    if (isOwn(active)) return { kind: 'own' };
    if (active?.tagName === 'INPUT' && active.type === 'password') return { kind: 'protected' };
    if (active?.tagName === 'IFRAME') return { kind: 'protected' };
    if (active && ['INPUT', 'TEXTAREA'].includes(active.tagName)) {
      const start = active.selectionStart;
      const end = active.selectionEnd;
      if (Number.isInteger(start) && Number.isInteger(end) && end > start) {
        return { kind: 'text', text: active.value.slice(start, end), start: active, end: active };
      }
      return { kind: 'empty' };
    }
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !selection.rangeCount) return { kind: 'empty' };
    if (isOwn(selection.anchorNode) || isOwn(selection.focusNode)) return { kind: 'own' };
    return { kind: 'text', text: selection.toString(), start: selection.anchorNode, end: selection.focusNode };
  }
  function clearPageSelection() {
    pageSelection = null;
    selectionTooLong = false;
  }
  function rememberPageSelection(preserveEmpty = false) {
    if (!enabled()) { clearPageSelection(); return; }
    if (copyingSelection) return;
    const snapshot = selectionSnapshot();
    if (snapshot.kind === 'own') return;
    if (snapshot.kind === 'protected') { clearPageSelection(); return; }
    if (snapshot.kind === 'text' && snapshot.text.trim()) {
      if (snapshot.text.length > MAX_SELECTION_CHARS) {
        pageSelection = null;
        selectionTooLong = true;
        return;
      }
      pageSelection = { ...snapshot, page: identity(), at: Date.now() };
      selectionTooLong = false;
    } else if (!preserveEmpty && document.hasFocus()) clearPageSelection();
  }
  function getPageSelection() {
    rememberPageSelection(!document.hasFocus());
    if (selectionTooLong) return { ok: false, error: 'Select a smaller passage to copy (up to 200,000 characters).' };
    if (pageSelection && (pageSelection.page !== identity() || Date.now() - pageSelection.at > SELECTION_CACHE_MS ||
        !pageSelection.start?.isConnected || !pageSelection.end?.isConnected)) clearPageSelection();
    if (!pageSelection?.text) return { ok: false, error: 'Highlight text on the page first, then choose Copy selected text.' };
    return { ok: true, text: pageSelection.text, characters: pageSelection.text.length };
  }
  function renderSelectionHint() {
    const chars = pageSelection?.page === pageIdentity && pageSelection.start?.isConnected && pageSelection.end?.isConnected &&
      Date.now() - pageSelection.at <= SELECTION_CACHE_MS ? pageSelection.text.length : 0;
    const hint = selectionTooLong ? 'Select a smaller passage to copy.' : chars ? `${chars.toLocaleString()} characters selected.` : 'Highlight page text to copy it.';
    if ($('#pn-selection-hint').textContent !== hint) $('#pn-selection-hint').textContent = hint;
    $$('[data-companion]').forEach(button => { button.disabled = companionBusy; });
  }
  function fallbackCopyText(text) {
    const active = shadow.activeElement || document.activeElement;
    const selection = window.getSelection();
    const ranges = [];
    if (selection) {
      for (let i = 0; i < selection.rangeCount; i++) ranges.push(selection.getRangeAt(i).cloneRange());
    }
    const field = document.createElement('textarea');
    field.value = text;
    field.readOnly = true;
    field.setAttribute('aria-label', 'Text being copied');
    field.style.cssText = 'position:fixed;left:0;top:0;width:1px;height:1px;opacity:0;pointer-events:none;';
    copyingSelection = true;
    shadow.append(field);
    try {
      field.focus({ preventScroll: true });
      field.select();
      if (!document.execCommand('copy')) throw new Error('Clipboard copy was not accepted.');
    } finally {
      field.remove();
      if (active?.isConnected) active.focus({ preventScroll: true });
      if (selection && ranges.length) {
        try {
          selection.removeAllRanges();
          for (const range of ranges) if (range.startContainer.isConnected && range.endContainer.isConnected) selection.addRange(range);
        } catch { /* The webpage can replace a selected node while copy completes. */ }
      }
      copyingSelection = false;
    }
  }
  async function copySelectedText() {
    const selection = getPageSelection();
    if (!selection.ok) return selection;
    try {
      if (!navigator.clipboard?.writeText) throw new Error('Use the compatible copy method.');
      await navigator.clipboard.writeText(selection.text);
    } catch {
      try { fallbackCopyText(selection.text); }
      catch { return { ok: false, error: 'Could not copy the selected text. Try Copy selected text from the extension popup, or use Ctrl+C.' }; }
    }
    return { ok: true, characters: selection.characters };
  }
  function availableScreen() {
    const result = {};
    for (const [key, name] of [['left', 'availLeft'], ['top', 'availTop'], ['width', 'availWidth'], ['height', 'availHeight']]) {
      const value = window.screen?.[name];
      if (Number.isFinite(value)) result[key] = value;
    }
    return result;
  }
  async function openChatGPTCompanion() {
    try {
      const result = await chrome.runtime.sendMessage({ type: 'PN_COMPANION', action: 'open', screen: availableScreen() });
      return result?.ok ? result : { ok: false, error: result?.error || 'Could not open ChatGPT. Reload the extension and try again.' };
    } catch { return { ok: false, error: 'Could not open ChatGPT. Reload this page after updating the extension.' }; }
  }
  async function companionAction(name) {
    if (companionBusy) return { error: 'The companion action is already in progress.' };
    companionBusy = true;
    renderSelectionHint();
    let copied = false;
    try {
      if (name !== 'open-chatgpt') {
        const result = await copySelectedText();
        if (!result.ok) { announce(result.error); return { error: result.error }; }
        copied = true;
        announce(`Copied ${result.characters.toLocaleString()} characters. Paste in ChatGPT when ready.`);
      }
      if (name !== 'copy-selection') {
        const result = await openChatGPTCompanion();
        if (!result.ok) {
          const error = copied ? `Text copied, but ${result.error.charAt(0).toLowerCase()}${result.error.slice(1)}` : result.error;
          announce(error);
          return { error };
        }
        if (!copied) announce(result.reused ? 'Your ChatGPT window is open.' : 'ChatGPT opened in a separate window.');
      }
      return null;
    } finally {
      companionBusy = false;
      renderSelectionHint();
    }
  }
  async function checkRoute() {
    const next = identity();
    if (next === pageIdentity) return;
    pageIdentity = next;
    clearSearch();
    clearPageSelection();
    savedSpot = null;
    history.length = 0;
    manualRoot = recentRoot = activeRoot = null;
    temporarilyHidden = false;
    forcedVisible = false;
    scanNeeded = headingsDirty = true;
    lastHeading = null;
    lastHeadingDestination = null;
    $('#pn-search').value = '';
    await loadSpot();
  }
  async function action(name, value, source = 'toolbar') {
    await checkRoute();
    if (name === 'hide') { temporarilyHidden = true; showPanel(false); render(); return; }
    if (!enabled()) {
      return { error: disabledSites.includes(location.hostname) ? 'Page Navigator is disabled on this site. Enable it in the extension popup.' : 'Page Navigator is turned off. Enable it in the extension popup.' };
    }
    if (source === 'command' && settings.avoidTyping && typing() && !['toggle', 'open-search'].includes(name)) return { error: 'Shortcut paused while you are typing. Click outside the field first.' };
    const root = resolveRoot(true);
    const m = metrics(root);
    if (!['previous-heading', 'next-heading', 'outline', 'more', 'close-panel'].includes(name)) {
      lastHeading = null;
      lastHeadingDestination = null;
    }
    switch (name) {
      case 'open-chatgpt':
      case 'copy-selection':
      case 'copy-open-chatgpt': return await companionAction(name);
      case 'top': scroll(root, 0); break;
      case 'middle': scroll(root, m.max / 2); break;
      case 'end': scroll(root, m.max); break;
      case 'percent': scroll(root, m.max * Math.max(0, Math.min(100, Number(value))) / 100); break;
      case 'page-up': scroll(root, m.top - m.view * .88); break;
      case 'page-down': scroll(root, m.top + m.view * .88); break;
      case 'search': {
        clearTimeout(searchInputTimer);
        searchInputTimer = null;
        searchEditToken++;
        const failure = await runSearch(value, true);
        if (failure) return failure;
        break;
      }
      case 'clear-search': clearSearch(); break;
      case 'next-match': jumpSearchMatch(searchIndex + 1); break;
      case 'previous-match': jumpSearchMatch(searchIndex - 1); break;
      case 'open-search': showPanel(true); pageSearchInput.focus({ preventScroll: true }); pageSearchInput.select(); break;
      case 'previous-spot': {
        let previous;
        while (history.length) {
          const candidate = history.pop();
          if (candidate.root.isConnected) { previous = candidate; break; }
        }
        if (previous) {
          manualRoot = previous.manual ? previous.root : null;
          recentRoot = previous.root;
          resolveRoot();
          scroll(previous.root, previous.top, false);
          if (panelOpen) renderAreas();
          announce('Returned to the previous position.');
        }
        else announce('Make a jump first, then return here.');
        break;
      }
      case 'previous-heading': navigateHeading(-1, source); break;
      case 'next-heading': navigateHeading(1, source); break;
      case 'save-spot': {
        const failure = await saveReadingSpot();
        if (failure) return failure;
        break;
      }
      case 'restore-spot': restoreReadingSpot(); break;
      case 'clear-spot': {
        const requestedPage = pageIdentity;
        try {
          await chrome.storage.local.remove(SPOT_PREFIX + requestedPage);
          if (requestedPage === pageIdentity && requestedPage === identity()) {
            savedSpot = null;
            announce('Saved spot cleared.');
          }
        } catch {
          const error = 'Could not clear the saved spot. Reload and try again.';
          announce(error);
          return { error };
        }
        break;
      }
      case 'toggle':
        temporarilyHidden = permittedVisibility();
        if (temporarilyHidden) showPanel(false);
        else { forcedVisible = true; collapsed = false; }
        break;
      case 'show': temporarilyHidden = false; forcedVisible = true; collapsed = false; break;
      case 'outline': showPanel(true); $('#pn-search').focus({ preventScroll: true }); break;
      case 'more': showPanel(!panelOpen, true); break;
      case 'close-panel': showPanel(false, true); break;
      case 'collapse': collapsed = true; showPanel(false); await storeCollapsed(); $('.compact').focus({ preventScroll: true }); break;
      case 'expand': collapsed = false; await storeCollapsed(); render(); $('[data-action="top"]').focus({ preventScroll: true }); break;
      case 'switch-side': {
        settings.position = settings.position.endsWith('right') ? settings.position.replace('right', 'left') : settings.position.replace('left', 'right');
        try {
          const stored = await chrome.storage.local.get(SETTINGS_KEY);
          await chrome.storage.local.set({ [SETTINGS_KEY]: { ...DEFAULTS, ...stored[SETTINGS_KEY], position: settings.position } });
        } catch { announce('Placement changed for this page. It could not be saved.'); }
        break;
      }
      default: return { error: 'Unknown navigation action.' };
    }
    render();
    return null;
  }
  async function storeCollapsed() {
    try { await chrome.storage.local.set({ pnCollapsed: collapsed }); } catch { /* Keep the visible local choice. */ }
  }
  function status() {
    headingsDirty = true;
    return {
      ok: true, percent: metrics(resolveRoot()).percent, visible: permittedVisibility(),
      hasSavedSpot: Boolean(savedSpot), canGoBack: history.some(h => h.root.isConnected),
      disabledOnSite: disabledSites.includes(location.hostname), hostname: location.hostname,
      targetLabel: rootLabel(resolveRoot()), headingCount: headings().length, collapsed,
      searchQuery, searchCount: searchMatches.length, searchIndex: searchIndex + 1, searchBusy, searchLimited,
      hasSelection: Boolean(pageSelection?.page === pageIdentity && Date.now() - pageSelection.at <= SELECTION_CACHE_MS),
      selectionChars: pageSelection?.page === pageIdentity ? pageSelection.text.length : 0
    };
  }

  shell.addEventListener('click', event => {
    const button = event.target.closest('button[data-action]');
    if (!button || button.disabled) return;
    action(button.dataset.action, button.dataset.value).catch(() => announce('Reload this page to reconnect Page Navigator.'));
  });
  host.addEventListener('pointerdown', () => rememberPageSelection(true), { capture: true });
  document.addEventListener('selectionchange', () => { rememberPageSelection(); renderSelectionHint(); });
  document.addEventListener('select', event => {
    if (!event.composedPath().includes(host)) { rememberPageSelection(); renderSelectionHint(); }
  }, true);
  shell.addEventListener('keydown', event => {
    if (event.key === 'Escape' && panelOpen) { event.preventDefault(); event.stopPropagation(); showPanel(false, true); }
  });
  range.addEventListener('input', () => {
    $('#pn-range-value').textContent = `${range.value}%`;
    range.setAttribute('aria-valuetext', `${range.value} percent`);
  });
  range.addEventListener('change', () => action('percent', range.value));
  $('#pn-search').addEventListener('input', renderHeadings);
  pageSearchInput.addEventListener('input', queuePageSearch);
  pageSearchInput.addEventListener('compositionstart', () => {
    searchComposing = true;
    clearTimeout(searchInputTimer);
    searchInputTimer = null;
    searchEditToken++;
    searchGeneration++;
    searchBusy = false;
  });
  pageSearchInput.addEventListener('compositionend', event => { searchComposing = false; queuePageSearch(event); });
  pageSearchInput.addEventListener('keydown', async event => {
    if (event.key !== 'Enter' || event.isComposing) return;
    event.preventDefault();
    event.stopPropagation();
    if (searchInputTimer) {
      clearTimeout(searchInputTimer);
      searchInputTimer = null;
      await runSearch(pageSearchInput.value, true);
    } else if (!searchBusy) jumpSearchMatch(searchIndex + (event.shiftKey ? -1 : 1));
  });
  areaSelect.addEventListener('change', () => {
    manualRoot = areaSelect.value === 'auto' ? null : roots.find(r => areaId(r) === areaSelect.value) || null;
    recentRoot = null;
    headingsDirty = true;
    resolveRoot();
    render();
    renderHeadings();
    scheduleSearchRefresh();
  });
  document.addEventListener('pointerdown', event => {
    if (!event.composedPath().includes(host)) {
      lastHeading = null;
      lastHeadingDestination = null;
      if (panelOpen) showPanel(false);
    }
  }, true);
  document.addEventListener('wheel', event => {
    if (!event.composedPath().includes(host)) {
      lastHeading = null;
      lastHeadingDestination = null;
    }
  }, { capture: true, passive: true });
  document.addEventListener('keydown', event => {
    if (!event.composedPath().includes(host) && !event.altKey && !event.ctrlKey && !event.metaKey &&
        ['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End', ' '].includes(event.key)) {
      lastHeading = null;
      lastHeadingDestination = null;
    }
  }, true);
  document.addEventListener('scroll', event => {
    if (event.composedPath().includes(host)) return;
    const target = event.target === document ? pageRoot() : event.target;
    if (!manualRoot && target instanceof Element && scrollable(target) && visibleArea(target) >= innerWidth * innerHeight * .25) recentRoot = target;
    queueRender();
  }, { capture: true, passive: true });
  window.addEventListener('resize', refreshSoon, { passive: true });
  window.addEventListener('hashchange', checkRoute);
  window.addEventListener('popstate', checkRoute);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { checkRoute(); refreshSoon(); } });

  const observer = new MutationObserver(changes => {
    if (changes.some(change => !isOwn(change.target) && !(change.target === document.documentElement && [...change.addedNodes, ...change.removedNodes].every(node => node === host)))) refreshSoon();
  });
  const sizeObserver = new ResizeObserver(refreshSoon);

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || !['PN_STATUS', 'PN_ACTION', 'PN_SELECTION'].includes(message.type)) return false;
    (async () => {
      await initialized;
      await checkRoute();
      if (message.type === 'PN_SELECTION') {
        if (!enabled()) return { ok: false, error: 'Enable Page Navigator on this page before copying text.' };
        return getPageSelection();
      }
      if (message.type === 'PN_ACTION') {
        const failure = await action(message.action, message.value, message.source);
        if (failure) return { ...status(), ok: false, error: failure.error };
      }
      await checkRoute();
      return status();
    })().then(sendResponse, () => sendResponse({ ok: false, error: 'Reload this page to reconnect Page Navigator.' }));
    return true;
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes[SETTINGS_KEY]) settings = normalizeSettings(changes[SETTINGS_KEY].newValue);
    if (changes.pnDisabledSites) disabledSites = Array.isArray(changes.pnDisabledSites.newValue) ? changes.pnDisabledSites.newValue : [];
    if (changes.pnCollapsed) { collapsed = Boolean(changes.pnCollapsed.newValue); if (collapsed) showPanel(false); }
    if (changes[SPOT_PREFIX + pageIdentity]) savedSpot = validSpot(changes[SPOT_PREFIX + pageIdentity].newValue);
    if (!enabled()) { clearSearch(); clearPageSelection(); }
    render();
  });
  function normalizeSettings(raw) {
    const next = { ...DEFAULTS, ...raw };
    if (!['top-left', 'top-right', 'bottom-left', 'bottom-right'].includes(next.position)) next.position = DEFAULTS.position;
    return next;
  }
  const initialized = (async () => {
    try {
      const stored = await chrome.storage.local.get([SETTINGS_KEY, 'pnDisabledSites', 'pnCollapsed']);
      settings = normalizeSettings(stored[SETTINGS_KEY]);
      disabledSites = Array.isArray(stored.pnDisabledSites) ? stored.pnDisabledSites : [];
      collapsed = Boolean(stored.pnCollapsed);
    } catch { /* The toolbar remains usable if settings are temporarily unavailable. */ }
    host.style.setProperty('display', 'none', 'important');
    document.documentElement.append(host);
    observer.observe(document.body || document.documentElement, {
      childList: true, subtree: true, characterData: true, attributes: true,
      attributeFilter: ['hidden', 'open', 'aria-hidden', 'class', 'style']
    });
    sizeObserver.observe(document.documentElement);
    if (document.body) sizeObserver.observe(document.body);
    resolveRoot(true);
    await loadSpot();
    render();
  })();
})();
