/* Local browser QA. Requires Playwright and its Chromium binary.
   Run: node tests/browser-tests.cjs
   This starts an isolated browser profile and a loopback fixture server.
*/
const fs = require('fs');
const path = require('path');
const http = require('http');
const assert = require('assert/strict');
const { chromium } = require('playwright');
const base = __dirname;
const extension = path.resolve(base,'..');
const report = [];
const browserErrors = [];
let context, server, worker;
const sleep = ms => new Promise(resolve=>setTimeout(resolve,ms));
async function test(name,fn){try{await fn();report.push({name,passed:true});console.log('PASS',name);}catch(error){report.push({name,passed:false,error:error.message});console.error('FAIL',name,error.message);}}
async function poll(read,check,description){let value;for(let i=0;i<40;i++){value=await read();if(check(value))return value;await sleep(100);}throw new Error(description+': '+JSON.stringify(value));}
async function send(page,action,source='popup'){
 await page.bringToFront();
 const message=action===null?{type:'PN_STATUS'}:{type:'PN_ACTION',action,source};
 return worker.evaluate(async message=>{
  const [tab]=await chrome.tabs.query({active:true,lastFocusedWindow:true});
  if(!tab?.id)throw new Error('No active fixture tab');
  return chrome.tabs.sendMessage(tab.id,message,{frameId:0});
 },message);
}
async function ready(page){return poll(async()=>{try{return await send(page,null);}catch{return null;}},x=>x?.ok,'Content script did not respond');}
async function measure(page,selector){return page.evaluate(sel=>{const el=sel?document.querySelector(sel):document.scrollingElement;return {top:el.scrollTop,max:Math.max(0,el.scrollHeight-el.clientHeight),height:el.clientHeight};},selector||null);}
async function at(page,ratio,selector){return poll(()=>measure(page,selector),v=>Math.abs(v.top-v.max*ratio)<4,'Incorrect scroll position');}
async function run(){
 if(!fs.existsSync(chromium.executablePath())){
  const result={executed:false,reason:'Playwright Chromium binary is not installed in this environment.',expectedExecutable:chromium.executablePath()};
  fs.writeFileSync(path.join(base,'browser-test-results.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result,null,2));process.exitCode=2;return;
 }
 server=http.createServer((req,res)=>{const name=path.basename(new URL(req.url,'http://127.0.0.1').pathname)||'long-page.html';const p=path.join(base,name);if(!fs.existsSync(p)||!p.endsWith('.html')){res.writeHead(404).end();return;}res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(fs.readFileSync(p));});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const origin=`http://127.0.0.1:${server.address().port}`;
 context=await chromium.launchPersistentContext(path.join(base,'browser-profile'),{headless:true,channel:'chromium',viewport:{width:1280,height:900},args:[`--disable-extensions-except=${extension}`,`--load-extension=${extension}`]});
 worker=context.serviceWorkers()[0]||await context.waitForEvent('serviceworker',{timeout:15000});
 worker.on('console',msg=>{if(msg.type()==='error')browserErrors.push(msg.text());});
 await worker.evaluate(()=>chrome.storage.local.set({pnSettings:{enabled:true,smooth:false,position:'bottom-right',showProgress:true,avoidTyping:true},pnDisabledSites:[]}));
 const page=await context.newPage();
 page.on('pageerror',error=>browserErrors.push(error.message));
 await page.goto(`${origin}/long-page.html`);await ready(page);
 await test('Top, Middle, End use full document scroll range',async()=>{await send(page,'end');await at(page,1);await send(page,'middle');await at(page,.5);await send(page,'top');await at(page,0);});
 await test('Previous spot restores position before last jump',async()=>{await send(page,'middle');const before=await at(page,.5);await send(page,'end');await at(page,1);await send(page,'previous-spot');await poll(()=>measure(page),v=>Math.abs(v.top-before.top)<4,'Previous spot lost');});
 await test('Screen up/down preserve reading overlap',async()=>{await send(page,'top');await at(page,0);await send(page,'page-down');const down=await poll(()=>measure(page),v=>v.top>0,'Page down did not move');assert.ok(down.top<down.height,'Page down should overlap prior viewport');await send(page,'page-up');await at(page,0);});
 await test('Saved spot persists across page reload',async()=>{await send(page,'middle');const saved=await at(page,.5);const response=await send(page,'save-spot');assert.ok(response.ok);assert.ok(response.hasSavedSpot);await send(page,'end');await at(page,1);await page.reload();await ready(page);await send(page,'top');await at(page,0);await send(page,'restore-spot');await poll(()=>measure(page),v=>Math.abs(v.top-saved.top)<10,'Saved spot did not restore');});
 await test('Heading shortcuts move to distinct sequential headings',async()=>{await send(page,'top');await at(page,0);await send(page,'next-heading');const first=await poll(()=>measure(page),v=>v.top>0,'First heading did not move');await send(page,'next-heading');const second=await poll(()=>measure(page),v=>v.top>first.top+5,'Second heading did not advance');await send(page,'previous-heading');await poll(()=>measure(page),v=>v.top<second.top-5,'Previous heading did not return');});
 await test('Keyboard navigation does not disturb active input',async()=>{await page.locator('input').first().focus();await sleep(150);const before=await measure(page);await send(page,'end','command');await sleep(300);const after=await measure(page);assert.ok(Math.abs(after.top-before.top)<4,'Keyboard command scrolled while typing');await page.locator('input').first().evaluate(el=>el.blur());});
 await test('Nested main panel scrolls instead of sidebar/body',async()=>{await page.goto(`${origin}/nested-scroll.html`);await ready(page);await send(page,'end');await at(page,1,'main');const others=await page.evaluate(()=>({body:document.scrollingElement.scrollTop,side:document.querySelector('aside').scrollTop}));assert.equal(others.body,0);assert.equal(others.side,0);await send(page,'middle');await at(page,.5,'main');await send(page,'top');await at(page,0,'main');});
 await test('End accounts for newly added dynamic content',async()=>{await page.goto(`${origin}/dynamic-page.html`);await ready(page);await send(page,'end');const before=await at(page,1);await page.locator('#append').evaluate(el=>el.click());await sleep(300);await send(page,'end');const after=await at(page,1);assert.ok(after.max>before.max+1000);});
 await test('Toolbar hides on short pages without scroll range',async()=>{await page.goto(`${origin}/short-page.html`);const s=await ready(page);assert.equal(s.visible,false);const m=await measure(page);assert.equal(m.max,0);});
 await test('Global and per-site disabling remain effective',async()=>{await page.goto(`${origin}/long-page.html`);await ready(page);await worker.evaluate(()=>chrome.storage.local.set({pnDisabledSites:['127.0.0.1']}));await poll(()=>send(page,null),s=>s.disabledOnSite===true&&s.visible===false,'Site disable not reflected');await send(page,'end');await at(page,0);await worker.evaluate(()=>chrome.storage.local.set({pnDisabledSites:[]}));await poll(()=>send(page,null),s=>s.disabledOnSite===false,'Site enable not reflected');});
 await test('Blocked popup gives a useful error',async()=>{const extensionId=new URL(worker.url()).host;const popup=await context.newPage();await popup.goto(`chrome-extension://${extensionId}/popup.html`);await sleep(500);const text=await popup.locator('body').innerText();assert.match(text,/refresh|unavailable|ordinary|web page|Chrome page|cannot|not available/i);await popup.close();});
 await test('No uncaught page errors',async()=>assert.deepEqual(browserErrors,[]));
 await page.goto(`${origin}/long-page.html`);await ready(page);await page.screenshot({path:path.join(base,'toolbar-check.png'),fullPage:false});
 fs.writeFileSync(path.join(base,'browser-test-results.json'),JSON.stringify({executed:true,report,browserErrors},null,2)+'\n');
 process.exitCode=report.some(r=>!r.passed)?1:0;
}
run().catch(error=>{console.error(error);process.exitCode=1;}).finally(async()=>{if(context)await context.close();if(server)await new Promise(resolve=>server.close(resolve));});
