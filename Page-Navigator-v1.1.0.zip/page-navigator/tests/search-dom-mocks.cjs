'use strict';
// Minimal deterministic DOM-boundary mocks for search algorithm tests.
// These are not a DOM implementation and cannot verify browser rendering.
const NodeFilter = {SHOW_ELEMENT:1, SHOW_TEXT:4, FILTER_ACCEPT:1, FILTER_REJECT:2, FILTER_SKIP:3};
class FakeNode {
  constructor(type){this.nodeType=type;this.parentNode=null;this.isConnected=true;}
  get parentElement(){return this.parentNode?.nodeType===1?this.parentNode:null;}
  getRootNode(){let n=this;while(n.parentNode)n=n.parentNode;return n;}
  contains(node){for(let n=node;n;n=n.parentNode)if(n===this)return true;return false;}
}
FakeNode.ELEMENT_NODE=1;FakeNode.TEXT_NODE=3;
class FakeText extends FakeNode {
  constructor(data){super(3);this.data=data;this.nodeName='#text';}
  get nodeValue(){return this.data;}set nodeValue(value){this.data=String(value);}
  get textContent(){return this.data;}set textContent(value){this.data=String(value);}
  get length(){return this.data.length;}
}
const blocks = new Set('html body main article section div p h1 h2 h3 h4 h5 h6 li ul ol table tr td th pre blockquote aside nav header footer form'.split(' '));
class FakeElement extends FakeNode {
  constructor(tag,attrs={}){
    super(1);this.tagName=tag.toUpperCase();this.localName=tag.toLowerCase();this.nodeName=this.tagName;
    this.attrs={...attrs};this.childNodes=[];this.style={display:blocks.has(this.localName)?'block':'inline',visibility:'visible',contentVisibility:'visible',...attrs.style};
    this.box={top:120,left:20,right:900,bottom:145,width:880,height:25};this.clientHeight=800;this.clientWidth=900;this.clientTop=0;this.scrollHeight=8000;this.scrollTop=0;this.scrollLeft=0;
  }
  get children(){return this.childNodes.filter(n=>n.nodeType===1);}
  get childElementCount(){return this.children.length;}
  get id(){return this.attrs.id||'';}set id(v){this.attrs.id=v;}
  get textContent(){return this.childNodes.map(n=>n.textContent).join('');}
  get innerText(){return this.textContent;}
  get hidden(){return this.hasAttribute('hidden');}
  get isContentEditable(){for(let n=this;n;n=n.parentElement){if(n.attrs.contenteditable==='false')return false;if(n.hasAttribute('contenteditable'))return true;}return false;}
  get offsetWidth(){return this.getClientRects().length?this.box.width:0;}
  get offsetHeight(){return this.getClientRects().length?this.box.height:0;}
  append(...nodes){for(let node of nodes){if(typeof node==='string')node=new FakeText(node);node.parentNode=this;this.childNodes.push(node);}}
  getAttribute(k){return Object.hasOwn(this.attrs,k)?String(this.attrs[k]):null;}
  hasAttribute(k){return Object.hasOwn(this.attrs,k);}
  setAttribute(k,v){this.attrs[k]=String(v);}
  removeAttribute(k){delete this.attrs[k];}
  matches(selector){return selector.split(',').some(raw=>{
    const s=raw.trim();if(s==='*')return true;
    if(s.startsWith('#'))return this.id===s.slice(1);
    const tag=s.match(/^[A-Za-z][\w-]*/)?.[0];if(tag&&this.localName!==tag.toLowerCase())return false;
    const attrs=[...s.matchAll(/\[([\w-]+)(?:\s*=\s*["']?([^\]"']+)["']?)?\]/g)];
    if(attrs.some(([,k,v])=>!this.hasAttribute(k)||(v!==undefined&&this.getAttribute(k)!==v.trim())))return false;
    return !!tag||attrs.length>0;
  });}
  closest(selector){for(let n=this;n;n=n.parentElement)if(n.matches(selector))return n;return null;}
  querySelectorAll(selector){const result=[];function walk(n){for(const child of n.childNodes||[]){if(child.nodeType===1){if(child.matches(selector))result.push(child);walk(child);}}}walk(this);return result;}
  querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
  getBoundingClientRect(){return {...this.box};}
  getClientRects(){for(let n=this;n;n=n.parentElement)if(n.style.display==='none'||n.hasAttribute('hidden'))return [];return [this.getBoundingClientRect()];}
  scrollTo(options){this.scrollTop=options.top;}
  focus(){}addEventListener(){}removeEventListener(){}
}
function text(data){return new FakeText(data);}
function element(tag,attrs,...children){const el=new FakeElement(tag,attrs);el.append(...children);return el;}
function allText(root){const out=[];function walk(n){if(n.nodeType===3)out.push(n);else for(const child of n.childNodes||[])walk(child);}walk(root);return out;}
class FakeRange {
  constructor(){this.startContainer=null;this.endContainer=null;this.startOffset=0;this.endOffset=0;}
  setStart(node,offset){this.startContainer=node;this.startOffset=offset;}
  setEnd(node,offset){this.endContainer=node;this.endOffset=offset;}
  get collapsed(){return this.startContainer===this.endContainer&&this.startOffset===this.endOffset;}
  cloneRange(){const r=new FakeRange();r.setStart(this.startContainer,this.startOffset);r.setEnd(this.endContainer,this.endOffset);return r;}
  get commonAncestorContainer(){for(let n=this.startContainer;n;n=n.parentNode)if(n.contains(this.endContainer))return n;return null;}
  toString(){if(!this.startContainer||!this.endContainer)return '';if(this.startContainer===this.endContainer)return this.startContainer.textContent.slice(this.startOffset,this.endOffset);const nodes=allText(this.startContainer.getRootNode());const start=nodes.indexOf(this.startContainer),end=nodes.indexOf(this.endContainer);if(start<0||end<start)return '';return nodes.slice(start,end+1).map((n,i)=>n.textContent.slice(i===0?this.startOffset:0,i===end-start?this.endOffset:undefined)).join('');}
  getBoundingClientRect(){return this.startContainer?.parentElement?.getBoundingClientRect()||{top:0,left:0,right:10,bottom:10,width:10,height:10};}
  getClientRects(){return this.startContainer?.parentElement?.getClientRects()||[];}
}
class FakeHighlight extends Set {constructor(...ranges){super(ranges);}}
function makeDocument(...nodes){
 const body=element('body',{},...nodes);const html=element('html',{},body);html.clientHeight=1000;
 const doc={body,documentElement:html,scrollingElement:html,compatMode:'CSS1Compat',createRange:()=>new FakeRange(),querySelector:selector=>html.querySelector(selector),querySelectorAll:selector=>html.querySelectorAll(selector)};
 doc.createTreeWalker=(root,what,filter)=>{
   const stack=[...(root.childNodes||[])].reverse();
   return {currentNode:root,nextNode(){
     while(stack.length){
       const n=stack.pop();
       const shown=(n.nodeType===1&&(what&NodeFilter.SHOW_ELEMENT))||(n.nodeType===3&&(what&NodeFilter.SHOW_TEXT));
       const decision=shown?(typeof filter==='function'?filter(n):filter?.acceptNode?filter.acceptNode(n):NodeFilter.FILTER_ACCEPT):NodeFilter.FILTER_SKIP;
       if(decision!==NodeFilter.FILTER_REJECT)stack.push(...[...(n.childNodes||[])].reverse());
       if(shown&&decision===NodeFilter.FILTER_ACCEPT){this.currentNode=n;return n;}
     }
     return null;
   }};
 };

 return doc;
}
module.exports={FakeNode,FakeElement,FakeText,FakeRange,FakeHighlight,NodeFilter,text,element,allText,makeDocument};
