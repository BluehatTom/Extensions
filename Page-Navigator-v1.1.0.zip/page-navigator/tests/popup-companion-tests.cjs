'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const extensionRoot = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(extensionRoot, 'popup.js'), 'utf8');
const html = fs.readFileSync(path.join(extensionRoot, 'popup.html'), 'utf8');
const settle = () => new Promise(resolve => setImmediate(resolve));
async function makePopup(options = {}) {
  const trace = [];
  const listeners = {};
  const elements = new Map();
  let document;
  class Element {
    constructor(tagName = 'DIV') {
      this.tagName = tagName; this.textContent = ''; this.value = ''; this.disabled = false;
      this.hidden = false; this.checked = false; this.dataset = {}; this.style = {};
      this.isConnected = true; this.attributes = {}; this.classes = new Set();
      this.classList = {toggle: (key, value) => value ? this.classes.add(key) : this.classes.delete(key)};
    }
    setAttribute(key, value) { this.attributes[key] = value; }
    addEventListener(event, callback) { (listeners[this.id + ':' + event] ||= []).push(callback); }
    focus() { document.activeElement = this; }
    remove() { this.isConnected = false; }
  }
  class Input extends Element {
    constructor() { super('INPUT'); this.selectionStart = 0; this.selectionEnd = 0; this.selectionDirection = 'none'; }
    setSelectionRange(start, end, direction) { this.selectionStart = start; this.selectionEnd = end; this.selectionDirection = direction; }
  }
  class Textarea extends Input { constructor() { super(); this.tagName = 'TEXTAREA'; } select() { this.selectionStart = 0; this.selectionEnd = this.value.length; } }
  for (const [, tag, id] of html.matchAll(/<([a-z]+)\b[^>]*\bid="([^"]+)"/g)) {
    const element = tag === 'input' ? new Input() : new Element(tag.toUpperCase());
    element.id = id; elements.set('#' + id, element);
  }
  const section = new Element(); elements.set('.companion-section', section);
  const actionButtons = [...html.matchAll(/data-action="([^"]+)"/g)].map(([,action]) => { const button = new Element('BUTTON'); button.dataset.action = action; return button; });
  const tempFields = [];
  const ranges = [];
  const selection = {get rangeCount() { return ranges.length; }, getRangeAt: i => ranges[i], removeAllRanges: () => { ranges.splice(0); }, addRange: range => ranges.push(range)};
  document = {
    querySelector: key => elements.get(key),
    querySelectorAll: selector => selector === '[data-action]' ? actionButtons : [],
    activeElement: elements.get('#page-search'),
    getSelection: () => selection,
    createElement: tag => tag === 'textarea' ? new Textarea() : new Element(tag.toUpperCase()),
    body: {append: field => { tempFields.push(field); }},
    execCommand: command => { trace.push(['fallback', command]); return options.fallback ?? true; }
  };
  const status = {
    ok: true, hostname: 'example.com', disabledOnSite: !!options.siteDisabled, percent: 20, targetLabel: 'This page',
    hasSavedSpot: false, canGoBack: true, headingCount: 3, visible: false,
    searchQuery: '', searchCount: 0, searchIndex: 0, searchBusy: false, searchLimited: false,
    hasSelection: false, selectionChars: 0
  };
  const chrome = {
    tabs: {
      query: async () => [{id: 12, windowId: 7}],
      sendMessage: async (id, message) => {
        trace.push(['page', message.type]);
        if (message.type === 'PN_STATUS') { if (options.restricted) throw new Error('No receiver'); return status; }
        if (message.type === 'PN_SELECTION') return options.selection ?? {ok: true, text: 'Selected page text', characters: 18};
        throw new Error('Unexpected request');
      },
      create: async () => ({})
    },
    runtime: {sendMessage: async message => { trace.push(['companion', message]); return options.openResult ?? {ok: true, windowId: 88, reused: false}; }},
    storage: {local: {get: async () => { if (options.storageError) throw new Error('storage unavailable'); return {pnSettings: {enabled: !options.disabled}}; }, set: async () => {}}, onChanged: {addListener: () => {}}},
    action: {setBadgeText: async () => {}, setTitle: async () => {}}
  };
  const navigator = {clipboard: {writeText: async text => { trace.push(['clipboard', text]); if (options.clipboard) return options.clipboard(text); }}};
  const context = vm.createContext({document, chrome, navigator, HTMLInputElement: Input, HTMLTextAreaElement: Textarea,
    window: {addEventListener: () => {}, close: () => {}}, screen: options.screen ?? {availLeft: -1200, availTop: 0, availWidth: 1200, availHeight: 800},
    setTimeout, clearTimeout, console, Promise, Object, Number, String, Math, Set, Error});
  vm.runInContext(source, context, {filename: 'popup.js'});
  await settle();
  trace.splice(0);
  return {context, trace, elements, actionButtons, document, tempFields, status, run: action => vm.runInContext(`runCompanion(${JSON.stringify(action)})`, context)};
}
(async () => {
  const tests = [];
  async function test(name, check) { await check(); tests.push(name); console.log('PASS', name); }
  await test('Open remains available on a restricted tab', async () => {
    const p = await makePopup({restricted: true});
    assert.equal(p.elements.get('#open-chatgpt').disabled, false);
    assert.equal(p.elements.get('#copy-selection').disabled, true);
    await p.run('open'); assert.equal(p.trace[0][0], 'companion'); assert.equal(p.trace[0][1].sourceWindowId, 7);
  });
  await test('Open remains available with global or site navigation disabled', async () => {
    for (const options of [{disabled: true}, {siteDisabled: true}]) {
      const p = await makePopup(options); assert.equal(p.elements.get('#open-chatgpt').disabled, false);
      assert.equal(p.elements.get('#copy-selection').disabled, true); await p.run('open'); assert.equal(p.trace[0][0], 'companion');
    }
  });
  await test('A stale no-selection status does not disable copy', async () => {
    const p = await makePopup(); assert.equal(p.elements.get('#copy-selection').disabled, false);
    await p.run('copy'); assert.equal(p.trace.map(x => x[0]).join(','), 'page,clipboard');
    assert.match(p.elements.get('#companion-status').textContent, /^Text copied/);
  });
  await test('Copy & open waits for clipboard success and does not block live search', async () => {
    let release;
    const p = await makePopup({clipboard: () => new Promise(resolve => {release = resolve;})});
    const running = p.run('copyOpen'); await settle();
    assert.equal(p.trace.map(x => x[0]).join(','), 'page,clipboard');
    assert.equal(p.elements.get('#copy-selection').disabled, true);
    assert.equal(p.elements.get('#page-search').disabled, false);
    assert.equal(p.actionButtons.find(b => b.dataset.action === 'top').disabled, false);
    release(); await running;
    assert.equal(p.trace.map(x => x[0]).join(','), 'page,clipboard,companion');
    assert.equal(p.elements.get('#copy-selection').disabled, false);
  });
  await test('Empty selection neither overwrites the clipboard nor opens ChatGPT', async () => {
    const p = await makePopup({selection: {ok: true, text: '  \n ', characters: 4}});
    await p.run('copyOpen'); assert.equal(p.trace.map(x => x[0]).join(','), 'page');
    assert.match(p.elements.get('#companion-status').textContent, /Select text on the page first/);
  });
  await test('Content error is reported without copying or opening', async () => {
    const p = await makePopup({selection: {ok: false, error: 'Select text on the page first.'}});
    await p.run('copyOpen'); assert.equal(p.trace.map(x => x[0]).join(','), 'page');
    assert.equal(p.elements.get('#companion-status').textContent, 'Select text on the page first.');
  });
  await test('Clipboard failure prevents opening and does not claim text was copied', async () => {
    const p = await makePopup({clipboard: () => Promise.reject(new Error('denied')), fallback: false});
    await p.run('copyOpen'); assert.equal(p.trace.map(x => x[0]).join(','), 'page,clipboard,fallback');
    assert.equal(p.elements.get('#companion-status').textContent, 'Clipboard access failed. Please try copying again.');
    assert.ok(p.elements.get('#companion-status').classes.has('error'));
  });
  await test('Clipboard fallback removes its field and restores search focus and selection', async () => {
    const p = await makePopup({clipboard: () => Promise.reject(new Error('unavailable'))});
    const search = p.elements.get('#page-search'); search.value = 'typed search'; search.setSelectionRange(2, 6, 'backward'); search.focus();
    await p.run('copy'); assert.equal(p.document.activeElement, search);
    assert.deepEqual([search.selectionStart, search.selectionEnd, search.selectionDirection], [2, 6, 'backward']);
    assert.equal(p.tempFields.length, 1); assert.equal(p.tempFields[0].isConnected, false);
    assert.equal(search.value, 'typed search'); assert.match(p.elements.get('#companion-status').textContent, /^Text copied/);
  });
  await test('An open failure after copying reports both outcomes accurately', async () => {
    const p = await makePopup({openResult: {ok: false, error: 'Window creation failed.'}});
    await p.run('copyOpen'); assert.equal(p.trace.map(x => x[0]).join(','), 'page,clipboard,companion');
    assert.match(p.elements.get('#companion-status').textContent, /^Text copied, but ChatGPT could not be opened\./);
    assert.match(p.elements.get('#companion-status').textContent, /Window creation failed/);
  });
  await test('Screen bounds retain finite zero and negative values, omit invalid ones', async () => {
    const p = await makePopup({screen: {availLeft: -900, availTop: 0, availWidth: undefined, availHeight: Infinity}});
    await p.run('open'); assert.deepEqual(JSON.parse(JSON.stringify(p.trace[0][1].screen)), {left: -900, top: 0});
  });
  await test('Settings read failure does not block opening a companion', async () => {
    const p = await makePopup({storageError: true}); assert.equal(p.elements.get('#open-chatgpt').disabled, false);
    await p.run('open'); assert.equal(p.trace[0][0], 'companion');
  });
  await test('Busy companion rejects duplicate clicks without affecting the first action', async () => {
    let release;
    const p = await makePopup({clipboard: () => new Promise(resolve => {release = resolve;})});
    const first = p.run('copyOpen'); await settle(); await p.run('open');
    assert.equal(p.trace.map(x => x[0]).join(','), 'page,clipboard'); release(); await first;
    assert.equal(p.trace.map(x => x[0]).join(','), 'page,clipboard,companion');
  });
  console.log(`${tests.length} popup companion behavior tests passed.`);
})().catch(error => { console.error(error); process.exitCode = 1; });
