'use strict';
// Actual production search functions, deterministic DOM-boundary mocks.
// This is NOT a browser/visual test.
const fs=require('fs');const path=require('path');const vm=require('vm');const assert=require('assert/strict');
const {FakeNode,FakeElement,FakeRange,FakeHighlight,NodeFilter,text,element,makeDocument}=require('./search-dom-mocks.cjs');
const source=fs.readFileSync(path.join(__dirname,'../content.js'),'utf8');
const report=[];const fixtures=[];
function production(name){const match=source.match(new RegExp('^  (?:async )?function '+name+'\\([^\\n]*\\) \\{[\\s\\S]*?^  \\}','m'));assert.ok(match,`Cannot extract ${name}`);return match[0];}
function fixture(...nodes){
 const document=makeDocument(...nodes);const docRoot=document.scrollingElement;
 const host=element('div',{'data-page-navigator':'1'},'needle');
 const pageSearchInput={value:'',focus(){}};
 const count={textContent:''};const prev={disabled:true};const next={disabled:true};const clear={hidden:true};
 const records={scrolls:[],messages:[],rendered:0,timers:new Set()};
 const c=vm.createContext({
   URL,Number,Math,Date,console,Promise,Set,Map,WeakMap,Array,Object,String,Boolean,RegExp,
   Node:FakeNode,Element:FakeElement,NodeFilter,Highlight:FakeHighlight,CSS:{highlights:new Map()},
   document,host,pageSearchInput,shadow:{activeElement:pageSearchInput},
   MAX_MATCHES:500,MAX_SEARCH_CHARS:2000000,MAX_SEARCH_NODES:30000,ALL_MATCHES:'page-navigator-found-7f',ACTIVE_MATCH:'page-navigator-active-7f',
   searchQuery:'',searchMatches:[],searchIndex:-1,searchBusy:false,searchLimited:false,searchRoot:null,
   searchGeneration:0,searchHasJumped:false,searchInputTimer:null,searchRefreshTimer:null,searchEditToken:0,searchComposing:false,
   pageIdentity:'https://example.test/article',location:{href:'https://example.test/article'},activeRoot:docRoot,innerHeight:1000,
   isPage:el=>el===docRoot,pageRoot:()=>docRoot,scrollable:el=>!!el.nestedScroll,
   getComputedStyle:el=>el.style,resolveRoot:()=>c.activeRoot,enabled:()=>true,checkRoute:async()=>{},
   rectFor:root=>root===docRoot?{top:0}:root.getBoundingClientRect(),stickyOffset:()=>0,
   scroll:(root,y,saveHistory)=>{records.scrolls.push({root,y,saveHistory});root.scrollTop=Math.max(0,Math.min(root.scrollHeight-root.clientHeight,y));},
   announce:message=>records.messages.push(message),
   $:selector=>selector==='#pn-search-count'?count:selector==='[data-action="clear-search"]'?clear:{textContent:'',hidden:false},
   $$:()=>[prev,next],
   setTimeout:(fn,ms)=>{const handle=setTimeout(()=>{records.timers.delete(handle);fn();},ms);records.timers.add(handle);return handle;},
   clearTimeout:handle=>{clearTimeout(handle);records.timers.delete(handle);},
 });
 for(const name of ['identity','metrics','searchPattern','searchLabel','renderSearch','paintSearch','clearSearch','blockForSearch','searchElementExcluded','rangesForSearchRun','collectSearchMatches','jumpSearchMatch','runSearch','scheduleSearchRefresh','queuePageSearch'])vm.runInContext("'use strict';\n"+production(name),c,{filename:'production:'+name});
 const f={c,document,docRoot,host,pageSearchInput,count,prev,next,clear,records,cleanup(){for(const handle of records.timers)clearTimeout(handle);records.timers.clear();}};fixtures.push(f);return f;
}
async function test(name,fn){try{await fn();report.push({name,passed:true});console.log('PASS',name);}catch(error){report.push({name,passed:false,error:error.message});console.error('FAIL',name,error.stack);}}
function gate(){let resolve;const promise=new Promise(r=>{resolve=r;});return {promise,resolve};}
function range(node,start=0,end=node.textContent.length){const r=new FakeRange();r.setStart(node,start);r.setEnd(node,end);return r;}
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
(async()=>{
 await test('Live input invokes search automatically without Enter or a Go action',async()=>{
   const f=fixture(element('p',{},'needle in the document'));f.pageSearchInput.value='needle';f.c.queuePageSearch({isComposing:false});
   assert.equal(f.c.searchBusy,true);await delay(230);assert.equal(f.c.searchMatches.length,1);assert.equal(f.c.searchIndex,0);assert.equal(f.count.textContent,'1 of 1');assert.ok(f.records.scrolls.length>0);
   assert.match(source,/pageSearchInput\.addEventListener\('input', queuePageSearch\)/);
 });
 await test('Inline text split across multiple nodes maps to one correct cross-node range',async()=>{
   const a=text('The quick '),b=text('brown'),d=text(' fox jumps.');const f=fixture(element('p',{},a,element('strong',{},b),d));
   const r=await f.c.collectSearchMatches(f.docRoot,'QUICK brown FOX',0);assert.equal(r.matches.length,1);const hit=r.matches[0].range;
   assert.equal(hit.startContainer,a);assert.equal(hit.startOffset,4);assert.equal(hit.endContainer,d);assert.equal(hit.endOffset,4);assert.equal(hit.toString(),'quick brown fox');
 });
 await test('A word can span inline tags, with literal punctuation matching safely',async()=>{
   const f=fixture(element('p',{},'hel',element('span',{},'lo'),' Cost (CMR 442) + lab [A].'));
   const a=await f.c.collectSearchMatches(f.docRoot,'hello',0);assert.equal(a.matches.length,1);assert.equal(a.matches[0].range.toString(),'hello');
   const b=await f.c.collectSearchMatches(f.docRoot,'(cmr 442) + lab [a].',0);assert.equal(b.matches.length,1);assert.equal(b.matches[0].range.toString(),'(CMR 442) + lab [A].');
 });
 await test('Case-insensitive matching preserves original Unicode string offsets',async()=>{
   const original='İstanbul Kelvin π CAT café';const n=text(original);const f=fixture(element('p',{},n));
   const r=await f.c.collectSearchMatches(f.docRoot,'cat',0);assert.equal(r.matches.length,1);assert.equal(r.matches[0].range.startOffset,original.indexOf('CAT'));assert.equal(r.matches[0].range.toString(),'CAT');
 });
 await test('Separate paragraph blocks cannot manufacture a nonexistent word',async()=>{
   const f=fixture(element('p',{},'alpha'),element('p',{},'beta'));
   assert.equal((await f.c.collectSearchMatches(f.docRoot,'alphabeta',0)).matches.length,0);
   assert.equal((await f.c.collectSearchMatches(f.docRoot,'alpha beta',0)).matches.length,0);
 });
 await test('Rendered line breaks and ordinary whitespace are searchable',async()=>{
   const a=text('alpha'),b=text('beta');const f=fixture(element('p',{},a,element('br',{}),b),element('p',{},'gamma\t \ndelta'));
   const r=await f.c.collectSearchMatches(f.docRoot,'alpha beta',0);assert.equal(r.matches.length,1);assert.equal(r.matches[0].range.startContainer,a);assert.equal(r.matches[0].range.endContainer,b);assert.equal(r.matches[0].range.endOffset,4);
   assert.equal((await f.c.collectSearchMatches(f.docRoot,'gamma delta',0)).matches.length,1);
 });
 await test('Scripts, controls, hidden regions, editors, frames, and extension UI are excluded',async()=>{
   const excluded=['script','style','noscript','template','textarea','input','select','option','iframe','object','embed','canvas','svg'].map(tag=>element(tag,{},'needle'));
   for(const attrs of [{hidden:''},{inert:''},{'aria-hidden':'true'},{contenteditable:'true'},{style:{display:'none'}},{style:{visibility:'hidden'}},{style:{visibility:'collapse'}},{style:{contentVisibility:'hidden'}},{style:{opacity:'0'}}])excluded.push(element('div',attrs,element('span',{},'needle')));
   const f=fixture(element('p',{},'needle'),...excluded);f.document.body.append(f.host);
   const r=await f.c.collectSearchMatches(f.docRoot,'needle',0);assert.equal(r.matches.length,1);assert.equal(r.matches[0].range.toString(),'needle');
 });
 await test('Search uses the selected scrolling area and excludes other nested panels',async()=>{
   const main=element('main',{},element('p',{},'needle main')),side=element('aside',{},element('p',{},'needle side'));main.nestedScroll=side.nestedScroll=true;
   const f=fixture(main,side,element('p',{},'needle page'));
   const page=await f.c.collectSearchMatches(f.docRoot,'needle',0);assert.equal(page.matches.length,1);assert.equal(page.matches[0].range.startContainer.textContent,'needle page');
   const selected=await f.c.collectSearchMatches(main,'needle',0);assert.equal(selected.matches.length,1);assert.equal(selected.matches[0].range.startContainer.textContent,'needle main');
 });
 await test('Empty input clears matches, current index, owned highlights, and count',async()=>{
   const f=fixture(element('p',{},'needle'));await f.c.runSearch('needle',false);assert.equal(f.c.searchMatches.length,1);assert.ok(f.c.CSS.highlights.has(f.c.ALL_MATCHES));
   f.pageSearchInput.value='   ';f.c.queuePageSearch({isComposing:false});assert.equal(f.c.searchQuery,'');assert.equal(f.c.searchMatches.length,0);assert.equal(f.c.searchIndex,-1);assert.equal(f.c.searchBusy,false);assert.equal(f.c.CSS.highlights.has(f.c.ALL_MATCHES),false);assert.match(f.count.textContent,/Type to search/);assert.equal(f.prev.disabled,true);
 });
 await test('Previous/next wrap through matches with consistent current-result counts',async()=>{
   const f=fixture(element('p',{},'cat cat cat'));await f.c.runSearch('cat',false);assert.equal(f.count.textContent,'1 of 3');
   f.c.jumpSearchMatch(f.c.searchIndex+1);assert.equal(f.c.searchIndex,1);assert.equal(f.count.textContent,'2 of 3');
   f.c.jumpSearchMatch(f.c.searchIndex+1);f.c.jumpSearchMatch(f.c.searchIndex+1);assert.equal(f.c.searchIndex,0);assert.equal(f.count.textContent,'1 of 3');
   f.c.jumpSearchMatch(f.c.searchIndex-1);assert.equal(f.c.searchIndex,2);assert.equal(f.count.textContent,'3 of 3');
 });
 await test('No matches disables match controls and does not scroll',async()=>{
   const f=fixture(element('p',{},'ordinary text'));await f.c.runSearch('missing',true);assert.equal(f.c.searchIndex,-1);assert.equal(f.count.textContent,'No matches');assert.equal(f.prev.disabled,true);assert.equal(f.next.disabled,true);assert.equal(f.records.scrolls.length,0);f.c.jumpSearchMatch(1);assert.equal(f.records.scrolls.length,0);
 });
 await test('Highlight updates preserve all unrelated page highlights',async()=>{
   const f=fixture(element('p',{},'cat'));const other={ownedBy:'page'};f.c.CSS.highlights.set('other-highlight',other);await f.c.runSearch('cat',false);assert.equal(f.c.CSS.highlights.get('other-highlight'),other);assert.ok(f.c.CSS.highlights.has(f.c.ACTIVE_MATCH));f.c.clearSearch();assert.equal(f.c.CSS.highlights.get('other-highlight'),other);assert.equal(f.c.CSS.highlights.size,1);
 });
 await test('Match cap is enforced with an honest limited-result label',async()=>{
   const f=fixture(element('p',{},'cat cat cat cat cat'));f.c.MAX_MATCHES=3;await f.c.runSearch('cat',false);assert.equal(f.c.searchMatches.length,3);assert.equal(f.c.searchLimited,true);assert.equal(f.count.textContent,'1 of 3 · limited');
   const exact=fixture(element('p',{},'cat cat cat'));exact.c.MAX_MATCHES=3;await exact.c.runSearch('cat',false);assert.equal(exact.c.searchLimited,false);
 });
 await test('A final oversized text node is flagged as truncated',async()=>{
   const f=fixture(element('p',{},'cat and far too much additional text'));f.c.MAX_SEARCH_CHARS=8;const r=await f.c.collectSearchMatches(f.docRoot,'cat',0);assert.equal(r.matches.length,1);assert.equal(r.limited,true);
   const empty=fixture(element('p',{},'nothing visible before needle'));empty.c.MAX_SEARCH_CHARS=5;await empty.c.runSearch('needle',false);assert.equal(empty.c.searchLimited,true);assert.match(empty.count.textContent,/scan limit reached/);
 });
 await test('Node budget also bounds rejected hidden nodes',async()=>{
   const hidden=Array.from({length:15},()=>element('div',{hidden:''},'needle'));const f=fixture(...hidden,element('p',{},'needle'));f.c.MAX_SEARCH_NODES=6;const r=await f.c.collectSearchMatches(f.docRoot,'needle',0);assert.equal(r.matches.length,0);assert.equal(r.limited,true);
 });
 await test('Queries are trimmed and limited to 200 characters',async()=>{
   const f=fixture(element('p',{},'x'.repeat(400)));await f.c.runSearch('  '+'x'.repeat(250)+'  ',false);assert.equal(f.c.searchQuery.length,200);assert.equal(f.c.searchMatches.length,2);
 });
 await test('An older asynchronous scan cannot replace newer search results',async()=>{
   const oldNode=text('old'),newNode=text('new');const f=fixture(element('p',{},oldNode,newNode));const pending=gate();const oldRange=range(oldNode),newRange=range(newNode);
   f.c.collectSearchMatches=(_root,q)=>q==='old'?pending.promise:Promise.resolve({matches:[{range:newRange}],limited:false});
   const oldRun=f.c.runSearch('old',false);await f.c.runSearch('new',false);pending.resolve({matches:[{range:oldRange}],limited:false});await oldRun;
   assert.equal(f.c.searchQuery,'new');assert.equal(f.c.searchMatches[0].range,newRange);assert.equal(f.c.searchBusy,false);
 });
 await test('Typing a newer query invalidates an old scan before the debounce finishes',async()=>{
   const oldNode=text('old');const f=fixture(element('p',{},oldNode));const pending=gate();f.c.collectSearchMatches=(_root,q)=>q==='old'?pending.promise:Promise.resolve({matches:[],limited:false});
   const oldRun=f.c.runSearch('old',true);f.pageSearchInput.value='new';f.c.queuePageSearch({isComposing:false});pending.resolve({matches:[{range:range(oldNode)}],limited:false});await oldRun;
   assert.equal(f.c.searchQuery,'new');assert.equal(f.c.searchMatches.length,0);assert.equal(f.records.scrolls.length,0);await delay(230);assert.equal(f.c.searchBusy,false);assert.equal(f.count.textContent,'No matches');
 });
 await test('Changing selected scrolling area invalidates an in-flight scan',async()=>{
   const a=text('cat');const panel=element('main',{},element('p',{},'cat'));panel.nestedScroll=true;const f=fixture(element('p',{},a),panel);const pending=gate();f.c.collectSearchMatches=()=>pending.promise;
   const run=f.c.runSearch('cat',true);f.c.activeRoot=panel;pending.resolve({matches:[{range:range(a)}],limited:false});await run;assert.equal(f.c.searchMatches.length,0);assert.equal(f.c.searchBusy,false);assert.equal(f.records.scrolls.length,0);assert.ok(f.c.searchRefreshTimer);f.cleanup();
 });
 await test('Chunked traversal cancels promptly after its generation is superseded',async()=>{
   const f=fixture(...Array.from({length:200},()=>element('p',{},'ordinary text')));f.c.setTimeout=(fn)=>{f.c.searchGeneration++;fn();return 1;};
   const r=await f.c.collectSearchMatches(f.docRoot,'missing',0);assert.equal(r.cancelled,true);
 });
 await test('Refresh preserves the active result when the same node survives',async()=>{
   const f=fixture(element('p',{},'cat cat cat'));await f.c.runSearch('cat',false);f.c.jumpSearchMatch(1);const before=f.c.searchMatches[1].range;
   await f.c.runSearch('cat',false);assert.equal(f.c.searchIndex,1);assert.equal(f.c.searchMatches[1].range.startContainer,before.startContainer);assert.equal(f.c.searchMatches[1].range.startOffset,before.startOffset);
 });
 await test('Composition input waits for a finished term',async()=>{
   const f=fixture(element('p',{},'cat'));f.pageSearchInput.value='cat';f.c.searchComposing=true;f.c.queuePageSearch({isComposing:true});assert.equal(f.c.searchInputTimer,null);assert.equal(f.c.searchQuery,'');f.c.searchComposing=false;f.c.queuePageSearch({isComposing:false});await delay(230);assert.equal(f.c.searchMatches.length,1);
 });
 await test('Detached or unpainted text never produces a match range',async()=>{
   const a=text('cat');const f=fixture(element('p',{},a));a.isConnected=false;assert.equal((await f.c.collectSearchMatches(f.docRoot,'cat',0)).matches.length,0);
   a.isConnected=true;a.parentElement.box.width=0;assert.equal((await f.c.collectSearchMatches(f.docRoot,'cat',0)).matches.length,0);
 });
 await test('Unexpected scan failures clear busy state and return a useful error',async()=>{
   const f=fixture(element('p',{},'cat'));f.c.collectSearchMatches=async()=>{throw new Error('Removed DOM');};const result=await f.c.runSearch('cat',false);assert.ok(result?.error);assert.equal(f.c.searchBusy,false);assert.equal(f.c.searchMatches.length,0);assert.equal(f.c.searchIndex,-1);
 });
 const result={kind:'deterministic Node VM search logic tests with DOM-boundary mocks; not browser validation',passed:report.filter(r=>r.passed).length,failed:report.filter(r=>!r.passed).length,tests:report};
 fs.writeFileSync(path.join(__dirname,'search-contract-results.json'),JSON.stringify(result,null,2)+'\n');console.log(`\n${result.passed} passed, ${result.failed} failed. Browser search rendering not executed.`);process.exitCode=result.failed?1:0;
})().catch(error=>{console.error(error);process.exitCode=1;}).finally(()=>fixtures.forEach(f=>f.cleanup()));
