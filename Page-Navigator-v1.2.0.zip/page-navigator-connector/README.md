# Page Navigator local connector

This small program connects Page Navigator's embedded page chat to the OpenAI API. It runs on your own computer. No npm packages or build step are needed.

## First setup on Windows

1. Install **Node.js 22 or later** from [nodejs.org](https://nodejs.org/) if it is not already installed. Restart your terminal after installing Node.
2. Keep this `page-navigator-connector` folder somewhere permanent.
3. Double-click **START-WINDOWS.cmd**. Keep the connector window open while using page chat.
4. A local setup page opens. If it does not, open the setup link printed in the connector window.
5. Paste your **OpenAI API key** into that local setup page and choose **Save key**.
6. Copy the **connection code** shown there.
7. In Page Navigator's **Page chat** sidebar, open **Connection settings**, paste the connection code, and choose **Connect**.
8. Choose **Use this page** or **Use selection**, then ask your question.

The API key stays in the connector's memory for that running session. Closing the connector forgets it. The connection code stays the same between launches, so you normally only need to paste that code into the extension once. Each new connector session needs the API key entered again unless you use the environment-variable option below.

Saving or connecting makes no paid OpenAI request. OpenAI validates your key and model access when you send a question. API access requires an available model and API credits; a ChatGPT website login does not configure this connector.

## Mac or Linux

With Node.js 22 or later installed, open a terminal in this folder and run:

```sh
sh start-mac-linux.sh
```

You can also start it directly on any supported platform:

```sh
node server.mjs --open
```

The `--open` flag opens the local setup screen. Without it, the setup link is printed in the terminal. Press **Ctrl+C** in that terminal to stop the connector.

## Model and existing environment configuration

The default model is `gpt-5.4-mini`. Open **Model settings** in the local setup page to choose a different model available to your API project. The model must support the Responses API and structured outputs.

If your computer already provides the `OPENAI_API_KEY` environment variable, the connector can use it at startup. `OPENAI_MODEL` optionally sets the starting model. The connector never writes either value to a file. Avoid putting an API key into the launcher, this folder, or any file you upload to GitHub.

This version does not save API keys to a password manager or an encrypted settings file. The local setup screen offers session-only key entry.

## What is sent and stored

- The extension sends an attached page snapshot and your current conversation to this local connector only when you ask a question.
- The connector sends the snapshot's title, selected text passages, and conversation to OpenAI. The page-address field (including its query string and fragment) and snapshot identifiers are not included in the model request.
- Requests use `store: false`. This disables API response storage for this request; it is not a promise that all provider-side processing or retention is disabled. Your API organization's OpenAI data controls still apply.
- No requests, page text, questions, responses, or API keys are written to logs or disk by the connector.
- A random connection token is stored outside the download folder so the extension can reconnect after a restart. It is stored in `connection.json` under `%LOCALAPPDATA%\PageNavigatorConnector` on Windows, `~/Library/Application Support/PageNavigatorConnector` on macOS, or `${XDG_CONFIG_HOME:-~/.config}/page-navigator-connector` on Linux. This file contains no OpenAI API key.
- The local setup link contains a separate temporary administrator token in its URL fragment. The setup screen keeps it in that browser tab's session storage and removes it from the displayed address. Never share the setup link or connection code.

The connector accepts connections only on `127.0.0.1:43127`. It checks the request host and origin, requires a connection code for chat, and rejects requests from ordinary websites. The setup screen has separate authorization. At most one model request runs at a time, with a 60-second deadline and a limit of 20 requests per minute. There are no automatic retries that could repeat a paid request.

Page snapshots are bounded to 60,000 text characters, 200 passages, and 6,000 characters per passage. Conversation history is bounded to 12 messages and 20,000 characters; each user question is limited to 4,000 characters. The model response is capped at 3,000 output tokens. If it stops before completing the required answer, the connector reports the problem instead of displaying a partial answer as complete.

The model can return an answer and passage references. It cannot run code or change a webpage. References are checked against the supplied passage IDs and actual quoted text before the extension receives them.

## Troubleshooting

| Message | Next step |
| --- | --- |
| Node.js is missing or too old | Install Node.js 22 or later, then start the connector again. |
| Port 43127 is already in use | Use the connector window already running. If another program owns the port, close it before starting this connector. |
| Connection code is incorrect | Copy the current code from the local setup screen into the sidebar. |
| API key is not configured | Enter it in the local setup screen. Keys are forgotten when the connector closes. |
| OpenAI rejected the key | Replace the key in local setup; check that it belongs to the intended API project. |
| Model is unavailable | Choose an accessible model with Responses API and structured-output support. |
| OpenAI rate or credit limit | Check your API account's credits and limits, or wait before retrying. |
| Another answer is running | Stop that request or wait for it to finish. |
| Setup link is no longer valid | Use the link in the currently running connector window. A restart creates a new setup link. |

## Source and tests

- `server.mjs`: loopback server, local setup, authentication, request limits, startup.
- `openai.mjs`: input validation, OpenAI request construction, and answer/source validation.
- `public/`: setup interface; no external scripts or libraries.
- `tests/connector-tests.mjs`: protocol tests using an injected fake OpenAI response.

Run the tests from this folder:

```sh
node --test tests/connector-tests.mjs
```

Tests do not read a real API key or contact OpenAI. Native Windows launcher behavior, browser rendering, and a real model response require testing on the destination computer.

## Official documentation

- [OpenAI text generation](https://developers.openai.com/api/docs/guides/text)
- [Structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs?api-mode=responses)
- [GPT-5.4 Mini](https://developers.openai.com/api/docs/models/gpt-5.4-mini)
- [API key guidance](https://developers.openai.com/api/docs/guides/api-keys)
