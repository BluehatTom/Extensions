'use strict';

const $ = selector => document.querySelector(selector);
const status = $('#setup-status');
const apiKey = $('#api-key');
const model = $('#model');
const code = $('#connection-code');
const tokenPattern = /^[A-Za-z0-9_-]{43}$/;
let adminToken = '';
let ready = false;
let busy = false;
let configured = false;

// Only the local setup authorization is kept in this tab. API keys are never stored by this page.
try {
  const fragment = location.hash.slice(1);
  if (tokenPattern.test(fragment)) {
    adminToken = fragment;
    sessionStorage.setItem('pnConnectorSetupToken', fragment);
    history.replaceState(null, '', '/setup');
  } else {
    const saved = sessionStorage.getItem('pnConnectorSetupToken') || '';
    if (tokenPattern.test(saved)) adminToken = saved;
  }
} catch {
  const fragment = location.hash.slice(1);
  if (tokenPattern.test(fragment)) adminToken = fragment;
}

function message(text, error = false) { status.textContent = text; status.classList.toggle('error', error); }
function render() {
  for (const control of [apiKey, model, $('#save-key'), $('#reset-code')]) control.disabled = !ready || busy;
  $('#copy-code').disabled = !ready || busy || !code.value;
  $('#show-code').disabled = !ready || busy || !code.value;
  $('#remove-key').hidden = !configured;
  $('#remove-key').disabled = busy || !ready;
  $('#key-state').textContent = configured ? 'Ready for this session' : 'Not set';
  $('#key-state').classList.toggle('ready', configured);
  $('#save-key').textContent = configured ? 'Update settings' : 'Save key';
  apiKey.required = !configured;
  apiKey.placeholder = configured ? 'Leave blank to keep the current key' : 'Paste your API key';
}

async function request(route, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 7000);
  try {
    const response = await fetch(route, {
      ...options, signal: controller.signal, cache: 'no-store', credentials: 'omit',
      headers: { Authorization: `Bearer ${adminToken}`, ...(options.body ? { 'Content-Type': 'application/json' } : {}) }
    });
    let result;
    try { result = await response.json(); } catch { throw new Error('The connector returned an unreadable response. Restart it and open the new setup link.'); }
    if (!response.ok || !result.ok) throw new Error(result.error || 'The connector could not finish this request.');
    return result;
  } catch (error) {
    if (error.name === 'AbortError' || error instanceof TypeError) throw new Error('The connector is not responding. Start it again, then open its setup link.');
    throw error;
  } finally { clearTimeout(timer); }
}

async function run(operation) {
  if (!ready || busy) return;
  busy = true; render();
  try { await operation(); }
  catch (error) { message(error.message || 'That action could not be completed.', true); }
  finally { busy = false; render(); }
}

$('#key-form').addEventListener('submit', event => {
  event.preventDefault();
  run(async () => {
    const body = { model: model.value.trim() };
    if (apiKey.value.trim()) body.apiKey = apiKey.value.trim();
    const result = await request('/setup/config', { method: 'POST', body: JSON.stringify(body) });
    apiKey.value = ''; configured = result.configured; code.value = result.connectionToken; model.value = result.model;
    message('Your API key is ready for this session. Copy the connection code below and connect Page Navigator.');
  });
});

$('#copy-code').addEventListener('click', () => run(async () => {
  let copied = false;
  try { if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(code.value); copied = true; } } catch { /* Use the explicit selection fallback. */ }
  if (!copied) {
    const originalType = code.type; code.type = 'text'; code.focus(); code.select();
    try { copied = typeof document.execCommand === 'function' && document.execCommand('copy'); }
    finally { code.type = originalType; }
  }
  if (!copied) {
    code.type = 'text'; $('#show-code').textContent = 'Hide'; $('#show-code').setAttribute('aria-pressed', 'true');
    code.focus(); code.select(); throw new Error('The code is selected. Use Ctrl+C or Command+C to copy it.');
  }
  message('Connection code copied. Paste it into Page chat → Connection settings, then choose Connect.');
}));

$('#show-code').addEventListener('click', () => {
  const show = code.type === 'password'; code.type = show ? 'text' : 'password';
  $('#show-code').textContent = show ? 'Hide' : 'Show'; $('#show-code').setAttribute('aria-pressed', String(show));
});

$('#remove-key').addEventListener('click', () => run(async () => {
  await request('/setup/config', { method: 'DELETE' });
  apiKey.value = ''; configured = false;
  message('The key has been removed from this session. Add a key again when you want to chat.');
}));

$('#reset-code').addEventListener('click', () => run(async () => {
  const result = await request('/setup/reset-connection', { method: 'POST' });
  code.value = result.connectionToken;
  message('A new connection code is ready. Copy it into Page Navigator to reconnect.');
}));

$('#local-address').textContent = location.host;
(async () => {
  if (!adminToken) { message('Open the setup link shown in the connector window. If that window is closed, start the connector again.', true); return; }
  try {
    const result = await request('/setup/state');
    configured = result.configured; model.value = result.model; code.value = result.connectionToken; ready = true;
    message(configured ? 'The connector is ready. Copy the connection code below to connect your extension.' : 'The connector is running. Add your OpenAI API key to enable page chat.');
  } catch (error) { message(error.message, true); }
  render();
})();
