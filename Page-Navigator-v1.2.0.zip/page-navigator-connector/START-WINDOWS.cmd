@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 22 or later from https://nodejs.org
  echo Then double-click START-WINDOWS.cmd again.
  pause
  exit /b 1
)
node server.mjs --open
if errorlevel 1 pause
