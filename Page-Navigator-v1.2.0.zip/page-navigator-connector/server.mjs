import http from 'node:http';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { readFile, mkdir, open, rename } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { spawn } from 'node:child_process';
import { askOpenAI, ConnectorError, DEFAULT_MODEL, LIMITS, validateApiKey, validateChatRequest, validateModel } from './openai.mjs';

export const VERSION = '1.2.0';
export const DEFAULT_PORT = 43127;
const PUBLIC = path.join(path.dirname(fileURLToPath(import.meta.url)), 'public');
const TOKEN_PATTERN = /^[A-Za-z0-9_-]{43}$/;
const newToken = () => randomBytes(32).toString('base64url');
const EXTENSION_ORIGIN = /^chrome-extension:\/\/[a-p]{32}$/;

function equalToken(actual, expected) {
  if (typeof actual !== 'string' || typeof expected !== 'string' || !TOKEN_PATTERN.test(actual) || actual.length !== expected.length) return false;
  return timingSafeEqual(Buffer.from(actual), Buffer.from(expected));
}
function bearer(request) {
  const value = request.headers.authorization;
  return typeof value === 'string' && value.startsWith('Bearer ') ? value.slice(7) : '';
}
function sendJSON(response, status, body, extra = {}) {
  if (response.destroyed || response.writableEnded) return;
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...extra });
  response.end(JSON.stringify(body));
}
function fail(status, code, message) { throw new ConnectorError(status, code, message); }

async function readJSON(request) {
  if (!/^application\/json(?:\s*;\s*charset=utf-8)?$/i.test(request.headers['content-type'] || '')) fail(415, 'content_type', 'Send this request as JSON.');
  if (Number(request.headers['content-length']) > LIMITS.bodyBytes) fail(413, 'too_large', 'The request is too large. Select less text or start a new chat.');
  return new Promise((resolve, reject) => {
    const parts = []; let length = 0; let settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true; clearTimeout(timer);
      request.removeListener('data', data); request.removeListener('end', end);
      request.removeListener('aborted', aborted); request.removeListener('error', failed);
      if (error) reject(error); else resolve(value);
    };
    const data = chunk => {
      length += chunk.length;
      if (length > LIMITS.bodyBytes) {
        request.pause();
        finish(new ConnectorError(413, 'too_large', 'The request is too large. Select less text or start a new chat.'));
      } else parts.push(chunk);
    };
    const end = () => {
      try { finish(null, JSON.parse(Buffer.concat(parts).toString('utf8'))); }
      catch { finish(new ConnectorError(400, 'invalid_json', 'The request was not valid JSON. Try again.')); }
    };
    const aborted = () => finish(new ConnectorError(400, 'cancelled', 'The request was cancelled.'));
    const failed = () => finish(new ConnectorError(400, 'connection', 'The request connection closed.'));
    const timer = setTimeout(() => {
      request.pause(); finish(new ConnectorError(408, 'body_timeout', 'The request took too long to arrive. Try again.'));
    }, 10000);
    timer.unref();
    request.on('data', data); request.on('end', end);
    request.on('aborted', aborted); request.on('error', failed);
  });
}

// Factory options permit deterministic protocol tests with an injected upstream.
// Production uses the fixed OpenAI endpoint and only listens on the loopback interface.
export function createConnector(options = {}) {
  let apiKey = options.apiKey ? validateApiKey(options.apiKey) : '';
  let model = validateModel(options.model || DEFAULT_MODEL);
  let connectionToken = options.connectionToken || newToken();
  const adminToken = options.adminToken || newToken();
  if (!TOKEN_PATTERN.test(connectionToken) || !TOKEN_PATTERN.test(adminToken)) throw new Error('Invalid connector token configuration.');
  const saveConnectionToken = options.saveConnectionToken || (async () => {});
  const fetchImpl = options.fetchImpl || fetch;
  const timeoutMs = options.timeoutMs ?? 60000;
  const requestLimit = options.requestLimit ?? 20;
  const rateWindowMs = options.rateWindowMs ?? 60000;
  const requestTimes = [];
  let activeController = null;
  let origin = '';
  let stopping = false;

  const server = http.createServer(async (request, response) => {
    response.setHeader('Cache-Control', 'no-store');
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('Referrer-Policy', 'no-referrer');
    response.setHeader('X-Frame-Options', 'DENY');
    response.setHeader('Content-Security-Policy', "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; form-action 'none'");
    response.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
    try {
      const host = new URL(origin).host;
      if (request.headers.host !== host) fail(403, 'host', 'This connector accepts only its local loopback address.');
      if (!request.url?.startsWith('/') || request.url.startsWith('//') || request.url.includes('?') || request.url.includes('#')) fail(400, 'path', 'This connector address is invalid.');
      const route = request.url;
      const callerOrigin = request.headers.origin;
      const isExtension = typeof callerOrigin === 'string' && EXTENSION_ORIGIN.test(callerOrigin);
      const isSetup = callerOrigin === origin;
      if (callerOrigin !== undefined && !isExtension && !isSetup) fail(403, 'origin', 'This website cannot use the local connector.');
      const extensionRoute = ['/health', '/status', '/chat'].includes(route);
      if (isExtension && extensionRoute) {
        response.setHeader('Access-Control-Allow-Origin', callerOrigin);
        response.setHeader('Vary', 'Origin');
      }
      if (request.method === 'OPTIONS') {
        if (!isExtension || !extensionRoute) fail(403, 'origin', 'This website cannot use the local connector.');
        const requestedMethod = request.headers['access-control-request-method'];
        const expectedMethod = route === '/chat' ? 'POST' : 'GET';
        if (requestedMethod !== expectedMethod) fail(405, 'method', 'This request method is not supported.');
        const headers = String(request.headers['access-control-request-headers'] || '').split(',').map(value => value.trim().toLowerCase()).filter(Boolean);
        if (headers.some(header => !['authorization', 'content-type'].includes(header))) fail(403, 'headers', 'This request uses unsupported headers.');
        response.setHeader('Access-Control-Allow-Methods', expectedMethod);
        response.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
        response.setHeader('Access-Control-Max-Age', '600');
        if (request.headers['access-control-request-private-network'] === 'true') response.setHeader('Access-Control-Allow-Private-Network', 'true');
        response.writeHead(204); response.end(); return;
      }
      if (stopping) fail(503, 'stopping', 'The connector is stopping. Start it again to chat.');

      if (request.method === 'GET' && route === '/health') {
        sendJSON(response, 200, { ok: true, service: 'page-navigator', version: VERSION, configured: Boolean(apiKey) }); return;
      }
      if (extensionRoute) {
        if (!equalToken(bearer(request), connectionToken)) fail(401, 'unauthorized', 'The connection code is missing or incorrect. Copy it from the connector setup screen.');
        if (request.method === 'GET' && route === '/status') {
          sendJSON(response, 200, { ok: true, configured: Boolean(apiKey), model }); return;
        }
        if (route !== '/chat' || request.method !== 'POST') fail(405, 'method', 'This request method is not supported.');
        if (!apiKey) fail(503, 'not_configured', 'Enter your OpenAI API key in the connector setup screen first.');
        const validated = validateChatRequest(await readJSON(request));
        if (request.aborted || response.destroyed) return;
        if (activeController) fail(429, 'busy', 'Another answer is still running. Stop it or wait before sending another question.');
        const now = Date.now();
        while (requestTimes.length && requestTimes[0] <= now - rateWindowMs) requestTimes.shift();
        if (requestTimes.length >= requestLimit) {
          response.setHeader('Retry-After', String(Math.max(1, Math.ceil((requestTimes[0] + rateWindowMs - now) / 1000))));
          fail(429, 'local_limit', 'The connector has received many requests. Wait a minute before trying again.');
        }
        requestTimes.push(now);
        const controller = new AbortController(); activeController = controller;
        const timeout = setTimeout(() => controller.abort(new Error('Request timeout')), timeoutMs); timeout.unref();
        const disconnected = () => { if (!response.writableEnded) controller.abort(new Error('Client disconnected')); };
        response.on('close', disconnected);
        try {
          const answer = await askOpenAI({ validated, apiKey, model, signal: controller.signal, fetchImpl });
          if (!controller.signal.aborted) sendJSON(response, 200, answer);
          else if (!response.destroyed) fail(504, 'timeout', 'The request stopped before an answer arrived. Try again when ready.');
        } finally {
          clearTimeout(timeout); response.removeListener('close', disconnected);
          if (activeController === controller) activeController = null;
        }
        return;
      }

      if (route.startsWith('/setup/')) {
        // Setup is a separate local administrator surface. An extension token cannot change its key.
        // Same-origin GET fetches can omit Origin; their admin bearer still authenticates them.
        if ((!isSetup && callerOrigin !== undefined) || !equalToken(bearer(request), adminToken)) fail(401, 'setup_auth', 'Open the setup link shown in the connector window.');
        if (route === '/setup/state' && request.method === 'GET') {
          sendJSON(response, 200, { ok: true, configured: Boolean(apiKey), model, connectionToken, sessionOnly: true }); return;
        }
        if (route === '/setup/config' && request.method === 'POST') {
          const body = await readJSON(request);
          if (!body || typeof body !== 'object' || Array.isArray(body)) fail(400, 'invalid_request', 'The setup values were invalid.');
          const nextModel = Object.hasOwn(body, 'model') ? validateModel(body.model) : model;
          const nextKey = Object.hasOwn(body, 'apiKey') ? validateApiKey(body.apiKey) : apiKey;
          if (!nextKey) fail(400, 'missing_key', 'Enter your OpenAI API key first.');
          apiKey = nextKey; model = nextModel;
          sendJSON(response, 200, { ok: true, configured: true, model, connectionToken, sessionOnly: true }); return;
        }
        if (route === '/setup/config' && request.method === 'DELETE') {
          apiKey = ''; activeController?.abort(new Error('Key removed'));
          sendJSON(response, 200, { ok: true, configured: false, model }); return;
        }
        if (route === '/setup/reset-connection' && request.method === 'POST') {
          const replacement = newToken();
          try { await saveConnectionToken(replacement); }
          catch { fail(500, 'storage', 'The new connection code could not be saved. Your existing code still works.'); }
          connectionToken = replacement;
          sendJSON(response, 200, { ok: true, connectionToken }); return;
        }
        fail(404, 'not_found', 'This setup action was not found.');
      }

      if (request.method !== 'GET') fail(405, 'method', 'This request method is not supported.');
      if (isExtension) fail(403, 'origin', 'Open the local setup page in a browser tab.');
      if (route === '/') { response.writeHead(302, { Location: '/setup' }); response.end(); return; }
      const assets = {
        '/setup': ['setup.html', 'text/html; charset=utf-8'],
        '/setup.js': ['setup.js', 'text/javascript; charset=utf-8'],
        '/setup.css': ['setup.css', 'text/css; charset=utf-8']
      };
      const asset = assets[route];
      if (!asset) fail(404, 'not_found', 'This connector page was not found.');
      const bytes = await readFile(path.join(PUBLIC, asset[0]));
      response.writeHead(200, { 'Content-Type': asset[1] }); response.end(bytes);
    } catch (error) {
      const safe = error instanceof ConnectorError ? error : new ConnectorError(500, 'internal', 'The connector could not finish this request. Restart it and try again.');
      // Never forward stack traces, credentials, upstream bodies, or page content to logs.
      const close = !request.complete || [413, 408].includes(safe.status);
      sendJSON(response, safe.status, { ok: false, error: safe.message, code: safe.code }, close ? { Connection: 'close' } : {});
      if (close) response.once('finish', () => request.destroy());
    }
  });
  server.headersTimeout = 10000;
  server.requestTimeout = 15000;
  server.keepAliveTimeout = 5000;
  server.maxHeadersCount = 40;
  server.maxRequestsPerSocket = 100;
  server.maxConnections = 32;
  return {
    server,
    async start(port = DEFAULT_PORT) {
      await new Promise((resolve, reject) => {
        const failed = error => { server.removeListener('listening', ready); reject(error); };
        const ready = () => { server.removeListener('error', failed); resolve(); };
        server.once('error', failed); server.once('listening', ready);
        server.listen(port, '127.0.0.1');
      });
      origin = `http://127.0.0.1:${server.address().port}`;
      return origin;
    },
    async stop() {
      stopping = true; apiKey = ''; activeController?.abort(new Error('Connector stopped'));
      if (!server.listening) return;
      await new Promise(resolve => { server.close(resolve); server.closeAllConnections(); });
    },
    get origin() { return origin; },
    get setupURL() { return `${origin}/setup#${adminToken}`; }
  };
}

export function settingsDirectory() {
  if (process.platform === 'win32') return path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), 'PageNavigatorConnector');
  if (process.platform === 'darwin') return path.join(os.homedir(), 'Library', 'Application Support', 'PageNavigatorConnector');
  return path.join(process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config'), 'page-navigator-connector');
}

export async function loadConnectionIdentity(directory) {
  await mkdir(directory, { recursive: true, mode: 0o700 });
  const destination = path.join(directory, 'connection.json');
  const save = async token => {
    const temporary = path.join(directory, `.connection-${randomBytes(8).toString('hex')}.tmp`);
    const handle = await open(temporary, 'wx', 0o600);
    try { await handle.writeFile(JSON.stringify({ version: 1, connectionToken: token }) + '\n'); }
    finally { await handle.close(); }
    await rename(temporary, destination);
  };
  try {
    const data = JSON.parse(await readFile(destination, 'utf8'));
    if (data.version === 1 && TOKEN_PATTERN.test(data.connectionToken)) return { token: data.connectionToken, save };
    throw new Error('Invalid local connection settings.');
  } catch (error) {
    if (error.code !== 'ENOENT') throw new Error('Local connection settings could not be read. Rename the connection.json file in your connector settings folder, then start again.');
  }
  const token = newToken(); await save(token); return { token, save };
}

function openSetup(url) {
  // The URL is created by this process, not supplied by a webpage or model.
  let command, args;
  if (process.platform === 'win32') { command = 'rundll32.exe'; args = ['url.dll,FileProtocolHandler', url]; }
  else if (process.platform === 'darwin') { command = 'open'; args = [url]; }
  else { command = 'xdg-open'; args = [url]; }
  const child = spawn(command, args, { stdio: 'ignore', detached: true, windowsHide: true });
  child.on('error', () => { /* The printed setup URL remains available. */ }); child.unref();
}

async function main() {
  if (Number(process.versions.node.split('.')[0]) < 22) throw new Error('Install Node.js 22 or later from https://nodejs.org, then start the connector again.');
  const identity = await loadConnectionIdentity(settingsDirectory());
  const connector = createConnector({
    apiKey: process.env.OPENAI_API_KEY || '', model: process.env.OPENAI_MODEL || DEFAULT_MODEL,
    connectionToken: identity.token, saveConnectionToken: identity.save
  });
  try { await connector.start(); }
  catch (error) {
    if (error.code === 'EADDRINUSE') throw new Error('Port 43127 is already in use. If Page Navigator Connector is already running, use its existing window and setup page. Otherwise close the program using this port and start again.');
    throw new Error('The local connector could not start. Check whether local security software blocks this application.');
  }
  console.log(`\nPage Navigator Connector ${VERSION}\n\nOpen this local setup link:\n${connector.setupURL}\n\nKeep this window open while using page chat. Press Ctrl+C to stop.\n`);
  if (process.argv.includes('--open')) openSetup(connector.setupURL);
  let closing = false;
  const stop = async () => { if (closing) return; closing = true; await connector.stop(); console.log('Page Navigator Connector stopped.'); };
  process.once('SIGINT', stop); process.once('SIGTERM', stop);
}

const invoked = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (invoked) main().catch(error => { console.error(error.message || 'The connector could not start.'); process.exitCode = 1; });
