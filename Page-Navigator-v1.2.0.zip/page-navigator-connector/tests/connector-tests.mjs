import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { mkdtemp, readFile, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createConnector, loadConnectionIdentity } from '../server.mjs';
import { DEFAULT_MODEL, OPENAI_ENDPOINT } from '../openai.mjs';

// All credentials and upstream replies in this suite are deliberately fake.
// It uses real loopback HTTP; it never reads OPENAI_API_KEY or contacts OpenAI.
const CONNECTION = 'c'.repeat(43);
const ADMIN = 'a'.repeat(43);
const FAKE_KEY = 'unit-test-not-a-real-api-key';
const EXTENSION = `chrome-extension://${'a'.repeat(32)}`;
const testDirectory = path.dirname(fileURLToPath(import.meta.url));
const delay = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));

function context() {
  const blocks = [
    { id: 'b1', text: 'Applications close on December 12. Registration is free.', label: 'Application deadline' },
    { id: 'b2', text: 'The workshop begins at 9 a.m.\nBring a notebook.', label: 'Workshop details' }
  ];
  return { id: 'snapshot-1', url: 'https://example.test/workshop', title: 'Workshop', scope: 'page', capturedAt: Date.now(), characters: blocks.reduce((sum, block) => sum + block.text.length, 0), truncated: false, blocks };
}
function question() { return { context: context(), messages: [{ role: 'user', content: 'When is the deadline?' }] }; }
function completed(answer = { answer: 'Applications close on December 12.', citations: [{ blockId: 'b1', quote: 'Applications close on December 12.' }] }) {
  return { status: 'completed', output: [{ type: 'message', content: [{ type: 'output_text', text: JSON.stringify(answer) }] }], usage: { input_tokens: 120, output_tokens: 30 } };
}
function apiResponse(data = completed(), status = 200) { return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } }); }
function gate() { let resolve, reject; const promise = new Promise((yes, no) => { resolve = yes; reject = no; }); return { promise, resolve, reject }; }

async function fixture(t, options = {}) {
  const calls = [];
  const connector = createConnector({
    apiKey: FAKE_KEY, connectionToken: CONNECTION, adminToken: ADMIN,
    fetchImpl: async (url, request) => { calls.push({ url, request }); return apiResponse(); },
    ...options
  });
  await connector.start(0);
  t.after(() => connector.stop());
  const send = (route, config = {}) => new Promise((resolve, reject) => {
    const body = config.raw !== undefined ? config.raw : config.body !== undefined ? JSON.stringify(config.body) : undefined;
    const token = Object.hasOwn(config, 'token') ? config.token : CONNECTION;
    const origin = Object.hasOwn(config, 'origin') ? config.origin : EXTENSION;
    const headers = {
      ...(token !== null ? { Authorization: `Bearer ${token}` } : {}),
      ...(origin !== null && origin !== undefined ? { Origin: origin } : {}),
      ...(body !== undefined ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) } : {}),
      ...config.headers
    };
    const request = http.request(`${connector.origin}${route}`, { method: config.method || 'GET', headers }, response => {
      const chunks = [];
      response.on('data', chunk => chunks.push(chunk));
      response.on('end', () => {
        const text = Buffer.concat(chunks).toString(); let json;
        try { json = JSON.parse(text); } catch { /* HTML or an empty preflight response. */ }
        resolve({ status: response.statusCode, headers: response.headers, text, body: json });
      });
      response.on('error', reject);
    });
    request.on('error', reject);
    request.end(body);
  });
  return { connector, send, calls };
}

test('Health and authenticated status reveal no API key, connection code, or setup token', async t => {
  const { send } = await fixture(t);
  const health = await send('/health', { token: null });
  assert.equal(health.status, 200);
  assert.deepEqual(health.body, { ok: true, service: 'page-navigator', version: '1.2.0', configured: true });
  const status = await send('/status');
  assert.deepEqual(status.body, { ok: true, configured: true, model: DEFAULT_MODEL });
  for (const secret of [FAKE_KEY, CONNECTION, ADMIN]) assert.ok(!health.text.includes(secret) && !status.text.includes(secret));
});

test('Chat requires the connection bearer and rejects wrong or non-ASCII token values cleanly', async t => {
  const { send, calls } = await fixture(t);
  for (const token of [null, 'x'.repeat(43), 'é'.repeat(43), ADMIN]) {
    const response = await send('/chat', { method: 'POST', body: question(), token });
    assert.equal(response.status, 401); assert.equal(response.body.code, 'unauthorized');
  }
  assert.equal(calls.length, 0);
});

test('Strict Host and Origin checks reject DNS rebinding and ordinary websites even with a bearer', async t => {
  const { send, calls } = await fixture(t);
  const forgedHost = await send('/chat', { method: 'POST', body: question(), headers: { Host: 'evil.example' } });
  assert.equal(forgedHost.status, 403); assert.equal(forgedHost.body.code, 'host');
  for (const origin of ['https://evil.example', 'null', 'chrome-extension://not-an-extension', `${EXTENSION}.evil.example`]) {
    const response = await send('/chat', { method: 'POST', body: question(), origin });
    assert.equal(response.status, 403); assert.equal(response.body.code, 'origin');
    assert.equal(response.headers['access-control-allow-origin'], undefined);
  }
  assert.equal(calls.length, 0);
});

test('Extension preflights allow only the supported method and headers, including private-network requests', async t => {
  const { send } = await fixture(t);
  const headers = { 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'authorization, content-type', 'Access-Control-Request-Private-Network': 'true' };
  const allowed = await send('/chat', { method: 'OPTIONS', token: null, headers });
  assert.equal(allowed.status, 204);
  assert.equal(allowed.headers['access-control-allow-origin'], EXTENSION);
  assert.equal(allowed.headers['access-control-allow-private-network'], 'true');
  assert.equal(allowed.headers['access-control-allow-methods'], 'POST');
  assert.equal((await send('/chat', { method: 'OPTIONS', token: null, headers: { ...headers, 'Access-Control-Request-Headers': 'x-unapproved' } })).status, 403);
  assert.equal((await send('/chat', { method: 'OPTIONS', token: null, headers: { ...headers, 'Access-Control-Request-Method': 'DELETE' } })).status, 405);
});

test('A valid question uses the fixed Responses endpoint, private credentials, bounded structured output, and no stored response', async t => {
  const { send, calls } = await fixture(t);
  const body = question();
  body.context.url = 'https://user:password@example.test/workshop?token=sensitive-query#sensitive-fragment';
  const response = await send('/chat', { method: 'POST', body });
  assert.equal(response.status, 200);
  assert.equal(response.body.answer, 'Applications close on December 12.');
  assert.deepEqual(response.body.citations, [{ blockId: 'b1', quote: 'Applications close on December 12.', label: 'Application deadline' }]);
  assert.deepEqual(response.body.usage, { inputTokens: 120, outputTokens: 30 });
  assert.equal(calls.length, 1); assert.equal(calls[0].url, OPENAI_ENDPOINT);
  const request = calls[0].request;
  assert.equal(request.redirect, 'error'); assert.equal(request.headers.Authorization, `Bearer ${FAKE_KEY}`);
  const api = JSON.parse(request.body);
  assert.equal(api.store, false); assert.equal(api.max_output_tokens, 3000); assert.equal(api.model, DEFAULT_MODEL);
  assert.equal(api.text.format.type, 'json_schema'); assert.equal(api.text.format.strict, true);
  assert.equal(api.text.format.schema.additionalProperties, false);
  assert.equal(api.input[0].role, 'user'); assert.match(api.input[0].content, /UNTRUSTED PAGE REFERENCE/);
  assert.match(api.instructions, /untrusted data/); assert.match(api.instructions, /no tools/);
  assert.equal(api.input.at(-1).content, body.messages[0].content);
  for (const privateText of [FAKE_KEY, 'sensitive-query', 'sensitive-fragment', 'snapshot-1', 'user:password', 'example.test']) assert.ok(!request.body.includes(privateText), privateText);
  assert.ok(!response.text.includes(FAKE_KEY));
});

test('Malformed snapshots, fabricated roles, duplicate blocks, and text/history limits cannot reach OpenAI', async t => {
  const { send, calls } = await fixture(t);
  const invalidBodies = [];
  invalidBodies.push({ messages: question().messages });
  let body = question(); body.context.url = 'javascript:alert(1)'; invalidBodies.push(body);
  body = question(); body.context.blocks[1].id = 'b1'; invalidBodies.push(body);
  body = question(); body.context.characters++; invalidBodies.push(body);
  body = question(); body.context.blocks[0].text = 'a'.repeat(6001); body.context.characters = body.context.blocks.reduce((n, b) => n + b.text.length, 0); invalidBodies.push(body);
  body = question(); body.context.blocks = Array.from({ length: 11 }, (_, i) => ({ id: `b${i}`, text: 'a'.repeat(6000), label: '' })); body.context.characters = 66000; invalidBodies.push(body);
  body = question(); body.context.blocks = Array.from({ length: 201 }, (_, i) => ({ id: `b${i}`, text: 'x', label: '' })); body.context.characters = 201; invalidBodies.push(body);
  body = question(); body.messages[0].role = 'system'; invalidBodies.push(body);
  body = question(); body.messages = [{ role: 'assistant', content: 'No user question' }]; invalidBodies.push(body);
  body = question(); body.messages[0].content = 'a'.repeat(4001); invalidBodies.push(body);
  body = question(); body.messages = Array.from({ length: 13 }, () => ({ role: 'user', content: 'a' })); invalidBodies.push(body);
  body = question(); body.messages = [{ role: 'assistant', content: 'a'.repeat(20000) }, { role: 'user', content: 'More?' }]; invalidBodies.push(body);
  for (const candidate of invalidBodies) {
    const response = await send('/chat', { method: 'POST', body: candidate });
    assert.equal(response.status, 400); assert.equal(response.body.code, 'invalid_request');
  }
  assert.equal(calls.length, 0);
});

test('Invalid JSON, non-JSON content types, and oversized request bodies fail before an upstream call', async t => {
  const { send, calls } = await fixture(t);
  const invalid = await send('/chat', { method: 'POST', raw: '{broken' });
  assert.equal(invalid.status, 400); assert.equal(invalid.body.code, 'invalid_json');
  const wrongType = await send('/chat', { method: 'POST', body: question(), headers: { 'Content-Type': 'text/plain' } });
  assert.equal(wrongType.status, 415);
  const tooBig = await send('/chat', { method: 'POST', raw: 'a'.repeat(512 * 1024 + 1) });
  assert.equal(tooBig.status, 413); assert.equal(tooBig.body.code, 'too_large');
  assert.equal(calls.length, 0);
});

test('Citation validation discards unknown IDs, invented quotations, and duplicate source buttons', async t => {
  const { send } = await fixture(t, { fetchImpl: async () => apiResponse(completed({
    answer: 'There are two relevant details.', citations: [
      { blockId: 'missing', quote: 'Applications close' },
      { blockId: 'b1', quote: 'The deadline is February 50.' },
      { blockId: 'b1', quote: 'Applications close on December 12.' },
      { blockId: 'b1', quote: 'Registration is free.' },
      { blockId: 'b2', quote: 'The workshop begins at 9 a.m. Bring a notebook.' }
    ]
  })) });
  const response = await send('/chat', { method: 'POST', body: question() });
  assert.equal(response.status, 200);
  assert.deepEqual(response.body.citations.map(item => item.blockId), ['b1', 'b2']);
});

test('A refusal, incomplete answer, or malformed model object never appears as a successful answer', async t => {
  const outputs = [
    { status: 'completed', output: [{ type: 'message', content: [{ type: 'refusal', refusal: 'No.' }] }] },
    { ...completed(), status: 'incomplete' },
    { status: 'completed', output: [{ type: 'message', content: [{ type: 'output_text', text: 'not JSON' }] }] },
    completed({ answer: '', citations: [] })
  ];
  const { send } = await fixture(t, { fetchImpl: async () => apiResponse(outputs.shift()) });
  for (const [status, code] of [[422, 'refused'], [502, 'incomplete'], [502, 'invalid_response'], [502, 'invalid_response']]) {
    const response = await send('/chat', { method: 'POST', body: question() });
    assert.equal(response.status, status); assert.equal(response.body.code, code); assert.equal(response.body.answer, undefined);
  }
});

test('Upstream authentication, model, credit, and service failures have safe actionable errors without retries', async t => {
  const statuses = [401, 403, 404, 429, 500]; let calls = 0;
  const { send } = await fixture(t, { fetchImpl: async () => { calls++; return new Response(`private upstream detail ${FAKE_KEY}`, { status: statuses.shift() }); } });
  for (const [status, code] of [[401, 'openai_auth'], [403, 'model_access'], [403, 'model_access'], [429, 'openai_limit'], [502, 'openai_unavailable']]) {
    const response = await send('/chat', { method: 'POST', body: question() });
    assert.equal(response.status, status); assert.equal(response.body.code, code); assert.ok(!response.text.includes(FAKE_KEY));
  }
  assert.equal(calls, 5);
});

test('Network errors cannot leak exception details and the next request can recover', async t => {
  let calls = 0;
  const { send } = await fixture(t, { fetchImpl: async () => { if (++calls === 1) throw new Error(`debug ${FAKE_KEY}`); return apiResponse(); } });
  const failure = await send('/chat', { method: 'POST', body: question() });
  assert.equal(failure.status, 502); assert.equal(failure.body.code, 'network'); assert.ok(!failure.text.includes(FAKE_KEY));
  assert.equal((await send('/chat', { method: 'POST', body: question() })).status, 200);
  assert.equal(calls, 2);
});

test('A request timeout aborts the upstream and releases the active request slot', async t => {
  let calls = 0; let aborted = false;
  const { send } = await fixture(t, { timeoutMs: 25, fetchImpl: async (_url, request) => {
    if (++calls > 1) return apiResponse();
    return new Promise((_resolve, reject) => request.signal.addEventListener('abort', () => { aborted = true; reject(request.signal.reason); }, { once: true }));
  } });
  const failure = await send('/chat', { method: 'POST', body: question() });
  assert.equal(failure.status, 504); assert.equal(failure.body.code, 'timeout'); assert.equal(aborted, true);
  assert.equal((await send('/chat', { method: 'POST', body: question() })).status, 200);
});

test('Closing the client connection aborts its upstream request', async t => {
  const started = gate(); const cancelled = gate();
  const { connector } = await fixture(t, { fetchImpl: async (_url, request) => {
    started.resolve();
    return new Promise((_resolve, reject) => request.signal.addEventListener('abort', () => { cancelled.resolve(); reject(request.signal.reason); }, { once: true }));
  } });
  const body = JSON.stringify(question());
  const request = http.request(`${connector.origin}/chat`, { method: 'POST', headers: { Authorization: `Bearer ${CONNECTION}`, Origin: EXTENSION, 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) } });
  request.on('error', () => {}); request.end(body);
  await started.promise; request.destroy();
  await Promise.race([cancelled.promise, delay(1500).then(() => { throw new Error('Client disconnect did not abort the upstream'); })]);
});

test('Concurrent requests receive a busy response and do not start a second paid request', async t => {
  const pending = gate(); const started = gate(); let calls = 0;
  const { send } = await fixture(t, { fetchImpl: async () => { calls++; started.resolve(); return pending.promise; } });
  const first = send('/chat', { method: 'POST', body: question() });
  await started.promise;
  const second = await send('/chat', { method: 'POST', body: question() });
  assert.equal(second.status, 429); assert.equal(second.body.code, 'busy'); assert.equal(calls, 1);
  pending.resolve(apiResponse()); assert.equal((await first).status, 200);
});

test('The local per-minute request limit rejects excess requests before contacting OpenAI', async t => {
  const { send, calls } = await fixture(t, { requestLimit: 2 });
  assert.equal((await send('/chat', { method: 'POST', body: question() })).status, 200);
  assert.equal((await send('/chat', { method: 'POST', body: question() })).status, 200);
  const third = await send('/chat', { method: 'POST', body: question() });
  assert.equal(third.status, 429); assert.equal(third.body.code, 'local_limit'); assert.ok(Number(third.headers['retry-after']) > 0); assert.equal(calls.length, 2);
});

test('Setup uses a separate administrator token; ordinary extension requests cannot change the key', async t => {
  const { connector, send } = await fixture(t);
  assert.equal((await send('/setup/state', { token: CONNECTION, origin: connector.origin })).status, 401);
  assert.equal((await send('/setup/state', { token: ADMIN, origin: EXTENSION })).status, 401);
  const browserGET = await send('/setup/state', { token: ADMIN, origin: null });
  assert.equal(browserGET.status, 200); assert.equal(browserGET.body.connectionToken, CONNECTION);
  assert.ok(!browserGET.text.includes(FAKE_KEY));
  assert.equal((await send('/setup/state', { token: ADMIN, origin: 'https://evil.example' })).status, 403);
});

test('Local setup can configure and remove a memory-only key without calling OpenAI', async t => {
  const { connector, send, calls } = await fixture(t, { apiKey: '' });
  assert.equal((await send('/status')).body.configured, false);
  assert.equal((await send('/chat', { method: 'POST', body: question() })).body.code, 'not_configured');
  const configured = await send('/setup/config', { method: 'POST', token: ADMIN, origin: connector.origin, body: { apiKey: FAKE_KEY, model: DEFAULT_MODEL } });
  assert.equal(configured.status, 200); assert.equal(configured.body.configured, true); assert.equal(configured.body.sessionOnly, true);
  assert.ok(!configured.text.includes(FAKE_KEY)); assert.equal(calls.length, 0);
  const modelOnly = await send('/setup/config', { method: 'POST', token: ADMIN, origin: connector.origin, body: { model: 'another-model' } });
  assert.equal(modelOnly.status, 200); assert.equal((await send('/status')).body.model, 'another-model');
  const removed = await send('/setup/config', { method: 'DELETE', token: ADMIN, origin: connector.origin });
  assert.equal(removed.body.configured, false); assert.equal((await send('/status')).body.configured, false); assert.equal(calls.length, 0);
});

test('Failed setup validation cannot partially change the configured key or model', async t => {
  const { connector, send, calls } = await fixture(t);
  const response = await send('/setup/config', { method: 'POST', token: ADMIN, origin: connector.origin, body: { apiKey: 'contains spaces in key', model: 'different-model' } });
  assert.equal(response.status, 400);
  assert.equal((await send('/status')).body.model, DEFAULT_MODEL);
  assert.equal((await send('/chat', { method: 'POST', body: question() })).status, 200);
  assert.equal(calls[0].request.headers.Authorization, `Bearer ${FAKE_KEY}`);
});

test('Replacing a connection code revokes the old bearer only after the new code is saved', async t => {
  const saved = [];
  const { connector, send } = await fixture(t, { saveConnectionToken: async value => { saved.push(value); } });
  const result = await send('/setup/reset-connection', { method: 'POST', token: ADMIN, origin: connector.origin });
  assert.equal(result.status, 200); assert.match(result.body.connectionToken, /^[A-Za-z0-9_-]{43}$/);
  assert.deepEqual(saved, [result.body.connectionToken]); assert.notEqual(result.body.connectionToken, CONNECTION);
  assert.equal((await send('/status')).status, 401);
  assert.equal((await send('/status', { token: result.body.connectionToken })).status, 200);
});

test('A connection-code storage failure leaves the existing connection usable', async t => {
  const { connector, send } = await fixture(t, { saveConnectionToken: async () => { throw new Error('Test storage failure'); } });
  const result = await send('/setup/reset-connection', { method: 'POST', token: ADMIN, origin: connector.origin });
  assert.equal(result.status, 500); assert.equal(result.body.code, 'storage'); assert.equal((await send('/status')).status, 200);
});

test('Setup assets are local, cannot be framed, and do not include credentials', async t => {
  const { send } = await fixture(t);
  for (const route of ['/setup', '/setup.js', '/setup.css']) {
    const response = await send(route, { token: null, origin: null });
    assert.equal(response.status, 200); assert.equal(response.headers['cache-control'], 'no-store');
    assert.equal(response.headers['x-frame-options'], 'DENY');
    assert.match(response.headers['content-security-policy'], /script-src 'self'/);
    assert.match(response.headers['content-security-policy'], /frame-ancestors 'none'/);
    for (const secret of [FAKE_KEY, CONNECTION, ADMIN]) assert.ok(!response.text.includes(secret));
  }
  assert.equal((await send('/setup?token=secret', { token: null, origin: null })).status, 400);
  assert.equal((await send('/server.mjs', { token: null, origin: null })).status, 404);
});

test('Connection identity persists outside runtime state and contains no API key', async () => {
  const directory = await mkdtemp(path.join(testDirectory, '.identity-'));
  try {
    const first = await loadConnectionIdentity(directory);
    const second = await loadConnectionIdentity(directory);
    assert.equal(first.token, second.token); assert.match(first.token, /^[A-Za-z0-9_-]{43}$/);
    const file = path.join(directory, 'connection.json');
    const saved = await readFile(file, 'utf8');
    assert.deepEqual(Object.keys(JSON.parse(saved)).sort(), ['connectionToken', 'version']);
    assert.ok(!saved.includes(FAKE_KEY));
    if (process.platform !== 'win32') assert.equal((await stat(file)).mode & 0o777, 0o600);
    await first.save('n'.repeat(43));
    assert.equal((await loadConnectionIdentity(directory)).token, 'n'.repeat(43));
  } finally { await rm(directory, { recursive: true, force: true }); }
});
