import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { createConnector } from '../server.mjs';

const require = createRequire(import.meta.url);
const { PageChatController, CONNECTOR } = require('../../page-navigator/sidepanel.js');

// One integration path across the production sidebar controller and real local
// HTTP server. Chrome messaging and the paid Responses API are mocked. There is
// no browser, credential lookup, or external network access in this test.
test('Sidebar pairs, submits page text through the connector, and jumps to a verified citation', async t => {
  const token = 'c'.repeat(43);
  const admin = 'a'.repeat(43);
  const fakeKey = 'integration-test-not-a-real-api-key';
  const extensionOrigin = `chrome-extension://${'b'.repeat(32)}`;
  const blocks = [{ id: 'b1', text: 'Applications close on December 12. Registration is free.', label: 'Application deadline' }];
  const context = {
    id: 'snapshot-integration', url: 'https://example.test/workshop?secret=local-only#section',
    title: 'Workshop', scope: 'page', capturedAt: Date.now(),
    characters: blocks[0].text.length, truncated: false, blocks
  };
  const upstreamCalls = [];
  const connector = createConnector({
    connectionToken: token, adminToken: admin,
    fetchImpl: async (url, options) => {
      upstreamCalls.push({ url, options });
      return new Response(JSON.stringify({
        status: 'completed',
        output: [{ type: 'message', content: [{ type: 'output_text', text: JSON.stringify({
          answer: 'Applications close on December 12.',
          citations: [
            { blockId: 'b1', quote: 'Applications close on December 12.' },
            { blockId: 'missing', quote: 'A fabricated passage.' }
          ]
        }) }] }],
        usage: { input_tokens: 100, output_tokens: 30 }
      }), { headers: { 'Content-Type': 'application/json' } });
    }
  });
  const origin = await connector.start(0);
  t.after(() => connector.stop());
  const saved = {};
  const contentMessages = [];
  const localRequests = [];
  const chromeApi = {
    storage: { local: {
      get: async () => saved,
      set: async value => Object.assign(saved, value)
    } },
    windows: { getCurrent: async () => ({ id: 1 }) },
    tabs: {
      query: async () => [{ id: 5, windowId: 1 }],
      sendMessage: async (tabId, message, options) => {
        assert.equal(tabId, 5);
        assert.equal(options.frameId, 0);
        contentMessages.push(message);
        if (message.type === 'PN_STATUS') return { ok: true, enabled: true, pageUrl: context.url, pageTitle: context.title };
        if (message.type === 'PN_CONTEXT') return { ok: true, context };
        if (message.type === 'PN_CONTEXT_JUMP') return { ok: true };
        throw new Error(`Unexpected content message: ${message.type}`);
      }
    }
  };
  const controller = new PageChatController({
    chromeApi,
    fetchImpl: async (url, options) => {
      assert.ok(url.startsWith(`${CONNECTOR}/`));
      // Only redirect the fixed loopback port to an isolated ephemeral test port.
      // The production HTTP/auth/payload/response processing is unchanged.
      localRequests.push({ url, options });
      return fetch(url.replace(CONNECTOR, origin), {
        ...options, headers: { ...options.headers, Origin: extensionOrigin }
      });
    }
  });
  t.after(() => controller.dispose());
  await controller.initialize();
  assert.equal(await controller.connect(token), false);
  assert.equal(controller.state.connection.state, 'needs-key');
  assert.equal(upstreamCalls.length, 0);

  const setup = await fetch(`${origin}/setup/config`, {
    method: 'POST', headers: { Authorization: `Bearer ${admin}`, 'Content-Type': 'application/json', Origin: origin },
    body: JSON.stringify({ apiKey: fakeKey })
  });
  assert.equal(setup.status, 200);
  assert.equal(await controller.connect(token), true);
  assert.deepEqual(saved, { pnChatConnection: { token } });
  assert.equal(upstreamCalls.length, 0, 'Setup and pairing must not create paid requests');

  await controller.capture('page');
  assert.equal(controller.state.context.id, context.id);
  controller.setPrompt('When do applications close?');
  await controller.sendQuestion();
  assert.equal(controller.state.chatError, false, controller.state.chatNotice);
  assert.equal(controller.state.chatBusy, false);
  assert.equal(controller.state.prompt, '');
  assert.equal(controller.state.messages.length, 2);
  const answer = controller.state.messages[1];
  assert.equal(answer.role, 'assistant');
  assert.equal(answer.text, 'Applications close on December 12.');
  assert.deepEqual(answer.citations, [{ blockId: 'b1', quote: 'Applications close on December 12.', label: 'Application deadline' }]);

  assert.equal(upstreamCalls.length, 1);
  const upstream = upstreamCalls[0];
  assert.equal(upstream.url, 'https://api.openai.com/v1/responses');
  assert.equal(upstream.options.headers.Authorization, `Bearer ${fakeKey}`);
  const payload = JSON.parse(upstream.options.body);
  assert.equal(payload.store, false);
  assert.equal(payload.text.format.type, 'json_schema');
  assert.ok(payload.input[0].content.includes(blocks[0].text));
  assert.equal(payload.input.at(-1).content, 'When do applications close?');
  assert.ok(!upstream.options.body.includes('local-only'));
  assert.ok(!upstream.options.body.includes(context.id));
  assert.ok(!JSON.stringify(localRequests).includes(fakeKey));

  await controller.jumpToSource(answer.id, 'b1');
  assert.deepEqual(contentMessages.at(-1), { type: 'PN_CONTEXT_JUMP', contextId: context.id, blockId: 'b1' });
  assert.equal(controller.state.contextError, false);
  assert.equal(controller.state.contextNotice, 'Moved to the source passage.');
});
