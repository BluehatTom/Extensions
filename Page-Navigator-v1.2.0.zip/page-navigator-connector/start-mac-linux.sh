#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
if ! command -v node >/dev/null 2>&1; then
  printf '%s\n' 'Install Node.js 22 or later from https://nodejs.org, then start this connector again.'
  exit 1
fi
exec node server.mjs --open
