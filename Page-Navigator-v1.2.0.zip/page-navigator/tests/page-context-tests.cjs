'use strict';
// Production context extraction and source navigation with deterministic DOM/API
// boundaries. These tests do not claim browser rendering or native clipboard QA.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const {webcrypto} = require('node:crypto');
const {FakeNode, FakeElement, FakeRange, FakeHighlight, NodeFilter, text, element, allText, makeDocument} = require('./search-dom-mocks.cjs');
const source = fs.readFileSync(path.join(__dirname, '../content.js'), 'utf8');
const report = [];
const plain = value => JSON.parse(JSON.stringify(value));
function production(name) {
  const match = source.match(new RegExp('^  (?:async )?function ' + name + '\\([^\\n]*\\) \\{[\\s\\S]*?^  \\}', 'm'));
  assert.ok(match, `Missing production function: ${name}`);
  return match[0];
}
class SelectionRange extends FakeRange {
  cloneRange() { const range = new SelectionRange(); range.setStart(this.startContainer, this.startOffset); range.setEnd(this.endContainer, this.endOffset); return range; }
  intersectsNode(node) {
    const nodes = allText(this.startContainer.getRootNode());
    const first = nodes.indexOf(this.startContainer);
    const last = nodes.indexOf(this.endContainer);
    const candidates = node.nodeType === 3 ? [node] : allText(node);
    return candidates.some(item => {
      const index = nodes.indexOf(item);
      return index >= first && index <= last && !(index === first && this.startOffset === item.length) && !(index === last && this.endOffset === 0);
    });
  }
}
function fixture(...nodes) {
  const document = makeDocument(...nodes);
  document.title = 'A useful article';
  document.createRange = () => new SelectionRange();
  const docRoot = document.scrollingElement;
  const host = element('div', {'data-page-navigator': '1'}, 'Extension-only text');
  document.body.append(host);
  const state = {now: 1000, enabled: true, focused: true, root: docRoot, messages: [], scrolls: [], runtime: [], timers: new Map(), nextTimer: 0, yields: 0, reducedMotion: false};
  let selectionRange = null;
  let selectionText = null;
  const selection = {
    isCollapsed: true, rangeCount: 0, anchorNode: null, focusNode: null,
    getRangeAt() { return selectionRange; },
    toString() { return selectionText ?? selectionRange?.toString() ?? ''; }
  };
  document.activeElement = document.body;
  document.hasFocus = () => state.focused;
  let c;
  const rootFor = el => {
    for (let node = el.parentElement; node; node = node.parentElement) if (node.nestedScroll) return node;
    return docRoot;
  };
  const timer = (fn, delay) => {
    const id = ++state.nextTimer;
    state.timers.set(id, {fn, delay});
    if (delay === 0) Promise.resolve().then(() => {
      if (!state.timers.has(id)) return;
      state.timers.delete(id); state.yields++;
      if (state.onYield) state.onYield();
      fn();
    });
    return id;
  };
  docRoot.scrollTo = options => { state.scrolls.push({root: docRoot, ...options}); docRoot.scrollTop = options.top; };
  c = vm.createContext({
    URL, Promise, Number, String, Math, Object, Array, Boolean, Map, Set, WeakMap, Uint32Array, crypto: webcrypto,
    Date: {now: () => state.now}, console, Node: FakeNode, Element: FakeElement, NodeFilter,
    Highlight: FakeHighlight, CSS: {highlights: new Map([['unrelated-page-highlight', 'keep']])},
    document, host, shadow: {activeElement: null}, window: {getSelection: () => selection, scrollTo: options => docRoot.scrollTo(options)},
    location: {href: 'https://example.test/article?edition=1', hostname: 'example.test'},
    MAX_CONTEXT_CHARS: 60000, MAX_CONTEXT_BLOCKS: 200, MAX_CONTEXT_BLOCK_CHARS: 6000, MAX_CONTEXT_NODES: 30000,
    CONTEXT_CACHE_MS: 600000, CONTEXT_HIGHLIGHT: 'page-navigator-source-7f', MAX_SELECTION_CHARS: 200000, SELECTION_CACHE_MS: 120000,
    contextGeneration: 0, contextCacheTimer: null, contextHighlightTimer: null, contextMutationVersions: new WeakMap(), pageContexts: new Map(),
    pageSelection: null, selectionTooLong: false, copyingSelection: false,
    pageIdentity: 'https://example.test/article?edition=1', savedSpot: null, history: [], manualRoot: null, recentRoot: null, activeRoot: docRoot,
    temporarilyHidden: false, forcedVisible: false, scanNeeded: false, headingsDirty: false, lastHeading: null, lastHeadingDestination: null,
    panelOpen: false, collapsed: false, disabledSites: [], searchQuery: '', searchMatches: [], searchIndex: -1, searchBusy: false, searchLimited: false,
    settings: {smooth: true}, innerHeight: 1000,
    setTimeout: timer, clearTimeout: id => state.timers.delete(id),
    enabled: () => state.enabled, pageRoot: () => docRoot, isPage: node => node === docRoot,
    isOwn: node => node === host || host.contains(node), getComputedStyle: el => el.style,
    resolveRoot: () => c.manualRoot || state.root, nearestScrollRoot: rootFor,
    rectFor: root => root === docRoot ? {top: 0} : root.getBoundingClientRect(), stickyOffset: () => 12,
    matchMedia: () => ({matches: state.reducedMotion}), queueRender() {}, renderAreas() {}, clearSearch() {}, loadSpot: async () => {},
    announce: value => state.messages.push(value), $: () => ({value: ''}),
    permittedVisibility: () => state.enabled, rootLabel: () => 'Whole page', headings: () => [],
    chrome: {runtime: {sendMessage(message) { state.runtime.push(plain(message)); return Promise.resolve({ok: true}); }}}
  });
  for (const name of ['identity', 'metrics', 'remember', 'scroll', 'blockForSearch', 'selectionSnapshot', 'clearPageSelection',
    'rememberPageSelection', 'getPageSelection', 'openPageChat', 'clearContextHighlight', 'clearPageContexts', 'prunePageContexts',
    'noteContextMutations', 'contextElementExcluded', 'contextSliceEnd', 'contextInputAllowed', 'contextTargetRange',
    'collectContextBlocks', 'capturePageContext', 'jumpToContext', 'checkRoute', 'status']) {
    vm.runInContext(production(name), c, {filename: 'production/content.js:' + name});
  }
  function select(start, startOffset, end = start, endOffset = end.length, renderedText = null) {
    selectionRange = new SelectionRange(); selectionRange.setStart(start, startOffset); selectionRange.setEnd(end, endOffset);
    selectionText = renderedText; selection.isCollapsed = false; selection.rangeCount = 1; selection.anchorNode = start; selection.focusNode = end;
    return selectionRange;
  }
  function collapse() { selection.isCollapsed = true; selection.rangeCount = 0; selection.anchorNode = selection.focusNode = null; selectionText = ''; }
  function changed(target, type = 'characterData', addedNodes = [], removedNodes = []) { c.noteContextMutations([{target, type, addedNodes, removedNodes}]); }
  return {c, state, document, docRoot, host, select, collapse, changed, selection};
}
async function test(name, fn) {
  try { await fn(); report.push({name, passed: true}); console.log('PASS', name); }
  catch (error) { report.push({name, passed: false, error: error.message}); console.error('FAIL', name, error.stack); }
}
function contents(response) { return response.context.blocks.map(block => block.text).join('\n'); }

(async () => {
  await test('Page capture joins inline text, separates blocks, and includes bounded metadata', async () => {
    const f = fixture(element('h2', {}, 'Requirements'), element('p', {}, 'A ', element('strong', {}, 'useful'), ' passage.'), element('p', {}, 'Another paragraph.'));
    f.document.title = 'T'.repeat(800);
    const response = await f.c.capturePageContext('page');
    assert.equal(response.ok, true); assert.equal(contents(response), 'Requirements\nA useful passage.\nAnother paragraph.');
    assert.equal(response.context.title.length, 500); assert.equal(response.context.characters, 47);
    assert.equal(response.context.scope, 'page'); assert.equal(response.context.truncated, false);
    assert.match(response.context.id, /^[0-9a-f]{32}$/); assert.equal(response.context.blocks[1].label, 'Requirements');
    assert.equal(JSON.stringify(response).includes('parentNode'), false); assert.equal(f.state.runtime.length, 0);
  });
  await test('Page capture excludes hidden, form, editor, embedded, script, graphic, and extension content', async () => {
    const hidden = ['script', 'style', 'noscript', 'template', 'textarea', 'input', 'select', 'iframe', 'object', 'embed', 'canvas', 'svg', 'button'].map(tag => element(tag, {}, 'DO NOT SHARE'));
    const f = fixture(element('p', {}, 'Public text'), ...hidden, element('p', {hidden: ''}, 'hidden'), element('p', {'aria-hidden': 'true'}, 'aria'),
      element('div', {contenteditable: 'true'}, 'editor'), element('div', {role: 'textbox'}, 'custom editor'),
      element('p', {style: {opacity: '0'}}, 'transparent'), element('p', {style: {visibility: 'hidden'}}, 'invisible'), element('p', {style: {contentVisibility: 'hidden'}}, 'contained'));
    const response = await f.c.capturePageContext('page');
    assert.equal(response.ok, true); assert.equal(contents(response), 'Public text');
  });
  await test('Current scrolling area excludes other descendant panels but permits scrollable ancestors', async () => {
    const passage = element('p', {}, 'Inside chosen panel'); passage.box.top = 500;
    const inner = element('main', {style: {overflowY: 'auto'}}, passage); inner.nestedScroll = true; inner.box.top = 50;
    const sibling = element('aside', {style: {overflowY: 'auto'}}, element('p', {}, 'Other panel')); sibling.nestedScroll = true;
    const wrapper = element('section', {style: {overflowY: 'auto'}}, element('p', {}, 'Outer panel'), inner, sibling); wrapper.nestedScroll = true;
    const f = fixture(wrapper, element('p', {}, 'Whole page'));
    inner.scrollTo = options => { inner.scrollTop = options.top; f.state.scrolls.push({root: inner, ...options}); };
    f.state.root = inner;
    const response = await f.c.capturePageContext('page');
    assert.equal(response.ok, true); assert.equal(contents(response), 'Inside chosen panel');
    assert.equal(f.c.jumpToContext(response.context.id, 'b1').ok, true);
    assert.equal(f.state.scrolls[0].root, inner); assert.equal(f.state.scrolls[0].top, 438);
    assert.equal(f.docRoot.scrollTop, 0); assert.equal(wrapper.scrollTop, 0);
    f.c.manualRoot = null; f.state.root = f.docRoot;
    assert.equal(contents(await f.c.capturePageContext('page')), 'Whole page');
  });
  await test('Large text is split at 6000 characters and the page budget is explicitly truncated', async () => {
    const f = fixture(element('p', {}, 'A'.repeat(65000)));
    const response = await f.c.capturePageContext('page');
    assert.equal(response.ok, true); assert.equal(response.context.characters, 60000); assert.equal(response.context.blocks.length, 10);
    assert.ok(response.context.blocks.every(block => block.text.length <= 6000)); assert.equal(response.context.truncated, true);
  });
  await test('Chunk and total limits preserve Unicode surrogate pairs', async () => {
    const passage = 'a'.repeat(5999) + '😀' + 'b'.repeat(54001);
    const f = fixture(element('p', {}, passage));
    const response = await f.c.capturePageContext('page');
    assert.equal(response.ok, true); assert.equal(response.context.truncated, true);
    assert.ok(response.context.blocks.every(block => !/[\uD800-\uDBFF]$/.test(block.text) && !/^[\uDC00-\uDFFF]/.test(block.text)));
    assert.ok(contents(response).includes('😀')); assert.ok(response.context.characters <= 60000);
  });
  await test('Block and traversal budgets remain bounded, including empty or rejected nodes', async () => {
    const f = fixture(...Array.from({length: 205}, (_, i) => element('p', {}, `Paragraph ${i}`)));
    const response = await f.c.capturePageContext('page');
    assert.equal(response.context.blocks.length, 200); assert.equal(response.context.truncated, true);
    const limited = fixture(element('p', {}, 'First passage'), ...Array.from({length: 30}, () => element('span', {hidden: ''}, 'Secret')));
    limited.c.MAX_CONTEXT_NODES = 10;
    const result = await limited.c.capturePageContext('page');
    assert.equal(contents(result), 'First passage'); assert.equal(result.context.truncated, true);
  });
  await test('An empty or unsupported context fails without manufacturing page content', async () => {
    const f = fixture(element('textarea', {}, 'Private initial value'));
    assert.equal((await f.c.capturePageContext('page')).ok, false);
    assert.equal((await f.c.capturePageContext('everything')).ok, false);
    assert.equal((await f.c.capturePageContext('selection')).ok, false);
    assert.equal(f.c.pageContexts.size, 0);
  });
  await test('Selection captures only the chosen text across inline nodes and survives sidebar focus', async () => {
    const a = text('before SELECT'), b = text('ED after');
    const f = fixture(element('p', {}, a, element('strong', {}, b)), element('p', {}, 'Not selected'));
    f.select(a, 7, b, 2); f.c.rememberPageSelection(); f.state.focused = false; f.collapse();
    const response = await f.c.capturePageContext('selection');
    assert.equal(response.ok, true); assert.equal(contents(response), 'SELECTED'); assert.equal(response.context.scope, 'selection');
    assert.equal(f.c.jumpToContext(response.context.id, 'b1').ok, true);
    const range = [...f.c.CSS.highlights.get('page-navigator-source-7f')][0];
    assert.equal(range.toString(), 'SELECTED');
  });
  await test('Selected paragraphs retain separate source blocks despite rendered line breaks', async () => {
    const a = text('First paragraph'), b = text('Second paragraph');
    const f = fixture(element('p', {}, a), element('p', {}, b));
    f.select(a, 0, b, b.length, 'First paragraph\n\nSecond paragraph');
    const response = await f.c.capturePageContext('selection');
    assert.equal(response.ok, true); assert.equal(response.context.blocks.length, 2);
    assert.equal(contents(response), 'First paragraph\nSecond paragraph');
  });
  await test('Selection mode permits explicitly chosen editable text while page mode excludes it', async () => {
    const selected = text('Chosen draft');
    const f = fixture(element('div', {contenteditable: 'true'}, selected), element('p', {}, 'Article'));
    assert.equal(contents(await f.c.capturePageContext('page')), 'Article');
    f.select(selected, 0);
    assert.equal(contents(await f.c.capturePageContext('selection')), 'Chosen draft');
  });
  await test('Input selections share only the selected value and map each chunk to its own offsets', async () => {
    const field = element('textarea', {}); field.value = 'private:' + 'x'.repeat(6500) + ':private'; field.selectionStart = 8; field.selectionEnd = 6508;
    const f = fixture(field); f.document.activeElement = field;
    field.setSelectionRange = (start, end) => { field.lastSelection = [start, end]; };
    const response = await f.c.capturePageContext('selection');
    assert.equal(response.ok, true); assert.equal(response.context.characters, 6500); assert.equal(response.context.blocks.length, 2);
    assert.ok(!contents(response).includes('private'));
    assert.equal(f.c.jumpToContext(response.context.id, 'b2').ok, true); assert.deepEqual(field.lastSelection, [6008, 6508]);
  });
  await test('Password fields are never read, including a field changed after context capture', async () => {
    const field = element('input', {}); field.type = 'text'; field.value = 'selected'; field.selectionStart = 0; field.selectionEnd = 8;
    const f = fixture(field); f.document.activeElement = field;
    const response = await f.c.capturePageContext('selection'); assert.equal(response.ok, true);
    field.type = 'password'; Object.defineProperty(field, 'value', {get() { throw new Error('Password value read'); }});
    assert.equal(f.c.jumpToContext(response.context.id, 'b1').ok, false);
    assert.equal((await f.c.capturePageContext('selection')).ok, false);
    assert.equal(contents(await (async () => { const publicText = element('p', {}, 'Article'); f.document.body.append(publicText); return f.c.capturePageContext('page'); })()), 'Article');
  });
  await test('Cached selection mutations, detachment, and expiry prevent stale text sharing', async () => {
    for (const change of ['mutation', 'detach', 'expire']) {
      const node = text('Selected words'); const f = fixture(element('p', {}, node)); f.select(node, 0); f.c.rememberPageSelection();
      f.state.focused = false; f.collapse();
      if (change === 'mutation') { node.textContent = 'Changed words'; f.changed(node); }
      if (change === 'detach') node.isConnected = false;
      if (change === 'expire') f.state.now += 120001;
      assert.equal((await f.c.capturePageContext('selection')).ok, false, change); assert.equal(f.c.pageContexts.size, 0);
    }
  });
  await test('Source jumps accept only the originating snapshot and known block identifiers', async () => {
    const f = fixture(element('p', {}, 'Cited passage'));
    const response = await f.c.capturePageContext('page');
    assert.equal(f.c.jumpToContext('other-snapshot', 'b1').ok, false);
    assert.equal(f.c.jumpToContext(response.context.id, 'body').ok, false);
    assert.equal(f.c.jumpToContext(response.context.id, {selector: 'body'}).ok, false);
    assert.equal(f.state.scrolls.length, 0);
    assert.equal(f.c.jumpToContext(response.context.id, 'b1').ok, true);
    assert.equal(f.c.CSS.highlights.get('unrelated-page-highlight'), 'keep');
    assert.equal(f.c.CSS.highlights.get('page-navigator-source-7f').priority, 2);
  });
  await test('Source navigation honors reduced motion through the existing scroll controls', async () => {
    const f = fixture(element('p', {}, 'Cited passage')); f.state.reducedMotion = true;
    const response = await f.c.capturePageContext('page'); f.c.jumpToContext(response.context.id, 'b1');
    assert.equal(f.state.scrolls[0].behavior, 'instant'); assert.equal(f.c.history.length, 1);
  });
  await test('Changed, newly inserted, hidden, moved, or detached source targets cannot be reused', async () => {
    for (const kind of ['changed', 'inserted', 'hidden', 'moved', 'detached']) {
      const node = text('Original passage'); const paragraph = element('p', {}, node); const f = fixture(paragraph);
      const response = await f.c.capturePageContext('page');
      if (kind === 'changed') node.textContent = 'Changed passage';
      if (kind === 'inserted') { const inserted = text('New '); paragraph.append(inserted); f.changed(paragraph, 'childList', [inserted]); }
      if (kind === 'hidden') paragraph.style.display = 'none';
      if (kind === 'moved') { const other = element('section', {}); f.document.body.append(other); other.append(paragraph); }
      if (kind === 'detached') node.isConnected = false;
      assert.equal(f.c.jumpToContext(response.context.id, 'b1').ok, false, kind); assert.equal(f.state.scrolls.length, 0);
    }
  });
  await test('Ordinary anchor changes preserve context while route/query changes invalidate it', async () => {
    const f = fixture(element('p', {}, 'Route passage'));
    const response = await f.c.capturePageContext('page');
    f.c.location.href += '#heading'; await f.c.checkRoute(); assert.equal(f.c.jumpToContext(response.context.id, 'b1').ok, true);
    f.c.location.href = 'https://example.test/article?edition=2'; await f.c.checkRoute();
    assert.equal(f.c.pageContexts.size, 0); assert.equal(f.c.jumpToContext(response.context.id, 'b1').ok, false);
    assert.equal(f.c.CSS.highlights.has('page-navigator-source-7f'), false);
  });
  await test('The source cache retains at most four snapshots and expires them after ten minutes', async () => {
    const f = fixture(element('p', {}, 'Source passage')); const ids = [];
    for (let i = 0; i < 5; i++) ids.push((await f.c.capturePageContext('page')).context.id);
    assert.equal(new Set(ids).size, 5); assert.equal(f.c.pageContexts.size, 4);
    assert.equal(f.c.jumpToContext(ids[0], 'b1').ok, false);
    f.state.now += 600001; f.c.prunePageContexts();
    assert.equal(f.c.pageContexts.size, 0); assert.equal(f.c.contextCacheTimer, null);
  });
  await test('Disabling navigation blocks capture and source jumps; clearing removes cached references', async () => {
    const f = fixture(element('p', {}, 'Source passage')); const response = await f.c.capturePageContext('page');
    f.state.enabled = false;
    assert.equal((await f.c.capturePageContext('page')).ok, false); assert.equal(f.c.jumpToContext(response.context.id, 'b1').ok, false);
    f.c.clearPageContexts(); assert.equal(f.c.pageContexts.size, 0);
    assert.match(source, /if \(!enabled\(\)\) \{ clearSearch\(\); clearPageSelection\(\); clearPageContexts\(\); \}/);
  });
  await test('A page change during an asynchronous capture cannot return or cache stale context', async () => {
    const f = fixture(...Array.from({length: 150}, (_, i) => element('p', {}, `Item ${i}`)));
    f.state.onYield = () => { f.c.location.href = 'https://example.test/another'; };
    const response = await f.c.capturePageContext('page');
    assert.equal(response.ok, false); assert.equal(f.c.pageContexts.size, 0); assert.ok(f.state.yields > 0);
  });
  await test('A superseded capture cannot replace a newer context snapshot', async () => {
    const f = fixture(...Array.from({length: 150}, (_, i) => element('p', {}, `Item ${i}`)));
    let newer;
    f.state.onYield = () => { f.state.onYield = null; f.c.contextGeneration++; newer = true; };
    const response = await f.c.capturePageContext('page');
    assert.equal(newer, true); assert.equal(response.ok, false); assert.equal(f.c.pageContexts.size, 0);
  });
  await test('Page chat opening sends its runtime request synchronously without page text', async () => {
    const f = fixture(element('p', {}, 'Private page text'));
    f.c.openPageChat();
    assert.deepEqual(f.state.runtime, [{type: 'PN_OPEN_CHAT'}]);
    assert.match(source, /if \(button\.dataset\.action === 'open-page-chat'\) \{ openPageChat\(\); return; \}/);
  });
  await test('Page status exposes route identity and title without tab metadata permissions', () => {
    const f = fixture(); f.c.location.href += '#ordinary-anchor'; f.document.title = 'T'.repeat(501);
    const status = f.c.status();
    assert.equal(status.pageUrl, 'https://example.test/article?edition=1'); assert.equal(status.pageTitle.length, 500);
    assert.match(source, /message\.type === 'PN_CONTEXT'/); assert.match(source, /message\.type === 'PN_CONTEXT_JUMP'/);
  });
  const passed = report.filter(item => item.passed).length;
  const failed = report.length - passed;
  console.log(`\n${passed} page context tests passed, ${failed} failed.`);
  console.log('Scope: production functions with mocked DOM/layout/Chrome boundaries; real browser rendering not executed.');
  process.exitCode = failed ? 1 : 0;
})().catch(error => { console.error(error); process.exitCode = 1; });
