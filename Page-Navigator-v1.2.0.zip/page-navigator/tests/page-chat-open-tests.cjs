'use strict';
// Production background code with Chrome's window-opening boundary mocked.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname, '../background.js'), 'utf8');
function fixture(options = {}) {
  const trace = [];
  const listeners = {};
  const chrome = {
    runtime: {id: 'own-extension', onMessage: {addListener: fn => {listeners.message = fn;}}},
    windows: {onRemoved: {addListener() {}}},
    commands: {onCommand: {addListener: fn => {listeners.command = fn;}}},
    sidePanel: options.unavailable ? undefined : {open(args) {trace.push(['open', args.tabId]); return options.failure ? Promise.reject(new Error(options.failure)) : Promise.resolve();}},
    tabs: {async query() {trace.push(['query']); return [{id: 42, windowId: 3}];}},
    action: {async setBadgeText() {}, async setTitle() {}, async setBadgeBackgroundColor() {}}
  };
  vm.runInNewContext(source, {chrome, URL, console, setTimeout, clearTimeout}, {filename: 'background.js'});
  return {trace, listeners, request(message, sender = {id: chrome.runtime.id}) {
    return new Promise(resolve => listeners.message(message, sender, resolve));
  }};
}
(async () => {
  let count = 0;
  async function test(name, fn) {await fn(); count++; console.log('PASS', name);}
  await test('Side panel open is called synchronously before replying to the user gesture', async () => {
    const f = fixture(); const pending = f.request({type: 'PN_OPEN_CHAT', tabId: 42});
    assert.deepEqual(f.trace, [['open', 42]]); assert.equal((await pending).ok, true);
  });
  await test('A content-script sender cannot redirect the panel to an unrelated tab', async () => {
    const f = fixture(); await f.request({type: 'PN_OPEN_CHAT', tabId: 999}, {id: 'own-extension', tab: {id: 7}});
    assert.deepEqual(f.trace, [['open', 7]]);
  });
  await test('Invalid tab IDs and foreign senders never open a panel', async () => {
    const f = fixture();
    for (const tabId of [-1, null, '42', NaN, undefined]) assert.equal((await f.request({type: 'PN_OPEN_CHAT', tabId})).ok, false);
    assert.equal((await f.request({type: 'PN_OPEN_CHAT', tabId: 42}, {id: 'other-extension'})).ok, false);
    assert.deepEqual(f.trace, []);
  });
  await test('Missing side-panel support returns a useful Chrome version message', async () => {
    const result = await fixture({unavailable: true}).request({type: 'PN_OPEN_CHAT', tabId: 42});
    assert.equal(result.ok, false); assert.match(result.error, /Chrome 116/);
  });
  await test('A denied user gesture is reported instead of claiming success', async () => {
    const result = await fixture({failure: 'User gesture required'}).request({type: 'PN_OPEN_CHAT', tabId: 42});
    assert.equal(result.ok, false); assert.match(result.error, /User gesture/);
  });
  await test('Keyboard command uses Chrome-provided tab without a preliminary asynchronous query', async () => {
    const f = fixture(); const pending = f.listeners.command('open-page-chat', {id: 9, windowId: 3});
    assert.deepEqual(f.trace, [['open', 9]]); await pending;
  });
  await test('Keyboard command can fall back to the active tab on Chrome variants without a tab argument', async () => {
    const f = fixture(); await f.listeners.command('open-page-chat');
    assert.deepEqual(f.trace, [['query'], ['open', 42]]);
  });
  console.log(`${count} page-chat opening checks passed. Native Chrome activation remains unverified.`);
})().catch(error => {console.error(error); process.exitCode = 1;});
