'use strict';
// Actual sidebar controller and renderer with mocked Chrome/fetch/DOM boundaries.
// No real browser, clipboard, or OpenAI request is involved.
const assert = require('node:assert/strict');
const {PageChatController,canonicalPage,validateContext,safeCitations,recentMessages,renderMarkdown,CONNECTOR,CHAT_TIMEOUT_MS} = require('../sidepanel.js');
const TOKEN = 'c'.repeat(64);
const fixtures = [];
const report = [];
const clone = value => JSON.parse(JSON.stringify(value));
function gate() { let resolve,reject; const promise = new Promise((a,b) => { resolve = a; reject = b; }); return {promise,resolve,reject}; }
const response = (body,status = 200) => ({ok: status >= 200 && status < 300,status,async text() { return JSON.stringify(body); }});
const text = 'Applications close on 30 November. Eligible students may apply online.';
function context(overrides = {}) { return {id: 'snapshot-1',url: 'https://example.test/article',title: 'Example reading',scope: 'page',capturedAt: Date.now(),characters: text.length,truncated: false,blocks: [{id: 'b1',text,label: 'Eligibility'}],...overrides}; }
async function until(check) { for (let i = 0; i < 80; i++) { if (check()) return; await new Promise(resolve => setImmediate(resolve)); } assert.ok(check(),'Expected asynchronous boundary was not reached'); }

function fixture({scheduler} = {}) {
  const calls = {messages: [],fetch: [],writes: [],removes: [],queries: []};
  const hooks = {};
  const saved = {};
  const source = {tab: {id: 10,windowId: 4},status: {ok: true,pageUrl: 'https://example.test/article',pageTitle: 'Example reading',hostname: 'example.test',disabledOnSite: false,searchQuery: '',searchCount: 0,searchIndex: 0,searchBusy: false,searchLimited: false},context: context(),configured: true};
  const chrome = {
    windows: {async getCurrent() { return {id: 4}; }},
    storage: {local: {
      async get() { return clone(saved); },
      async set(value) { calls.writes.push(clone(value)); if (hooks.storageFailure) throw new Error('Disk unavailable'); Object.assign(saved,value); },
      async remove(key) { calls.removes.push(key); delete saved[key]; }
    }},
    tabs: {
      async query(query) { calls.queries.push({...query}); return source.tab ? [{...source.tab}] : []; },
      async sendMessage(tabId,message,options) {
        calls.messages.push({tabId,message: clone(message),options: clone(options)});
        if (message.type === 'PN_STATUS') return hooks.status ? hooks.status(tabId,message) : clone(source.status);
        if (message.type === 'PN_CONTEXT') return hooks.context ? hooks.context(tabId,message) : {ok: true,context: {...clone(source.context),scope: message.scope}};
        if (message.type === 'PN_CONTEXT_JUMP') return hooks.jump ? hooks.jump(tabId,message) : {ok: true};
        if (message.type === 'PN_ACTION') {
          if (hooks.action) return hooks.action(tabId,message);
          if (message.action === 'search') Object.assign(source.status,{searchQuery: message.value,searchCount: 3,searchIndex: 1});
          if (message.action === 'clear-search') Object.assign(source.status,{searchQuery: '',searchCount: 0,searchIndex: 0});
          if (message.action === 'next-match') source.status.searchIndex = source.status.searchIndex % Math.max(1,source.status.searchCount) + 1;
          if (message.action === 'previous-match') source.status.searchIndex = source.status.searchIndex <= 1 ? source.status.searchCount : source.status.searchIndex - 1;
          return clone(source.status);
        }
        throw new Error('Unexpected content request');
      }
    }
  };
  const fetchImpl = async (url,options) => {
    const call = {url,options}; calls.fetch.push(call);
    if (url.endsWith('/status')) return hooks.connection ? hooks.connection(call) : response({ok: true,configured: source.configured,model: 'gpt-5.4-mini'});
    if (url.endsWith('/chat')) return hooks.chat ? hooks.chat(call) : response({ok: true,answer: 'The deadline is **30 November**.',citations: [{blockId: 'b1',quote: 'Applications close on 30 November.',label: 'Server label'}],model: 'gpt-5.4-mini',usage: {inputTokens: 10,outputTokens: 20}});
    throw new Error('Unexpected URL');
  };
  const notices = [];
  const controller = new PageChatController({chromeApi: chrome,fetchImpl,notify: (_,kind) => notices.push(kind),...(scheduler ? {setTimer: scheduler.set,clearTimer: scheduler.clear} : {})});
  const result = {controller,calls,hooks,source,saved,notices,async ready() { await controller.initialize(); await controller.connect(TOKEN); await controller.capture('page'); },cleanup() { controller.dispose(); }};
  fixtures.push(result); return result;
}

function timers() {
  const jobs = new Map(); let next = 1;
  return {set(fn,ms) { const id = next++; jobs.set(id,{fn,ms}); return id; },clear(id) { jobs.delete(id); },fire(ms) { for (const [id,job] of [...jobs]) if (job.ms === ms) { jobs.delete(id); job.fn(); } },jobs};
}

class Node {
  constructor(tag = '#text',value = '') { this.tagName = tag; this.value = value; this.children = []; this.attributes = {}; }
  append(...nodes) { this.children.push(...nodes); }
  setAttribute(name,value) { this.attributes[name] = value; }
  set textContent(value) { this.value = String(value); this.children = []; }
  get textContent() { return this.value + this.children.map(child => child.textContent).join(''); }
  set innerHTML(_) { throw new Error('Unsafe HTML insertion'); }
}
const fakeDocument = {createElement: tag => new Node(tag),createTextNode: value => new Node('#text',String(value))};
function nodes(root,tag) { return [...(root.tagName === tag ? [root] : []),...root.children.flatMap(child => nodes(child,tag))]; }

async function test(name,run) {
  let timeout;
  try {
    await Promise.race([run(),new Promise((_,reject) => { timeout = setTimeout(() => reject(new Error('Test timed out')),2000); })]);
    report.push({name,passed: true}); console.log('PASS',name);
  } catch (error) { report.push({name,passed: false}); console.error('FAIL',name,error.stack); }
  finally { clearTimeout(timeout); }
}

(async () => {
  await test('Page identity and title come from the content script without broad tab access',async () => {
    const f = fixture(); await f.controller.initialize();
    assert.equal(f.source.tab.url,undefined); assert.equal(f.source.tab.title,undefined);
    assert.equal(f.controller.state.page.url,'https://example.test/article'); assert.equal(f.controller.state.page.title,'Example reading');
    assert.deepEqual(f.calls.queries[0],{active: true,windowId: 4});
    assert.equal(canonicalPage('https://example.test/article#heading'),'https://example.test/article');
    assert.equal(canonicalPage('https://example.test/article#/next'),'https://example.test/article#/next');
    assert.equal(canonicalPage('javascript:alert(1)'),'');
  });

  await test('Page and selection capture stay local until an explicit question is sent',async () => {
    const f = fixture(); await f.ready(); await f.controller.capture('selection');
    assert.equal(f.controller.state.context.scope,'selection');
    assert.equal(f.calls.fetch.filter(call => call.url.endsWith('/chat')).length,0);
    assert.deepEqual(f.calls.writes,[{pnChatConnection: {token: TOKEN}}]);
    assert.ok(f.calls.messages.some(call => call.message.type === 'PN_CONTEXT' && call.message.scope === 'selection'));
  });

  await test('Context validation rejects unsafe URLs, duplicate source IDs, empty and oversized passages',async () => {
    const valid = validateContext(context({characters: 1,truncated: true})); assert.equal(valid.characters,text.length); assert.equal(valid.truncated,true);
    assert.throws(() => validateContext(context({url: 'javascript:alert(1)'})));
    assert.throws(() => validateContext(context({blocks: [{id: 'b1',text,label: ''},{id: 'b1',text,label: ''}]})));
    assert.throws(() => validateContext(context({blocks: [{id: 'b1',text: ' ',label: ''}]})));
    assert.throws(() => validateContext(context({blocks: [{id: 'b1',text: 'x'.repeat(6001),label: ''}]})));
    assert.throws(() => validateContext(context({scope: 'page'}),'selection'));
    assert.ok(Object.isFrozen(valid)); assert.ok(Object.isFrozen(valid.blocks[0]));
  });

  await test('Restricted and disabled pages cannot provide context or navigation actions',async () => {
    const f = fixture(); f.source.status = {ok: false,error: 'Restricted page'}; await f.controller.initialize();
    await f.controller.capture('page'); await f.controller.navigate('end'); assert.equal(f.controller.state.context,null);
    assert.equal(f.calls.messages.some(call => ['PN_CONTEXT','PN_ACTION'].includes(call.message.type)),false);
    const g = fixture(); g.source.status.disabledOnSite = true; await g.controller.initialize(); await g.controller.capture('selection'); assert.equal(g.controller.available(),false);
  });

  await test('Slow status checks are shared with polling so context capture cannot be starved',async () => {
    const f = fixture(); await f.controller.initialize(); const waiting = gate(); let reads = 0;
    f.hooks.status = async () => { reads++; return waiting.promise; };
    const capture = f.controller.capture('page'); await until(() => reads === 1);
    const polls = Array.from({length: 8},() => f.controller.refreshActive());
    assert.equal(reads,1); waiting.resolve(clone(f.source.status)); await capture; await Promise.all(polls);
    assert.equal(f.controller.state.capturing,false); assert.equal(f.controller.state.context.id,'snapshot-1'); assert.match(f.controller.state.contextNotice,/ready/);
  });

  await test('Polling shares the delayed pre-send check and the question still completes once',async () => {
    const f = fixture(); await f.ready(); const waiting = gate(); let reads = 0;
    f.hooks.status = async () => { reads++; return waiting.promise; };
    f.controller.setPrompt('What is the deadline?'); const task = f.controller.sendQuestion(); await until(() => reads === 1);
    const polls = Array.from({length: 7},() => f.controller.refreshActive()); assert.equal(reads,1);
    waiting.resolve(clone(f.source.status)); await task; await Promise.all(polls);
    assert.equal(f.calls.fetch.filter(call => call.url.endsWith('/chat')).length,1);
    assert.equal(f.controller.state.messages.length,2); assert.equal(f.controller.state.messages[0].status,'complete'); assert.equal(f.controller.state.chatBusy,false);
  });

  await test('A capture that finishes after switching tabs cannot attach old page text',async () => {
    const f = fixture(); await f.ready(); const waiting = gate(); f.hooks.context = () => waiting.promise;
    const capture = f.controller.capture('selection'); await until(() => f.controller.state.capturing && f.calls.messages.filter(call => call.message.type === 'PN_CONTEXT').length === 2);
    f.source.tab = {id: 11,windowId: 4}; f.source.status.pageUrl = 'https://example.test/second'; f.source.status.pageTitle = 'Second page';
    await f.controller.refreshActive({force: true}); waiting.resolve({ok: true,context: context({scope: 'selection'})}); await capture;
    assert.equal(f.controller.state.context,null); assert.equal(f.controller.state.page.title,'Second page'); assert.equal(f.controller.state.capturing,false);
  });

  await test('A sent question includes only its chosen snapshot and retains verified source links',async () => {
    const f = fixture(); await f.ready(); f.controller.setPrompt('What is the deadline?'); await f.controller.sendQuestion();
    const call = f.calls.fetch.find(call => call.url.endsWith('/chat')); const sent = JSON.parse(call.options.body);
    assert.equal(call.url,`${CONNECTOR}/chat`); assert.equal(call.options.headers.Authorization,`Bearer ${TOKEN}`);
    assert.equal(sent.context.id,'snapshot-1'); assert.deepEqual(sent.messages,[{role: 'user',content: 'What is the deadline?'}]);
    assert.equal(f.controller.state.prompt,''); assert.equal(f.controller.state.messages.length,2);
    assert.deepEqual(f.controller.state.messages[1].citations,[{blockId: 'b1',quote: 'Applications close on 30 November.',label: 'Eligibility'}]);
    assert.equal(f.calls.writes.length,1,'Only the connection code is persisted');
  });

  await test('Rapid repeated Send actions create only one local request',async () => {
    const f = fixture(); await f.ready(); const waiting = gate(); f.hooks.chat = () => waiting.promise;
    f.controller.setPrompt('Explain this.'); const first = f.controller.sendQuestion(); const second = f.controller.sendQuestion();
    await until(() => f.calls.fetch.some(call => call.url.endsWith('/chat'))); assert.equal(f.calls.fetch.filter(call => call.url.endsWith('/chat')).length,1);
    waiting.resolve(response({ok: true,answer: 'An explanation.',citations: []})); await Promise.all([first,second]); assert.equal(f.controller.state.messages.length,2);
  });

  await test('Failed answers preserve the question and do not add false assistant messages or retries',async () => {
    const f = fixture(); await f.ready(); f.hooks.chat = async () => response({ok: false,error: 'API credits are exhausted.'},429);
    f.controller.setPrompt('Explain the eligibility.'); await f.controller.sendQuestion();
    assert.equal(f.controller.state.prompt,'Explain the eligibility.'); assert.equal(f.controller.state.messages.length,0); assert.equal(f.controller.state.chatBusy,false); assert.match(f.controller.state.chatNotice,/credits/);
    assert.equal(f.calls.fetch.filter(call => call.url.endsWith('/chat')).length,1);
  });

  await test('Stop aborts the fetch and late answers cannot enter the conversation',async () => {
    const f = fixture(); await f.ready(); const waiting = gate(); f.hooks.chat = () => waiting.promise;
    f.controller.setPrompt('Summarize this.'); const task = f.controller.sendQuestion(); await until(() => f.calls.fetch.some(call => call.url.endsWith('/chat')));
    const call = f.calls.fetch.find(call => call.url.endsWith('/chat')); f.controller.cancelChat(); assert.equal(call.options.signal.aborted,true);
    waiting.resolve(response({ok: true,answer: 'Late answer',citations: []})); await task;
    assert.equal(f.controller.state.messages.length,0); assert.equal(f.controller.state.prompt,'Summarize this.'); assert.equal(f.controller.state.chatBusy,false);
  });

  await test('Changing tabs aborts a pending question and clears page-specific text and chat',async () => {
    const f = fixture(); await f.ready(); const waiting = gate(); f.hooks.chat = () => waiting.promise;
    f.controller.setPrompt('What does this mean?'); const task = f.controller.sendQuestion(); await until(() => f.calls.fetch.some(call => call.url.endsWith('/chat')));
    const call = f.calls.fetch.find(call => call.url.endsWith('/chat'));
    f.source.tab = {id: 12,windowId: 4}; f.source.status.pageUrl = 'https://example.test/new'; f.source.status.pageTitle = 'New page'; await f.controller.refreshActive({force: true});
    assert.equal(call.options.signal.aborted,true); waiting.resolve(response({ok: true,answer: 'Old page answer',citations: []})); await task;
    assert.equal(f.controller.state.page.title,'New page'); assert.equal(f.controller.state.context,null); assert.equal(f.controller.state.messages.length,0); assert.equal(f.controller.state.prompt,'');
  });

  await test('A route change without a tab event is detected before an answer is displayed',async () => {
    const f = fixture(); await f.ready(); const waiting = gate(); f.hooks.chat = () => waiting.promise;
    f.controller.setPrompt('Summarize.'); const task = f.controller.sendQuestion(); await until(() => f.calls.fetch.some(call => call.url.endsWith('/chat')));
    f.source.status.pageUrl = 'https://example.test/article#/other'; f.source.status.pageTitle = 'Other route';
    waiting.resolve(response({ok: true,answer: 'Answer for previous route',citations: []})); await task;
    assert.equal(f.controller.state.context,null); assert.equal(f.controller.state.messages.length,0); assert.equal(f.controller.state.page.title,'Other route');
  });

  await test('A different page is detected before submission and is never silently uploaded',async () => {
    const f = fixture(); await f.ready(); f.source.status.pageUrl = 'https://example.test/elsewhere';
    f.controller.setPrompt('Tell me about this.'); await f.controller.sendQuestion();
    assert.equal(f.calls.fetch.some(call => call.url.endsWith('/chat')),false); assert.equal(f.controller.state.context,null);
  });

  await test('Changing the attached text starts new model context while old sources retain their snapshot',async () => {
    const f = fixture(); await f.ready(); f.controller.setPrompt('First question'); await f.controller.sendQuestion(); const oldAnswer = f.controller.state.messages[1];
    f.source.context = context({id: 'snapshot-2',scope: 'selection'}); await f.controller.capture('selection');
    f.controller.setPrompt('Explain this selection'); await f.controller.sendQuestion();
    const calls = f.calls.fetch.filter(call => call.url.endsWith('/chat')); assert.equal(JSON.parse(calls[1].options.body).messages.length,1);
    await f.controller.jumpToSource(oldAnswer.id,'b1');
    const jump = f.calls.messages.find(call => call.message.type === 'PN_CONTEXT_JUMP'); assert.equal(jump.message.contextId,'snapshot-1');
    assert.equal(oldAnswer.context.scope,'page'); assert.equal(f.controller.state.context.scope,'selection');
  });

  await test('Forged source IDs and quotes are discarded and stale-source errors are shown accurately',async () => {
    const c = context(); const valid = safeCitations(c,[{blockId: 'x',quote: 'Applications'},{blockId: 'b1',quote: 'Invented fact'},{blockId: 'b1',quote: 'Applications close on 30 November.',label: '<script>bad</script>'}]);
    assert.equal(valid.length,1); assert.equal(valid[0].label,'Eligibility');
    const f = fixture(); await f.ready(); f.controller.setPrompt('Deadline?'); await f.controller.sendQuestion(); const answer = f.controller.state.messages[1];
    await f.controller.jumpToSource(answer.id,'forged'); assert.equal(f.calls.messages.some(call => call.message.type === 'PN_CONTEXT_JUMP'),false);
    f.hooks.jump = async () => ({ok: false,error: 'This passage has changed. Capture the page again.'}); await f.controller.jumpToSource(answer.id,'b1');
    assert.match(f.controller.state.contextNotice,/has changed/); assert.equal(f.controller.state.contextError,true);
  });

  await test('Safe Markdown renders actual tables while all HTML and executable links stay inert text',async () => {
    const root = new Node('div');
    renderMarkdown(fakeDocument,root,'# Summary\n\n<img src=x onerror=alert(1)>\n\n| Item | Date |\n| --- | --- |\n| **Application** | `30 November` |\n\n[Run](javascript:alert(1))\n\n```html\n<script>bad()</script>\n```');
    assert.equal(nodes(root,'table').length,1); assert.equal(nodes(root,'th').length,2); assert.equal(nodes(root,'td').length,2);
    assert.equal(nodes(root,'strong')[0].textContent,'Application'); assert.equal(nodes(root,'script').length,0); assert.equal(nodes(root,'img').length,0); assert.equal(nodes(root,'a').length,0);
    assert.match(root.textContent,/<img src=x onerror=/); assert.match(root.textContent,/<script>bad/); assert.equal(nodes(root,'th')[0].attributes.scope,'col');
  });

  await test('History keeps recent complete turns within request limits and never mixes contexts',async () => {
    const c = context(), other = context({id: 'other'}); const history = [];
    for (let i = 0; i < 12; i++) history.push({role: 'user',text: 'u'.repeat(1000),status: 'complete',context: c},{role: 'assistant',text: 'a'.repeat(2000),status: 'complete',context: c});
    history.push({role: 'user',text: 'wrong page',status: 'complete',context: other},{role: 'assistant',text: 'wrong answer',status: 'complete',context: other});
    const result = recentMessages(history,c.id,'new question'); assert.equal(result.length,11); assert.equal(result.at(-1).content,'new question');
    assert.ok(result.reduce((sum,message) => sum + message.content.length,0) <= 20000); assert.equal(result.some(message => /wrong/.test(message.content)),false);
    for (let i = 0; i < result.length - 1; i += 2) { assert.equal(result[i].role,'user'); assert.equal(result[i + 1].role,'assistant'); }
  });

  await test('Older search replies cannot replace the current query or its match count',async () => {
    const f = fixture(); await f.controller.initialize(); const old = gate();
    f.hooks.action = async (_,message) => message.value === 'old' ? old.promise : {...f.source.status,searchQuery: message.value,searchCount: 4,searchIndex: 1};
    f.controller.setSearch('old',{immediate: true}); f.controller.setSearch('new',{immediate: true});
    await until(() => f.controller.state.search.count === 4);
    old.resolve({...f.source.status,searchQuery: 'old',searchCount: 9,searchIndex: 1}); await new Promise(resolve => setImmediate(resolve));
    assert.equal(f.controller.state.searchInput,'new'); assert.equal(f.controller.state.search.query,'new'); assert.equal(f.controller.state.search.count,4);
  });

  await test('Composition waits for completed text and clearing needs no Go action',async () => {
    const scheduler = timers(), f = fixture({scheduler}); await f.controller.initialize();
    f.controller.setSearch('途中',{composing: true}); scheduler.fire(180); assert.equal(f.calls.messages.some(call => call.message.type === 'PN_ACTION'),false);
    f.controller.setSearch('完成'); scheduler.fire(180); await until(() => !f.controller.state.searchPending);
    assert.equal(f.calls.messages.filter(call => call.message.type === 'PN_ACTION')[0].message.value,'完成');
    f.controller.setSearch('',{immediate: true}); await until(() => !f.controller.state.searchPending);
    assert.equal(f.calls.messages.at(-1).message.action,'clear-search'); assert.equal(f.controller.state.search.count,0);
  });

  await test('Enter during the search debounce runs the query and then advances to the next match',async () => {
    const scheduler = timers(), f = fixture({scheduler}); await f.controller.initialize();
    f.controller.setSearch('deadline'); f.controller.moveMatch('next-match'); await until(() => f.controller.state.search.index === 2);
    assert.deepEqual(f.calls.messages.filter(call => call.message.type === 'PN_ACTION').map(call => call.message.action),['search','next-match']);
  });

  await test('A blocked query is searched again before Enter can move through obsolete matches',async () => {
    const f = fixture(); await f.controller.initialize(); f.controller.state.search = {query: 'old',count: 2,index: 1,busy: false,limited: false}; f.controller.state.searchInput = 'new';
    f.controller.moveMatch('next-match'); await until(() => f.controller.state.search.index === 2);
    assert.equal(f.calls.messages.filter(call => call.message.type === 'PN_ACTION')[0].message.action,'search'); assert.equal(f.controller.state.search.query,'new');
  });

  await test('An API key pasted into the connection field is rejected before any request',async () => {
    const f = fixture(); await f.controller.initialize(); assert.equal(await f.controller.connect(`sk-${'a'.repeat(50)}`),false);
    assert.equal(f.calls.fetch.length,0); assert.match(f.controller.state.connection.message,/API key only/);
  });

  await test('A connector without an API key leaves navigation usable and explains setup',async () => {
    const f = fixture(); f.source.configured = false; await f.ready();
    assert.equal(f.controller.state.connection.state,'needs-key'); assert.equal(f.controller.available(),true); assert.match(f.controller.state.connection.message,/local setup/);
    f.controller.setPrompt('Explain'); await f.controller.sendQuestion(); assert.equal(f.calls.fetch.some(call => call.url.endsWith('/chat')),false);
    await f.controller.navigate('middle'); assert.equal(f.calls.messages.at(-1).message.action,'middle');
  });

  await test('A storage failure never falsely claims the connection code was saved',async () => {
    const f = fixture(); f.hooks.storageFailure = true; await f.ready();
    assert.equal(f.controller.state.connection.state,'connected'); assert.match(f.controller.state.connection.message,/could not be saved/); assert.equal(f.saved.pnChatConnection,undefined);
  });

  await test('Forgetting a connection defeats an older pending verification',async () => {
    const f = fixture(); await f.controller.initialize(); const waiting = gate(); f.hooks.connection = () => waiting.promise;
    const connect = f.controller.connect(TOKEN); await until(() => f.calls.fetch.length === 1); await f.controller.forgetConnection();
    waiting.resolve(response({ok: true,configured: true,model: 'gpt-5.4-mini'})); assert.equal(await connect,false);
    assert.equal(f.controller.token,''); assert.equal(f.controller.state.connection.state,'unconfigured'); assert.equal(f.calls.writes.length,0); assert.deepEqual(f.calls.removes,['pnChatConnection']);
  });

  await test('A bounded timeout aborts the request and preserves the question for a manual retry',async () => {
    const scheduler = timers(), f = fixture({scheduler}); await f.ready();
    f.hooks.chat = async call => new Promise((_,reject) => call.options.signal.addEventListener('abort',() => { const error = new Error('Aborted'); error.name = 'AbortError'; reject(error); }));
    f.controller.setPrompt('Explain this'); const task = f.controller.sendQuestion(); await until(() => f.calls.fetch.some(call => call.url.endsWith('/chat')));
    assert.equal(CHAT_TIMEOUT_MS,100000); scheduler.fire(CHAT_TIMEOUT_MS); await task;
    assert.equal(f.controller.state.prompt,'Explain this'); assert.match(f.controller.state.chatNotice,/too long/); assert.equal(f.controller.state.chatBusy,false); assert.equal(f.controller.state.messages.length,0);
  });

  await test('Disabling Page Navigator clears captured text and cancels an active answer',async () => {
    const f = fixture(); await f.ready(); const waiting = gate(); f.hooks.chat = () => waiting.promise;
    f.controller.setPrompt('Summarize'); const task = f.controller.sendQuestion(); await until(() => f.calls.fetch.some(call => call.url.endsWith('/chat')));
    await f.controller.storageChanged({pnSettings: {newValue: {enabled: false}}},'local');
    waiting.resolve(response({ok: true,answer: 'Too late',citations: []})); await task;
    assert.equal(f.controller.state.context,null); assert.equal(f.controller.state.messages.length,0); assert.equal(f.controller.available(),false); assert.equal(f.controller.state.chatBusy,false);
  });

  await test('New chat cancels outstanding work and removes transient context without saving page data',async () => {
    const f = fixture(); await f.ready(); f.controller.setPrompt('One question'); await f.controller.sendQuestion();
    f.controller.newChat(); assert.equal(f.controller.state.context,null); assert.deepEqual(f.controller.state.messages,[]); assert.equal(f.controller.state.prompt,'');
    assert.deepEqual(Object.keys(f.saved),['pnChatConnection']);
  });

  const passed = report.filter(item => item.passed).length;
  console.log(`\nSidebar behavior tests: ${passed}/${report.length} passed.`);
  console.log('Scope: production controller and safe renderer with mocked Chrome, network, and DOM boundaries. No real browser or paid API call.');
  process.exitCode = passed === report.length ? 0 : 1;
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(() => fixtures.forEach(fixture => fixture.cleanup()));
