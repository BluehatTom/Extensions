'use strict';
// Deterministic tests against production functions and the actual MV3 worker.
// Browser APIs and DOM selection are mocked; this is not a browser integration test.
// Run from source: node qa/companion-contract-tests.cjs
// Run from the distributed extension: node tests/companion-contract-tests.cjs
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('node:assert/strict');
const root = fs.existsSync(path.join(__dirname, '../manifest.json'))
  ? path.resolve(__dirname, '..') : path.resolve(__dirname, '../page-navigator');
const contentSource = fs.readFileSync(path.join(root, 'content.js'), 'utf8');
const backgroundSource = fs.readFileSync(path.join(root, 'background.js'), 'utf8');
const results = [];
const plain = value => JSON.parse(JSON.stringify(value));
async function test(name, run) {
  try { await run(); results.push({name, ok: true}); console.log('PASS', name); }
  catch (error) { results.push({name, ok: false}); console.error('FAIL', name, error.stack); }
}
function gate() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return {promise, resolve, reject};
}
async function until(predicate) {
  for (let i = 0; i < 80; i++) { if (predicate()) return; await Promise.resolve(); }
  assert.ok(predicate(), 'Expected asynchronous browser boundary was not reached');
}
function contentFunction(name) {
  const match = contentSource.match(new RegExp('^  (?:async )?function ' + name + '\\([^\\n]*\\) \\{[\\s\\S]*?^  \\}', 'm'));
  assert.ok(match, `Cannot extract production function ${name}`);
  return match[0];
}

function contentFixture() {
  const state = {
    now: 1000, url: 'https://example.test/article', focused: true, enabled: true,
    events: [], messages: [], fields: [], renders: 0, execSuccess: true,
    runtimeResult: {ok: true, windowId: 100, reused: false}
  };
  let c;
  const shadow = {activeElement: null, append(field) { field.isConnected = true; state.fields.push(field); }};
  const host = {own: true, tagName: 'DIV', isConnected: true};
  function element(tagName, properties = {}) {
    return {
      tagName, isConnected: true, own: false, style: {},
      setAttribute() {},
      focus() {
        document.activeElement = this.own ? host : this;
        shadow.activeElement = this.own ? this : null;
      },
      ...properties
    };
  }
  const body = element('BODY');
  let currentRange = null;
  const selection = {
    text: '', rangeCount: 0, isCollapsed: true, anchorNode: null, focusNode: null,
    toString() { return this.text; },
    getRangeAt() { return currentRange; },
    removeAllRanges() { this.text = ''; this.rangeCount = 0; this.isCollapsed = true; },
    addRange(range) { setSelection(range.text, range.startContainer, range.endContainer); }
  };
  function setSelection(text, start = element('P'), end = start) {
    selection.text = text; selection.rangeCount = text ? 1 : 0; selection.isCollapsed = !text;
    selection.anchorNode = start; selection.focusNode = end;
    currentRange = {
      text, startContainer: start, endContainer: end, commonAncestorContainer: start,
      cloneRange() { return {...this}; }
    };
    return {start, end};
  }
  const document = {
    activeElement: body, body,
    hasFocus: () => state.focused,
    createElement(tag) {
      assert.equal(tag, 'textarea');
      return element('TEXTAREA', {
        own: true, value: '',
        select() { setSelection(this.value, this); c.rememberPageSelection(); },
        remove() { this.isConnected = false; this.removed = true; }
      });
    },
    execCommand(command) {
      assert.equal(command, 'copy');
      state.events.push({type: 'fallback-copy', text: shadow.activeElement.value});
      return state.execSuccess;
    }
  };
  const ui = {value: ''};
  c = vm.createContext({
    URL, Number, String, Object, Array, Boolean, Math, Promise, Set, console,
    Date: {now: () => state.now},
    MAX_SELECTION_CHARS: 200000, SELECTION_CACHE_MS: 120000,
    pageSelection: null, selectionTooLong: false, copyingSelection: false, companionBusy: false,
    pageIdentity: state.url, savedSpot: null, history: [], manualRoot: null, recentRoot: null,
    activeRoot: null, temporarilyHidden: false, forcedVisible: false, scanNeeded: false,
    headingsDirty: false, lastHeading: null, lastHeadingDestination: null,
    document, shadow, host,
    window: {getSelection: () => selection, screen: {availLeft: 0, availTop: 0, availWidth: 1920, availHeight: 1040}},
    navigator: {clipboard: {async writeText(text) { state.events.push({type: 'copy', text}); }}},
    identity: () => state.url, enabled: () => state.enabled,
    isOwn: node => node?.own === true,
    renderSelectionHint: () => { state.renders++; },
    announce: text => state.messages.push(text),
    clearSearch() {}, clearPageContexts() {}, loadSpot: async () => {}, $: () => ui,
    chrome: {runtime: {async sendMessage(message) {
      state.events.push({type: 'open', message: plain(message)});
      if (state.runtimeError) throw new Error(state.runtimeError);
      return state.runtimeResult;
    }}}
  });
  for (const name of ['selectionSnapshot', 'clearPageSelection', 'rememberPageSelection', 'getPageSelection',
    'fallbackCopyText', 'copySelectedText', 'availableScreen', 'openChatGPTCompanion', 'companionAction', 'checkRoute']) {
    vm.runInContext(contentFunction(name), c, {filename: 'production/content.js:' + name});
  }
  return {c, state, body, host, shadow, selection, document, element, setSelection};
}

function browserState() {
  return {
    nextWindowId: 100, nextTabId: 1000, lastFocusedWindowId: 1,
    windows: new Map([
      [1, {id: 1, type: 'normal', state: 'normal', incognito: false, left: 0, top: 0, width: 1440, height: 1000,
        tabs: [{id: 10, windowId: 1, incognito: false, active: true, url: 'https://example.test/article'}]}],
      [2, {id: 2, type: 'normal', state: 'normal', incognito: true, left: 50, top: 50, width: 1200, height: 900,
        tabs: [{id: 20, windowId: 2, incognito: true, active: true, url: 'https://example.test/private'}]}]
    ]),
    stored: {}, calls: [], status: new Map(), warnings: [], failCreates: 0,
    failStorageRead: false, failStorageWrite: false, createGate: null, omitCreatedTabs: false
  };
}
function worker(state = browserState()) {
  const listeners = {};
  const record = (method, ...args) => state.calls.push({method, args: plain(args)});
  const getWindow = id => {
    const value = state.windows.get(id);
    if (!value) throw new Error(`No window with id ${id}`);
    return value;
  };
  const findTab = id => {
    const value = [...state.windows.values()].flatMap(window => window.tabs || []).find(tab => tab.id === id);
    if (!value) throw new Error(`No tab with id ${id}`);
    return value;
  };
  const chrome = {
    runtime: {id: 'page-navigator-test', onMessage: {addListener(fn) { listeners.message = fn; }}},
    storage: {session: {
      async get(key) {
        record('storage.get', key);
        if (state.failStorageRead) throw new Error('Storage read unavailable');
        return plain(state.stored);
      },
      async set(value) {
        record('storage.set', value);
        if (state.failStorageWrite) throw new Error('Storage write unavailable');
        Object.assign(state.stored, plain(value));
      }
    }},
    windows: {
      async get(id, options) { record('windows.get', id, options); return plain(getWindow(id)); },
      async getLastFocused() { record('windows.getLastFocused'); return plain(getWindow(state.lastFocusedWindowId)); },
      async create(options) {
        record('windows.create', options);
        if (state.createGate) await state.createGate.promise;
        if (state.failCreates > 0) { state.failCreates--; throw new Error('Window creation denied'); }
        const id = state.nextWindowId++;
        const tab = {id: state.nextTabId++, windowId: id, incognito: options.incognito, active: true, url: options.url};
        const created = {id, state: 'normal', type: options.type, incognito: options.incognito,
          left: options.left, top: options.top, width: options.width, height: options.height, tabs: [tab]};
        state.windows.set(id, created);
        const response = plain(created);
        if (state.omitCreatedTabs) delete response.tabs;
        return response;
      },
      async update(id, options) {
        record('windows.update', id, options);
        if (state.failWindowUpdate) throw new Error('Window focus denied');
        Object.assign(getWindow(id), options);
        return plain(getWindow(id));
      },
      onRemoved: {addListener(fn) { listeners.removed = fn; }}
    },
    tabs: {
      async get(id) { record('tabs.get', id); return plain(findTab(id)); },
      async query(options) {
        record('tabs.query', options);
        return plain(getWindow(options.windowId ?? state.lastFocusedWindowId).tabs || []);
      },
      async update(id, options) {
        record('tabs.update', id, options);
        Object.assign(findTab(id), options);
        return plain(findTab(id));
      },
      async sendMessage(id, message, options) {
        record('tabs.sendMessage', id, message, options);
        if (!state.status.has(id)) throw new Error('Could not establish connection. Receiving end does not exist.');
        const reply = state.status.get(id);
        if (reply instanceof Error) throw reply;
        return plain(reply);
      }
    },
    commands: {onCommand: {addListener(fn) { listeners.command = fn; }}},
    action: {
      async setBadgeText(value) { record('badge.text', value); },
      async setTitle(value) { record('badge.title', value); },
      async setBadgeBackgroundColor(value) { record('badge.color', value); }
    }
  };
  const c = vm.createContext({chrome, URL, Promise, Map, Set, Number, Object, Math, Boolean, String, Array,
    setTimeout, clearTimeout, console: {warn: text => state.warnings.push(text)}});
  vm.runInContext(backgroundSource, c, {filename: 'production/background.js'});
  function open(sourceWindowId = 1, options = {}, sender = {id: chrome.runtime.id}) {
    return new Promise(resolve => {
      listeners.message({type: 'PN_COMPANION', action: 'open', sourceWindowId, ...options}, sender, resolve);
    });
  }
  return {c, state, listeners, open};
}
const calls = (state, method) => state.calls.filter(call => call.method === method);

(async () => {
  await test('Selected page text is copied exactly, including whitespace', async () => {
    const f = contentFixture(); f.setSelection('  Line one\n\tLine two  ');
    assert.deepEqual(plain(f.c.getPageSelection()), {ok: true, text: '  Line one\n\tLine two  ', characters: 22});
    await f.c.copySelectedText();
    assert.equal(f.state.events[0].text, '  Line one\n\tLine two  ');
  });
  await test('Only the selected portion of text inputs and textareas is read', () => {
    for (const tagName of ['INPUT', 'TEXTAREA']) {
      const f = contentFixture();
      f.document.activeElement = f.element(tagName, {type: 'text', value: 'prefix SELECTED suffix', selectionStart: 7, selectionEnd: 15});
      assert.equal(f.c.getPageSelection().text, 'SELECTED');
    }
  });
  await test('Password fields are rejected without reading their values, and clear stale selection', () => {
    const f = contentFixture(); f.setSelection('Earlier passage'); f.c.rememberPageSelection();
    const password = f.element('INPUT', {type: 'password'});
    Object.defineProperty(password, 'value', {get() { throw new Error('Password value must never be read'); }});
    f.document.activeElement = password;
    assert.equal(f.c.getPageSelection().ok, false); assert.equal(f.c.pageSelection, null);
  });
  await test('Password fields nested inside page shadow roots remain protected', () => {
    const f = contentFixture();
    const password = f.element('INPUT', {type: 'password'});
    Object.defineProperty(password, 'value', {get() { throw new Error('Password read'); }});
    f.document.activeElement = f.element('DIV', {shadowRoot: {activeElement: password}});
    assert.equal(f.c.selectionSnapshot().kind, 'protected');
    assert.equal(f.c.getPageSelection().ok, false);
  });
  await test('An active iframe cannot cause an earlier top-page passage to be copied', () => {
    const f = contentFixture(); f.setSelection('Earlier text'); f.c.rememberPageSelection();
    f.document.activeElement = f.element('IFRAME');
    assert.equal(f.c.getPageSelection().ok, false); assert.equal(f.c.pageSelection, null);
  });
  await test('Toolbar focus retains a page selection without copying extension UI text', () => {
    const f = contentFixture(); f.setSelection('Page passage'); f.c.rememberPageSelection(true);
    f.document.activeElement = f.host; f.shadow.activeElement = f.element('BUTTON', {own: true});
    f.setSelection('Copy selected text', f.host);
    assert.equal(f.c.getPageSelection().text, 'Page passage');
  });
  await test('Popup focus preserves a selection that Chrome temporarily collapses', () => {
    const f = contentFixture(); f.setSelection('Keep this passage'); f.c.rememberPageSelection();
    f.state.focused = false; f.setSelection(''); f.c.rememberPageSelection();
    assert.equal(f.c.getPageSelection().text, 'Keep this passage');
  });
  await test('Clearing a selection on the focused page prevents later stale copying', () => {
    const f = contentFixture(); f.setSelection('Old passage'); f.c.rememberPageSelection();
    f.setSelection(''); f.c.rememberPageSelection(); f.state.focused = false;
    assert.equal(f.c.getPageSelection().ok, false);
  });
  await test('A cached selection expires after two minutes away from the page', () => {
    const f = contentFixture(); f.setSelection('Cached passage'); f.c.rememberPageSelection();
    f.state.focused = false; f.setSelection(''); f.state.now += 120001;
    assert.equal(f.c.getPageSelection().ok, false); assert.equal(f.c.pageSelection, null);
  });
  await test('Removed page nodes invalidate cached selection', () => {
    const f = contentFixture(); const {end} = f.setSelection('Removed passage'); f.c.rememberPageSelection();
    f.state.focused = false; f.setSelection(''); end.isConnected = false;
    assert.equal(f.c.getPageSelection().ok, false);
  });
  await test('An SPA route change clears cached selection before a popup can request it', async () => {
    const f = contentFixture(); f.setSelection('First page'); f.c.rememberPageSelection();
    f.state.focused = false; f.setSelection(''); f.state.url = 'https://example.test/next';
    await f.c.checkRoute();
    assert.equal(f.c.pageIdentity, f.state.url); assert.equal(f.c.pageSelection, null);
    assert.equal(f.c.getPageSelection().ok, false);
  });
  await test('Route identity guard rejects stale cache even before route refresh runs', () => {
    const f = contentFixture(); f.setSelection('First page'); f.c.rememberPageSelection();
    f.state.focused = false; f.setSelection(''); f.state.url = 'https://example.test/next';
    assert.equal(f.c.getPageSelection().ok, false);
  });
  await test('Disabled navigation clears and does not recollect selected text', () => {
    const f = contentFixture(); f.setSelection('Visible text'); f.c.rememberPageSelection();
    f.state.enabled = false; f.c.rememberPageSelection();
    assert.equal(f.c.pageSelection, null); assert.equal(f.c.getPageSelection().ok, false);
    f.state.enabled = true; assert.equal(f.c.getPageSelection().text, 'Visible text');
  });
  await test('Oversized selections fail explicitly instead of silently truncating', () => {
    const f = contentFixture(); f.setSelection('a'.repeat(200001));
    const result = f.c.getPageSelection();
    assert.equal(result.ok, false); assert.match(result.error, /200,000/); assert.equal(f.c.pageSelection, null);
    f.setSelection('a'.repeat(200000)); assert.equal(f.c.getPageSelection().characters, 200000);
  });
  await test('No selection means no clipboard write and no companion window', async () => {
    const f = contentFixture(); const result = await f.c.companionAction('copy-open-chatgpt');
    assert.match(result.error, /Highlight text/); assert.equal(f.state.events.length, 0);
    assert.equal(f.c.companionBusy, false);
  });
  await test('Copy and open waits for the clipboard before changing window focus', async () => {
    const f = contentFixture(); f.setSelection('Selected text'); const pending = gate();
    f.c.navigator.clipboard.writeText = async text => { f.state.events.push({type: 'copy-start', text}); await pending.promise; f.state.events.push({type: 'copy-complete'}); };
    const action = f.c.companionAction('copy-open-chatgpt');
    await until(() => f.state.events.length === 1);
    assert.equal(f.state.events.some(event => event.type === 'open'), false);
    pending.resolve(); await action;
    assert.deepEqual(f.state.events.map(event => event.type), ['copy-start', 'copy-complete', 'open']);
    const message = f.state.events.at(-1).message;
    assert.equal(message.type, 'PN_COMPANION'); assert.equal(message.action, 'open');
    assert.equal(JSON.stringify(message).includes('Selected text'), false, 'Selected text must not be sent to the worker or ChatGPT');
  });
  await test('Copy-only never opens ChatGPT and open-only never reads selection or clipboard', async () => {
    const f = contentFixture(); f.setSelection('Copy this'); await f.c.companionAction('copy-selection');
    assert.deepEqual(f.state.events.map(event => event.type), ['copy']);
    f.state.events.length = 0;
    f.c.getPageSelection = () => { throw new Error('Open-only must not read page selection'); };
    await f.c.companionAction('open-chatgpt');
    assert.deepEqual(f.state.events.map(event => event.type), ['open']);
  });
  await test('HTTP-compatible copy fallback removes its temporary field and restores selection', async () => {
    const f = contentFixture(); f.setSelection('HTTP passage'); f.c.navigator.clipboard = undefined;
    const result = await f.c.copySelectedText();
    assert.equal(result.ok, true); assert.equal(f.state.events[0].type, 'fallback-copy');
    assert.equal(f.state.events[0].text, 'HTTP passage'); assert.equal(f.state.fields[0].removed, true);
    assert.equal(f.document.activeElement, f.body); assert.equal(f.selection.toString(), 'HTTP passage');
    assert.equal(f.c.copyingSelection, false); assert.equal(f.c.pageSelection.text, 'HTTP passage');
  });
  await test('Failure of both clipboard methods reports failure and prevents opening', async () => {
    const f = contentFixture(); f.setSelection('Do not lose this');
    f.c.navigator.clipboard.writeText = async () => { throw new Error('Clipboard denied'); }; f.state.execSuccess = false;
    const result = await f.c.companionAction('copy-open-chatgpt');
    assert.match(result.error, /Could not copy/); assert.equal(f.state.events.some(event => event.type === 'open'), false);
    assert.equal(f.state.fields[0].removed, true); assert.equal(f.c.copyingSelection, false); assert.equal(f.c.companionBusy, false);
  });
  await test('Successful copy followed by open failure tells the user text was copied', async () => {
    const f = contentFixture(); f.setSelection('Preserved text'); f.state.runtimeResult = {ok: false, error: 'Chrome denied opening.'};
    const result = await f.c.companionAction('copy-open-chatgpt');
    assert.match(result.error, /^Text copied, but/); assert.deepEqual(f.state.events.map(event => event.type), ['copy', 'open']);
  });
  await test('Rapid toolbar actions cannot duplicate a pending clipboard/open operation', async () => {
    const f = contentFixture(); f.setSelection('Once'); const pending = gate();
    f.c.navigator.clipboard.writeText = async () => pending.promise;
    const first = f.c.companionAction('copy-open-chatgpt');
    const second = await f.c.companionAction('copy-open-chatgpt');
    assert.match(second.error, /already in progress/); pending.resolve(); await first;
    assert.equal(f.state.events.filter(event => event.type === 'open').length, 1);
  });
  await test('Companion open handles a disconnected extension and filters invalid screen values', async () => {
    const f = contentFixture(); f.state.runtimeError = 'Extension context invalidated';
    f.c.window.screen = {availLeft: -1920, availTop: 0, availWidth: NaN, availHeight: Infinity};
    assert.deepEqual(plain(f.c.availableScreen()), {left: -1920, top: 0});
    const result = await f.c.openChatGPTCompanion(); assert.equal(result.ok, false); assert.match(result.error, /Reload this page/);
  });

  await test('Worker creates only the fixed ChatGPT URL and stores window/tab ownership', async () => {
    const f = worker(); const response = await f.open();
    assert.equal(response.ok, true); assert.equal(response.reused, false);
    const options = calls(f.state, 'windows.create')[0].args[0];
    assert.equal(options.url, 'https://chatgpt.com/'); assert.equal(options.type, 'popup'); assert.equal(options.focused, true);
    assert.deepEqual(f.state.stored.pnCompanionWindowsV1.normal, {windowId: response.windowId, tabId: 1000, incognito: false});
    assert.equal(calls(f.state, 'tabs.sendMessage').length, 0);
    assert.equal(calls(f.state, 'windows.update').length, 0, 'Opening must not resize the source window');
  });
  await test('Existing companion is focused and its chat URL is never reset', async () => {
    const f = worker(); const first = await f.open();
    f.state.windows.get(first.windowId).tabs[0].url = 'https://chatgpt.com/c/existing-conversation';
    const second = await f.open(); assert.equal(second.reused, true); assert.equal(second.windowId, first.windowId);
    assert.equal(calls(f.state, 'windows.create').length, 1);
    assert.deepEqual(calls(f.state, 'tabs.update')[0].args, [1000, {active: true}]);
    assert.deepEqual(calls(f.state, 'windows.update')[0].args, [100, {focused: true}]);
  });
  await test('A minimized companion is restored before being focused', async () => {
    const f = worker(); const first = await f.open(); f.state.windows.get(first.windowId).state = 'minimized';
    await f.open(); assert.deepEqual(calls(f.state, 'windows.update')[0].args[1], {focused: true, state: 'normal'});
  });
  await test('A fresh service-worker context reuses session-stored companion ownership', async () => {
    const state = browserState(); const first = worker(state); const created = await first.open();
    const restarted = worker(state); const response = await restarted.open();
    assert.equal(response.reused, true); assert.equal(response.windowId, created.windowId);
    assert.equal(calls(state, 'windows.create').length, 1); assert.equal(calls(state, 'storage.get').length, 2);
  });
  await test('Concurrent clicks from the same source create one window', async () => {
    const f = worker(); f.state.createGate = gate();
    const first = f.open(); const second = f.open();
    await until(() => calls(f.state, 'windows.create').length === 1);
    f.state.createGate.resolve();
    const responses = await Promise.all([first, second]);
    assert.equal(calls(f.state, 'windows.create').length, 1);
    assert.equal(responses[0].windowId, responses[1].windowId); assert.equal(responses[1].reused, true);
  });
  await test('Concurrent requests from different normal windows serialize and share one companion', async () => {
    const f = worker(); f.state.windows.set(3, {...plain(f.state.windows.get(1)), id: 3}); f.state.createGate = gate();
    const first = f.open(1); const second = f.open(3);
    await until(() => calls(f.state, 'windows.create').length === 1); f.state.createGate.resolve();
    const [a, b] = await Promise.all([first, second]);
    assert.equal(a.windowId, b.windowId); assert.equal(b.reused, true); assert.equal(calls(f.state, 'windows.create').length, 1);
  });
  await test('Closed or stale window records create a replacement without touching unrelated windows', async () => {
    const f = worker(); const first = await f.open(); f.state.windows.delete(first.windowId);
    const second = await f.open(); assert.equal(second.reused, false); assert.notEqual(second.windowId, first.windowId);
    assert.equal(calls(f.state, 'windows.update').length, 0);
  });
  await test('The window-close event removes only the corresponding ownership record', async () => {
    const f = worker(); const normal = await f.open(1); const incognito = await f.open(2);
    f.state.windows.delete(normal.windowId); f.listeners.removed(normal.windowId);
    await f.open(2);
    assert.equal(f.state.stored.pnCompanionWindowsV1.normal, undefined);
    assert.equal(f.state.stored.pnCompanionWindowsV1.incognito.windowId, incognito.windowId);
  });
  await test('A companion tab navigated away from ChatGPT is not repurposed', async () => {
    const f = worker(); const first = await f.open(); const old = f.state.windows.get(first.windowId);
    old.tabs[0].url = 'https://example.test/private'; const second = await f.open();
    assert.equal(second.reused, false); assert.notEqual(second.windowId, first.windowId);
    assert.equal(old.tabs[0].url, 'https://example.test/private'); assert.equal(calls(f.state, 'tabs.update').length, 0);
  });
  await test('An in-flight navigation away from ChatGPT takes precedence over the old URL', async () => {
    const f = worker(); const first = await f.open();
    f.state.windows.get(first.windowId).tabs[0].pendingUrl = 'https://example.test/other';
    assert.equal((await f.open()).reused, false);
  });
  await test('A moved tab or changed window type cannot be mistaken for the companion', async () => {
    for (const alteration of ['moved-tab', 'normal-window']) {
      const f = worker(); const first = await f.open(); const window = f.state.windows.get(first.windowId);
      if (alteration === 'moved-tab') window.tabs[0].windowId = 999;
      else window.type = 'normal';
      assert.equal((await f.open()).reused, false, alteration);
      assert.equal(calls(f.state, 'tabs.update').length, 0);
    }
  });
  await test('Normal and incognito source windows retain separate companions', async () => {
    const f = worker(); const normal = await f.open(1); const privateWindow = await f.open(2);
    assert.notEqual(normal.windowId, privateWindow.windowId);
    assert.equal(f.state.windows.get(normal.windowId).incognito, false);
    assert.equal(f.state.windows.get(privateWindow.windowId).incognito, true);
    assert.equal((await f.open(1)).windowId, normal.windowId); assert.equal((await f.open(2)).windowId, privateWindow.windowId);
  });
  await test('Content-script sender window takes precedence over a claimed source', async () => {
    const f = worker(); const response = await f.open(1, {}, {id: 'page-navigator-test', tab: {windowId: 2}});
    assert.equal(f.state.windows.get(response.windowId).incognito, true);
  });
  await test('Invalid source IDs and foreign extension messages return explicit errors', async () => {
    const f = worker();
    assert.equal((await f.open(-1)).ok, false); assert.equal((await f.open('1')).ok, false);
    assert.equal((await f.open(1, {}, {id: 'another-extension'})).ok, false);
    assert.equal(calls(f.state, 'windows.create').length, 0);
  });
  await test('Failed creation is reported and does not poison the request queue', async () => {
    const f = worker(); f.state.failCreates = 1;
    const first = await f.open(); assert.equal(first.ok, false); assert.match(first.error, /creation denied/);
    const second = await f.open(); assert.equal(second.ok, true); assert.equal(second.reused, false);
  });
  await test('Focus failure does not report successful reuse or create another window', async () => {
    const f = worker(); await f.open(); f.state.failWindowUpdate = true;
    const result = await f.open(); assert.equal(result.ok, false); assert.match(result.error, /focus denied/);
    assert.equal(calls(f.state, 'windows.create').length, 1);
  });
  await test('Session-storage failure preserves successful creation and same-worker reuse', async () => {
    const f = worker(); f.state.failStorageRead = true; f.state.failStorageWrite = true;
    const first = await f.open(); assert.equal(first.ok, true); assert.equal((await f.open()).reused, true);
    assert.equal(calls(f.state, 'windows.create').length, 1); assert.equal(f.state.warnings.length, 1);
  });
  await test('Malformed persisted ownership is ignored', async () => {
    const f = worker(); f.state.stored.pnCompanionWindowsV1 = {
      normal: {windowId: '100', tabId: 1000, incognito: false},
      incognito: {windowId: 100, tabId: 1000, incognito: false}
    };
    assert.equal((await f.open()).reused, false);
    assert.equal(calls(f.state, 'windows.get').some(call => call.args[0] === '100'), false);
  });
  await test('Missing creation tab metadata is recovered using the new window ID', async () => {
    const f = worker(); f.state.omitCreatedTabs = true; const first = await f.open();
    assert.deepEqual(calls(f.state, 'tabs.query')[0].args[0], {windowId: first.windowId});
    assert.equal((await f.open()).reused, true);
  });
  await test('URL validation rejects lookalike hosts, HTTP, non-default ports, and script URLs', () => {
    const f = worker();
    for (const url of ['https://chatgpt.com.evil.test/', 'http://chatgpt.com/', 'https://chatgpt.com:444/', 'javascript:alert(1)', '', 'bad url']) {
      assert.equal(f.c.isChatGPTUrl(url), false, url);
    }
    assert.equal(f.c.isChatGPTUrl('https://chatgpt.com/c/conversation'), true);
  });
  await test('A missing tab URL may be verified only by this extension content script on ChatGPT', async () => {
    const f = worker(); const first = await f.open(); const tab = f.state.windows.get(first.windowId).tabs[0];
    delete tab.url; f.state.status.set(tab.id, {ok: true, hostname: 'chatgpt.com'});
    assert.equal((await f.open()).reused, true);
    assert.deepEqual(calls(f.state, 'tabs.sendMessage').at(-1).args, [tab.id, {type: 'PN_STATUS'}, {frameId: 0}]);
    f.state.status.set(tab.id, {ok: true, hostname: 'example.test'});
    assert.equal((await f.open()).reused, false);
  });
  await test('Missing URL and unavailable content script fail safely instead of reusing an unverified tab', async () => {
    const f = worker(); const first = await f.open(); delete f.state.windows.get(first.windowId).tabs[0].url;
    assert.equal((await f.open()).reused, false);
  });
  await test('Companion geometry fits small, negative-origin, and ordinary source displays', () => {
    const f = worker();
    for (const display of [
      {left: 0, top: 0, width: 1920, height: 1040},
      {left: -1920, top: 0, width: 1920, height: 1080},
      {left: 100, top: -900, width: 320, height: 240},
      {left: 0, top: 0, width: 1, height: 1}
    ]) {
      const bounds = f.c.companionBounds(display, display);
      for (const value of Object.values(bounds)) assert.ok(Number.isFinite(value));
      assert.ok(bounds.width > 0 && bounds.height > 0);
      assert.ok(bounds.left >= display.left && bounds.top >= display.top);
      assert.ok(bounds.left + bounds.width <= display.left + display.width);
      assert.ok(bounds.top + bounds.height <= display.top + display.height);
    }
  });
  await test('Stale monitor geometry and non-finite values cannot place the window off the source display', () => {
    const f = worker(); const source = {left: -1800, top: 100, width: 1400, height: 900};
    const bounds = f.c.companionBounds(source, {left: 0, top: 0, width: 1920, height: 1080});
    assert.ok(bounds.left >= source.left && bounds.left + bounds.width <= source.left + source.width);
    assert.deepEqual(plain(f.c.companionBounds(null, {left: 0, top: 0, width: NaN, height: Infinity})), {width: 480, height: 720});
    assert.equal(f.c.normalizedRect({left: 1e8, top: 0, width: 100, height: 100}), null);
  });
  await test('The companion keyboard command works without a content script and never sends page text', async () => {
    const f = worker(); await f.listeners.command('open-chatgpt');
    assert.equal(calls(f.state, 'windows.create').length, 1); assert.equal(calls(f.state, 'tabs.sendMessage').length, 0);
    assert.equal(calls(f.state, 'badge.text').at(-1).args[0].text, '');
  });

  const passed = results.filter(result => result.ok).length;
  console.log(`\nCompanion contract tests: ${passed}/${results.length} passed.`);
  console.log('Scope: actual content functions and service-worker code; mocked DOM, clipboard, Chrome windows, tabs, and storage.');
  console.log('Not verified here: real Chrome rendering, native clipboard, login, OS window placement, or browser integration.');
  if (passed !== results.length) process.exitCode = 1;
})().catch(error => { console.error(error.stack); process.exitCode = 1; });
