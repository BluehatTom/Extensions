# Page Navigator

A Chrome extension for navigating and searching long web pages, with an integrated page-aware chat sidebar and an optional ChatGPT website companion.
Version 1.2.0 · Chrome 116 or later · No extension build step.

Navigation, live search, saved spots, and the website companion work without an API key. The new **Page chat** sidebar uses the included local connector and your OpenAI API credentials.

## Install

1. Extract the ZIP into a folder you intend to keep.
2. Enter `chrome://extensions` in Chrome's address bar.
3. Turn on **Developer mode**.
4. Click **Load unpacked** and select the `page-navigator` folder containing `manifest.json`.
5. Pin **Page Navigator** from Chrome's Extensions menu, then refresh any webpages that were already open.

The toolbar appears near the bottom right of a long page. It stays hidden on short pages until you choose **Show toolbar** in the extension popup. You can also open `START-HERE.html` for the illustrated installation steps.

For local HTML files, open the extension's **Details** page and enable **Allow access to file URLs**. No extra setting is needed for ordinary HTTP/HTTPS pages to which Chrome grants the extension access.

## Main controls

| Control | What it does |
| --- | --- |
| Top | Goes to the beginning of the current scrolling area. |
| Middle | Goes to 50% of its available scrolling distance. |
| End | Goes to the bottom of content currently loaded. |
| Search | Opens a search box that searches as you type. |
| Page chat | Opens the integrated sidebar for questions about the current page. |
| ChatGPT | Opens or brings forward the ChatGPT companion window. |
| More | Opens the additional navigation controls. |

### Page-aware chat sidebar — new in 1.2

Open **Page chat** on the page toolbar or **Ask about this page** in the extension popup. The sidebar includes Top/Middle/End and live page search, so you can keep reading while you chat.

1. Choose **Use this page** to attach loaded text from the current scrolling area, or **Use selection** to attach only the highlighted passage.
2. Review the attached page title and text preview. Capturing content does not send it to OpenAI by itself.
3. Ask your question, or use a quick prompt to summarize, explain, find, or extract information.
4. Use the answer's source buttons to jump to and highlight the associated passage.

The sidebar sends the attached text and recent chat messages only when you submit a question. It clears or separates page context when the active page changes, cancels outdated requests, and never automatically attaches a newly visited page. **Stop** cancels a pending answer; **New chat** clears the current conversation. The extension does not save page text or chat transcripts persistently.

Page capture excludes hidden content, scripts, website form fields/editors, embedded frames, and extension UI. It captures up to 60,000 characters in 200 blocks, with up to 6,000 characters in each block, and shows when the result is limited. Infinite feeds and virtualized apps expose only currently loaded content. Selection capture uses the selected-text safeguards described below.

Source buttons point to passages captured by the extension, not model-supplied selectors. If the page changes, the passage disappears, or its snapshot expires, capture the page again. Answers can still contain mistakes; source buttons make it easier to inspect the supplied evidence.

#### Connect the assistant

The ZIP includes a sibling folder named **page-navigator-connector**. Keep it alongside the extension folder.

1. Install **Node.js 22 or later** if it is not already available.
2. Open **page-navigator-connector/START-WINDOWS.cmd** on Windows, or run the connector's start script on macOS/Linux. Keep the connector running while you use page chat.
3. In the connector's local setup page, enter your OpenAI API key. This key stays with the connector; it is never entered into Page Navigator or included in the ZIP.
4. Copy the connector's **connection code**, paste it into the sidebar's connection settings, and connect.

The connector runs on your own computer at `http://127.0.0.1:43127`. It forwards chat requests to the OpenAI Responses API. The default model is `gpt-5.4-mini`; the local setup page lets you choose another supported model. An API account with access to the model and available credits is required. See the connector's README for setup, credential storage, and troubleshooting.

The API key stays in memory and is forgotten when the connector closes. Enter it again after restarting the connector, or use an existing `OPENAI_API_KEY` environment configuration. The connection code stays the same across normal restarts. Connecting the sidebar does not make a paid model request; sending a question does.

This is a separate API conversation. It does not import your ChatGPT website conversations or account memory. Your ordinary ChatGPT website companion remains available below.

### ChatGPT website companion

Click **ChatGPT** on the page toolbar, or **Open ChatGPT** in the extension popup. ChatGPT opens in a separate, movable and resizable Chrome window near your current browser window. Page Navigator reuses its existing companion when it is still open on ChatGPT, including after Chrome suspends the extension's background worker. Closing the companion, or navigating it to a different website, lets the next click create a new one. Your original browser window keeps its size and position.

To ask about part of a page:

1. Highlight the passage you want to use.
2. Open the extension popup or **More** on the page toolbar.
3. Choose **Copy & open**. The extension copies the selected text and then brings ChatGPT forward.
4. Paste with **Ctrl+V** (Windows/Linux) or **Command+V** (Mac), add your question, and send when ready.

**Copy selected text** also works on its own. These controls copy only your selection, with its original text and spacing. They do not copy the entire page, read your existing clipboard, fill a prompt, or send a message automatically. Password fields and embedded frames are excluded. A selection must be on the current page, remain attached to it, and be no more than 200,000 characters. The short-lived selection cache expires after two minutes and clears when the page route changes or Page Navigator is disabled.

The companion opens the real [ChatGPT website](https://chatgpt.com/) in this Chrome profile. Sign in there if asked. No API key or API integration is used; ChatGPT's normal account access and usage limits apply. A companion opened from an incognito window stays separate from the normal-profile companion when the extension is enabled in incognito.

**Open ChatGPT** remains available in the extension popup on pages where navigation and copying are unavailable, including Chrome system pages. Copying needs an enabled, accessible webpage. If a website prevents the page toolbar from copying, try the extension popup or the normal copy shortcut.

### Live search

The extension popup has an always-visible search field. The page toolbar's **Search** button opens the same search on the page. There is no Go button: the extension searches after a brief typing pause and jumps to the first match.

- Matching is literal and case-insensitive. Formatting and links do not split otherwise adjacent words.
- All matches are highlighted in yellow; the selected match is orange and underlined.
- The count shows your current match and the number found.
- Use the arrows or **Enter** / **Shift+Enter** for next / previous. Navigation wraps at either end.
- Use the clear button to remove the query and its highlights. Escape also clears the search field in the popup.
- Search stays within the selected scrolling area. Open **More → Scrolling area** if a page has several panels.
- Searches update when loaded page text changes. Background updates do not automatically jump away from what you are reading.

Search excludes form-entry values, editable text, hidden content, frames, graphics, and the extension controls. It searches loaded DOM text, so it cannot search content that a website has not loaded, text in images, PDFs, or virtualized content absent from the DOM. To keep large pages responsive, a search returns at most 500 matches and scans up to two million text characters or 30,000 inspected nodes. The count is marked **limited** when a cap is reached. Queries are limited to 200 characters.

### Extra navigation

- **Previous position:** goes back through the positions before your recent jumps (up to 30). This history lasts for the current page session.
- **Screen up / down:** moves 88% of one screen, retaining a small reading overlap.
- **Previous / next heading:** jumps between semantic page headings. **Open heading list** provides a filterable outline.
- **Save spot / Return to spot:** stores one reading position per page on this device, including across reloads. Saving again replaces that page's prior spot. **Clear saved spot** removes it.
- **Position slider and 25% / 75% buttons:** jump directly to another part of the page.
- **Scrolling area:** Automatic detects the whole page or a large scrolling panel. You can explicitly choose a detected area when needed.

Saved spots use the page URL, position, and a nearby heading when available. A site that substantially changes its layout or content may restore approximately. Ordinary anchor fragments share a page's saved spot; hash-router paths are treated as separate pages. Nothing automatically changes your scroll position when you reopen a page.

## Keyboard shortcuts

| Default | Action |
| --- | --- |
| Alt+Shift+1 | Top |
| Alt+Shift+2 | Middle |
| Alt+Shift+3 | End |
| Alt+Shift+4 | Show / hide toolbar |

Choose **Customize keyboard shortcuts** in the popup, or open `chrome://extensions/shortcuts`, to change these or assign keys for Page chat, the ChatGPT website companion, search, headings, screen movement, previous position, saved spots, and the heading list. Chrome or your operating system may reserve a combination; choose another if needed. Chrome permits four suggested shortcuts, so the additional actions start unassigned.

By default, navigation commands pause while a page text field, editable region, or embedded frame is focused. Showing the toolbar, opening Search, and the ChatGPT shortcut remain available. The typing preference can be changed under Settings.

## Appearance and accessibility

- Collapse the page toolbar to one small button, move it to another corner, or hide it for the current page.
- Disable the toolbar on an individual hostname using the popup checkbox, or disable it everywhere under Settings.
- Native labeled buttons and fields support keyboard operation and visible focus indicators.
- Smooth scrolling respects the operating system's reduced-motion preference.
- Search uses the CSS Custom Highlight API to paint matches. It does not wrap, replace, or rewrite the website's text.
- Status messages and search counts are exposed to assistive technology. Keyboard heading navigation also focuses the heading.

## Supported pages and limits

This version targets ordinary HTML pages, including many pages with an internal scrolling panel. Chrome system pages, the Chrome Web Store, and Chrome's built-in PDF viewer do not expose their page content to this extension. Cross-origin frames and content inside closed shadow roots are outside this version's scope. An app that virtualizes its content may expose only a small portion of a conversation or document at a time.

End means the end of **currently loaded content**. An infinite feed may load more afterward; press End again to move to its new bottom.

## Privacy and permissions

All navigation and search processing happens in the browser. Page Navigator has no analytics or remotely loaded extension scripts. Search queries and match text are not stored persistently. Selected text is kept briefly in the current page's memory and written to the clipboard only when you choose a copy action.

Page chat is optional. Captured text stays in the sidebar until you send a question. Submitting a question sends the attached page context and recent conversation through the local connector to OpenAI. The connector uses `store: false` for Responses API calls; this is not a claim of zero retention by the API service. The extension and connector do not write page text or conversations to persistent storage or logs. The connection code is saved in extension-local settings so you can reconnect; the API key stays outside the extension.

Opening the companion loads ChatGPT as a normal website, which makes its own network requests and follows its own account and privacy settings. Text you choose to paste and send is handled by ChatGPT.

The `storage` permission saves settings, disabled hostnames, collapsed state, and reading spots. Session storage remembers the companion's window and tab identifiers, without storing copied text. The `clipboardWrite` permission supports the copy buttons; the extension does not request `clipboardRead`. Static content-script matches give it access to ordinary webpages so it can display controls, inspect headings/text, and scroll. This is why Chrome may describe the extension as able to read and change page content. Local-file access remains controlled by Chrome's separate file-access setting.

The narrow `https://chatgpt.com/*` host permission lets the background worker verify that its companion tab is still on ChatGPT before reusing it. The `sidePanel` permission enables the embedded chat sidebar. The loopback `http://127.0.0.1/*` host permission lets that sidebar contact the connector on this computer; its extension security policy limits network connections to port 43127. Page Navigator does not request the broader `tabs` permission.

Saved spots remain in this Chrome profile. Clear a page's spot from the popup or More panel. Removing the extension removes its extension-local settings and saved spots.

## Updating

Keep the extracted folder in the same location. Replace its files with the new version, click the extension's **Reload** button at `chrome://extensions`, and refresh existing webpages. Reloading preserves extension-local settings; removing and reinstalling does not.

## Source and validation

- `manifest.json`: Chrome registration, permissions, and commands.
- `content.js`: toolbar, scroll-area detection, navigation, reading spots, live search, selected-text copying, page capture, and passage jumps.
- `highlights.css`: document-level search highlight colors.
- `popup.html`, `popup.css`, `popup.js`: extension popup and settings.
- `background.js`: keyboard-command dispatch, sidebar opening, and companion-window ownership, placement, and reuse.
- `sidepanel.html`, `sidepanel.css`, `sidepanel.js`: page-aware chat, context preview, connection settings, and source buttons.
- `../page-navigator-connector/`: local API connection and setup screen, with its own tests and instructions.
- `icons/`: local extension icons.
- `tests/`: deterministic logic tests, local browser fixtures, and an optional browser harness.

The logic tests execute production functions with mocked browser geometry/storage. They do not replace a real browser integration or visual test. See `VALIDATION.txt` for this build's exact verification status.

Run the dependency-free suites with Node.js:

```sh
node tests/core-contract-tests.cjs
node tests/search-contract-tests.cjs
node tests/companion-contract-tests.cjs
node tests/popup-companion-tests.cjs
node tests/page-chat-open-tests.cjs
node tests/page-context-tests.cjs
node tests/sidepanel-tests.cjs
node --test ../page-navigator-connector/tests/connector-tests.mjs
node --test ../page-navigator-connector/tests/page-chat-integration.mjs
```

The optional browser harness requires Playwright and its Chromium browser. With those installed in your development environment, run `node tests/browser-tests.cjs`. It creates a separate browser profile and a temporary loopback server for the included fixtures.

## Chrome documentation

- [Load an unpacked extension](https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world)
- [Keyboard commands](https://developer.chrome.com/docs/extensions/reference/api/commands)
- [Static content scripts](https://developer.chrome.com/docs/extensions/reference/manifest/content-scripts)
- [Content-script restrictions](https://developer.chrome.com/docs/extensions/develop/concepts/content-scripts)
- [Chrome windows](https://developer.chrome.com/docs/extensions/reference/api/windows)
- [Tab access and permissions](https://developer.chrome.com/docs/extensions/reference/api/tabs)
