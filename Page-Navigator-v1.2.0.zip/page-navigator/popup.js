'use strict';

const DEFAULTS = Object.freeze({
  enabled: true,
  smooth: true,
  position: 'bottom-right',
  showProgress: true,
  avoidTyping: true
});
const $ = (selector) => document.querySelector(selector);
const actionButtons = [...document.querySelectorAll('[data-action]')];
const searchInput = $('#page-search');
const searchResults = $('#search-results');
const companionButtons = {
  open: $('#open-chatgpt'),
  copy: $('#copy-selection'),
  copyOpen: $('#copy-open-chatgpt')
};
const EMPTY_SEARCH = Object.freeze({searchQuery: '', searchCount: 0, searchIndex: 0, searchBusy: false, searchLimited: false});
const settingControls = {
  enabled: $('#enabled'),
  smooth: $('#smooth'),
  showProgress: $('#show-progress'),
  avoidTyping: $('#avoid-typing'),
  position: $('#position')
};
let settings = {...DEFAULTS};
let tabId = null;
let sourceWindowId = null;
let companionBusy = false;
let pageState = null;
let busy = false;
let refreshTimer;
let storageQueue = Promise.resolve();
let searchTimer;
let searchRefreshTimer;
let searchVersion = 0;
let searchPending = false;
let searchPhase = '';
let searchComposing = false;
let searchHydrated = false;
let searchEdited = false;
let searchError = '';
let searchStatusError = '';
let queuedMatch = null;
let searchState = {...EMPTY_SEARCH};

const sameQuery = (a, b) => String(a || '').trim() === String(b || '').trim();
const canSearch = () => Number.isInteger(tabId) && !!pageState?.ok && settings.enabled && !pageState.disabledOnSite;

function statusMessage(text, isError = false) {
  $('#status').textContent = text;
  $('#status').classList.toggle('error', isError);
}

function renderSettings() {
  for (const [key, control] of Object.entries(settingControls)) {
    if (control instanceof HTMLInputElement) control.checked = !!settings[key];
    else control.value = settings[key];
  }
}

function renderState(state, {acceptSearch = false} = {}) {
  pageState = state;
  const ready = !!state?.ok;
  const enabled = ready && settings.enabled && !state.disabledOnSite;
  for (const button of actionButtons) {
    const action = button.dataset.action;
    let available = enabled;
    if (action === 'previous-spot') available = available && state?.canGoBack;
    if (action === 'restore-spot' || action === 'clear-spot') available = available && state?.hasSavedSpot;
    if (action === 'previous-heading' || action === 'next-heading') available = available && state?.headingCount > 0;
    button.disabled = busy || !available;
  }
  const percent = ready ? Math.min(100, Math.max(0, Math.round(Number(state.percent) || 0))) : 0;
  $('#page-progress').value = percent;
  $('#percent-text').textContent = ready ? `${percent}%` : '—';
  $('#target-label').textContent = state?.targetLabel || 'This page';
  $('#heading-count').textContent = String(state?.headingCount || 0);
  $('#toggle-toolbar').textContent = state?.visible ? 'Hide toolbar' : 'Show toolbar';
  $('#site-name').textContent = state?.hostname || 'this site';
  $('#site-enabled').checked = ready && !state.disabledOnSite;
  $('#site-enabled').disabled = !ready || busy || !state?.hostname;
  $('#page-context').textContent = ready
    ? (state.hostname || 'Local file')
    : 'Navigation unavailable on this tab';
  renderSearch(state, {acceptSearch});
  renderCompanion();
}

function explainNoConnection() {
  renderState(null);
  statusMessage('Refresh a normal webpage to connect. Chrome system pages, the Web Store, and the built-in PDF viewer are not supported. For local files, enable “Allow access to file URLs” in extension details.', true);
}

async function readStatus({quiet = false} = {}) {
  if (!Number.isInteger(tabId)) return;
  const searchAtRequest = searchVersion;
  try {
    const state = await chrome.tabs.sendMessage(tabId, {type: 'PN_STATUS'}, {frameId: 0});
    if (!state?.ok) throw new Error(state?.error || 'Page unavailable.');
    renderState(state, {acceptSearch: searchAtRequest === searchVersion});
    if (!quiet) {
      if (!settings.enabled) statusMessage('Page Navigator is disabled. Enable it in Settings.');
      else if (state.disabledOnSite) statusMessage('Page Navigator is disabled on this site. Use the checkbox below to enable it.');
      else if (state.hasSavedSpot) statusMessage('A reading spot is saved for this page.');
      else statusMessage('Save a reading spot to return to it later.');
    }
  } catch {
    explainNoConnection();
  }
}

const ACTION_MESSAGES = {
  top: 'Jumping to the top.', middle: 'Jumping to the middle.', end: 'Jumping to the end.',
  'page-up': 'Moving up one screen.', 'page-down': 'Moving down one screen.',
  'previous-heading': 'Moving to the previous heading.', 'next-heading': 'Moving to the next heading.',
  'previous-spot': 'Returning to the previous spot.', 'save-spot': 'Reading spot saved on this device.',
  'restore-spot': 'Returning to your saved reading spot.', 'clear-spot': 'Saved reading spot cleared.',
  toggle: 'Page toolbar updated.', outline: 'Heading list opened on the page.'
};

async function runAction(action) {
  if (busy || !Number.isInteger(tabId)) return;
  busy = true;
  const searchAtRequest = searchVersion;
  renderState(pageState);
  try {
    const result = await chrome.tabs.sendMessage(
      tabId, {type: 'PN_ACTION', action, source: 'popup'}, {frameId: 0}
    );
    if (!result?.ok) {
      statusMessage(result?.error || result?.message || 'That action could not be completed.', true);
      return;
    }
    renderState(result, {acceptSearch: searchAtRequest === searchVersion});
    statusMessage(result.message || ACTION_MESSAGES[action] || 'Done.');
    await Promise.allSettled([
      chrome.action.setBadgeText({tabId, text: ''}),
      chrome.action.setTitle({tabId, title: 'Page Navigator'})
    ]);
    if (action === 'outline') {
      window.close();
      return;
    }
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => readStatus({quiet: true}), settings.smooth ? 750 : 80);
  } catch {
    explainNoConnection();
  } finally {
    busy = false;
    renderState(pageState);
  }
}

for (const button of actionButtons) {
  button.addEventListener('click', () => runAction(button.dataset.action));
}

// Companion actions have their own state so search and navigation remain usable.
function companionMessage(text, isError = false) {
  const status = $('#companion-status');
  status.textContent = text;
  status.hidden = !text;
  status.classList.toggle('error', isError);
}

function renderCompanion() {
  companionButtons.open.disabled = companionBusy || !Number.isInteger(sourceWindowId);
  const copyAvailable = canSearch();
  companionButtons.copy.disabled = companionBusy || !copyAvailable;
  companionButtons.copyOpen.disabled = companionBusy || !copyAvailable || !Number.isInteger(sourceWindowId);
  $('.companion-section').setAttribute('aria-busy', String(companionBusy));
}

function companionScreen() {
  const available = globalThis.screen;
  const values = {
    left: available?.availLeft,
    top: available?.availTop,
    width: available?.availWidth,
    height: available?.availHeight
  };
  return Object.fromEntries(Object.entries(values).filter(([, value]) => Number.isFinite(value)));
}

async function openCompanion() {
  const response = await chrome.runtime.sendMessage({
    type: 'PN_COMPANION',
    action: 'open',
    sourceWindowId,
    screen: companionScreen()
  });
  if (!response?.ok) throw new Error(response?.error || 'The ChatGPT window could not be opened. Try again.');
  return response;
}

function copyWithFallback(text) {
  // Older clipboard environments can still copy from this extension document.
  // Restore the popup's focus and selection after the temporary field is removed.
  const previousFocus = document.activeElement;
  const selection = document.getSelection();
  const savedRanges = [];
  if (selection) {
    for (let index = 0; index < selection.rangeCount; index += 1) {
      savedRanges.push(selection.getRangeAt(index).cloneRange());
    }
  }
  const inputSelection = previousFocus instanceof HTMLInputElement || previousFocus instanceof HTMLTextAreaElement
    ? {start: previousFocus.selectionStart, end: previousFocus.selectionEnd, direction: previousFocus.selectionDirection}
    : null;
  const field = document.createElement('textarea');
  field.value = text;
  field.readOnly = true;
  field.tabIndex = -1;
  field.setAttribute('aria-hidden', 'true');
  field.style.cssText = 'position:fixed;left:0;top:0;width:1px;height:1px;padding:0;border:0;opacity:0;pointer-events:none';
  document.body.append(field);
  try {
    field.focus({preventScroll: true});
    field.select();
    if (typeof document.execCommand !== 'function' || !document.execCommand('copy')) {
      throw new Error('Clipboard access failed. Please try copying again.');
    }
  } finally {
    field.remove();
    if (previousFocus?.isConnected) previousFocus.focus({preventScroll: true});
    if (inputSelection && Number.isInteger(inputSelection.start) && Number.isInteger(inputSelection.end)) {
      previousFocus.setSelectionRange(inputSelection.start, inputSelection.end, inputSelection.direction || 'none');
    } else if (selection) {
      selection.removeAllRanges();
      for (const range of savedRanges) {
        if (range.commonAncestorContainer.isConnected) selection.addRange(range);
      }
    }
  }
}

async function copySelectedText() {
  const response = await chrome.tabs.sendMessage(tabId, {type: 'PN_SELECTION'}, {frameId: 0});
  if (!response?.ok) throw new Error(response?.error || 'Selected text could not be read. Refresh the page and try again.');
  const text = typeof response.text === 'string' ? response.text : '';
  if (!text.trim()) throw new Error('Select text on the page first, then reopen Page Navigator to copy it.');
  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return;
    } catch {
      // A denied modern clipboard API may still allow an explicit extension copy.
    }
  }
  copyWithFallback(text);
}

async function runCompanion(action) {
  if (companionBusy) return;
  const needsCopy = action === 'copy' || action === 'copyOpen';
  if (needsCopy && !canSearch()) {
    companionMessage('Select text on an enabled webpage to copy it here.', true);
    return;
  }
  if (action !== 'copy' && !Number.isInteger(sourceWindowId)) {
    companionMessage('The browser window is unavailable. Close and reopen Page Navigator to try again.', true);
    return;
  }
  companionBusy = true;
  renderCompanion();
  companionMessage(needsCopy ? 'Copying selected text…' : 'Opening ChatGPT…');
  let copied = false;
  try {
    if (needsCopy) {
      await copySelectedText();
      copied = true;
    }
    if (action !== 'copy') {
      const response = await openCompanion();
      companionMessage(copied
        ? 'Text copied. Paste it into the ChatGPT window when you are ready.'
        : (response.reused ? 'ChatGPT companion window focused.' : 'ChatGPT companion window opened.'));
    } else {
      companionMessage('Text copied. Paste it into ChatGPT when you are ready.');
    }
  } catch (error) {
    const message = error?.message || 'Please try again.';
    companionMessage(copied ? `Text copied, but ChatGPT could not be opened. ${message}` : message, true);
  } finally {
    companionBusy = false;
    renderCompanion();
  }
}

for (const [action, button] of Object.entries(companionButtons)) {
  button.addEventListener('click', () => runCompanion(action));
}

$('#open-page-chat').addEventListener('click', () => {
  if (!Number.isInteger(tabId)) return;
  const button = $('#open-page-chat');
  button.disabled = true;
  // Send immediately in the click handler to preserve side-panel activation.
  chrome.runtime.sendMessage({type: 'PN_OPEN_CHAT', tabId}).then(result => {
    if (!result?.ok) throw new Error(result?.error || 'Could not open page chat. Try again.');
    window.close();
  }).catch(error => statusMessage(error?.message || 'Could not open page chat.', true))
    .finally(() => { button.disabled = !Number.isInteger(tabId); });
});

// Keep the input independent of page-status refreshes. Only the first successful
// status hydrates it, and old requests never replace a newer typed query or count.
function renderSearch(state, {acceptSearch = false} = {}) {
  if (acceptSearch && state?.ok && !searchHydrated) {
    if (!searchEdited) searchInput.value = String(state.searchQuery || '');
    searchHydrated = true;
  }
  if (acceptSearch && state?.ok && !searchPending && sameQuery(state.searchQuery, searchInput.value)) {
    const count = Math.max(0, Number(state.searchCount) || 0);
    searchState = {
      searchQuery: String(state.searchQuery || ''),
      searchCount: count,
      searchIndex: Math.min(count, Math.max(0, Number(state.searchIndex) || 0)),
      searchBusy: !!state.searchBusy,
      searchLimited: !!state.searchLimited
    };
  }
  const enabled = canSearch();
  if (!enabled && searchPending) {
    clearTimeout(searchTimer);
    searchTimer = undefined;
    searchVersion += 1;
    searchPending = false;
    queuedMatch = null;
  }
  searchInput.disabled = !enabled;
  const query = searchInput.value.trim();
  const current = sameQuery(searchState.searchQuery, query);
  const unavailable = !enabled || searchPending || searchState.searchBusy || !current || !searchState.searchCount;
  $('#previous-match').disabled = unavailable;
  $('#next-match').disabled = unavailable;
  $('#clear-search').disabled = !enabled || (!searchInput.value && !searchState.searchQuery);
  let label = 'Searches as you type';
  if (!enabled) label = 'Search is unavailable on this page';
  else if (searchError) label = 'Search could not be completed';
  else if (query && (searchComposing || (searchPending && searchPhase === 'search') || searchState.searchBusy)) label = 'Searching…';
  else if (query && current) {
    const {searchIndex, searchCount, searchLimited} = searchState;
    label = searchCount
      ? `${searchIndex} of ${searchCount} matches${searchLimited ? ' · limited results' : ''}`
      : (searchLimited ? 'Scan limit reached · no matches found' : 'No matches');
  } else if (query) label = 'Type to update search results';
  if (searchResults.textContent !== label) searchResults.textContent = label;
  searchResults.classList.toggle('error', !!searchError);
  searchResults.title = searchState.searchLimited ? 'Only part of this page could be searched within the search limit.' : '';
  searchResults.setAttribute('aria-busy', String(searchPending || searchState.searchBusy));
  // A popup opened while the page toolbar is scanning needs its final count too.
  clearTimeout(searchRefreshTimer);
  if (enabled && current && searchState.searchBusy && !searchPending) {
    searchRefreshTimer = setTimeout(() => readStatus({quiet: true}), 250);
  }
}

async function requestSearch(action, query, version) {
  if (version !== searchVersion) return;
  if (!canSearch()) {
    searchPending = false;
    renderSearch(pageState);
    return;
  }
  try {
    const message = {type: 'PN_ACTION', action, source: 'popup'};
    if (action === 'search') message.value = query;
    const result = await chrome.tabs.sendMessage(tabId, message, {frameId: 0});
    if (version !== searchVersion || !sameQuery(query, searchInput.value)) return;
    searchPending = false;
    if (!result?.ok) {
      searchError = result?.error || result?.message || 'Search could not be completed. Please try again.';
      queuedMatch = null;
      renderSearch(pageState);
      searchStatusError = searchError;
      statusMessage(searchError, true);
      return;
    }
    if (!sameQuery(result.searchQuery, query)) {
      searchError = 'The page changed during search. Type again to update the results.';
      queuedMatch = null;
      renderState(result);
      searchStatusError = searchError;
      statusMessage(searchError, true);
      return;
    }
    searchError = '';
    if (searchStatusError && $('#status').textContent === searchStatusError) statusMessage('Search updated.');
    searchStatusError = '';
    renderState(result, {acceptSearch: true});
    await Promise.allSettled([
      chrome.action.setBadgeText({tabId, text: ''}),
      chrome.action.setTitle({tabId, title: 'Page Navigator'})
    ]);
    if (version !== searchVersion) return;
    const next = queuedMatch;
    queuedMatch = null;
    if (next && searchState.searchCount > 0) moveMatch(next);
  } catch (error) {
    if (version !== searchVersion) return;
    searchPending = false;
    queuedMatch = null;
    searchError = `Search is unavailable. ${error?.message || 'Refresh the page and try again.'}`;
    renderSearch(pageState);
    searchStatusError = searchError;
    statusMessage(searchError, true);
  }
}

function scheduleSearch({immediate = false} = {}) {
  clearTimeout(searchTimer);
  searchTimer = undefined;
  searchEdited = true;
  const version = ++searchVersion;
  const query = searchInput.value;
  queuedMatch = null;
  searchError = '';
  searchPending = true;
  searchPhase = query.trim() ? 'search' : 'clear';
  if (!query.trim()) searchState = {...EMPTY_SEARCH};
  renderSearch(pageState);
  if (searchComposing) return;
  const run = () => {
    searchTimer = undefined;
    requestSearch(query.trim() ? 'search' : 'clear-search', query, version);
  };
  if (immediate || !query.trim()) run();
  else searchTimer = setTimeout(run, 180);
}

function moveMatch(action) {
  if (!canSearch() || !searchInput.value.trim() || searchComposing) return;
  if (searchPending) {
    // Enter during the debounce interval runs the search now, then advances.
    // A pending request remains cancellable by the next input event.
    queuedMatch = action;
    if (searchTimer !== undefined) {
      clearTimeout(searchTimer);
      searchTimer = undefined;
      requestSearch('search', searchInput.value, searchVersion);
    }
    return;
  }
  if (!sameQuery(searchState.searchQuery, searchInput.value)) {
    searchPending = true;
    searchPhase = 'search';
    searchError = '';
    queuedMatch = action;
    const version = ++searchVersion;
    renderSearch(pageState);
    requestSearch('search', searchInput.value, version);
    return;
  }
  if (searchState.searchBusy || !searchState.searchCount) return;
  searchPending = true;
  searchPhase = 'match';
  const version = ++searchVersion;
  renderSearch(pageState);
  requestSearch(action, searchInput.value, version);
}

searchInput.addEventListener('input', (event) => {
  if (event.isComposing) searchComposing = true;
  scheduleSearch();
});
searchInput.addEventListener('compositionstart', () => {
  searchComposing = true;
  clearTimeout(searchTimer);
  searchTimer = undefined;
  searchVersion += 1;
});
searchInput.addEventListener('compositionend', () => {
  searchComposing = false;
  scheduleSearch();
});
searchInput.addEventListener('keydown', (event) => {
  if (event.isComposing || searchComposing) return;
  if (event.key === 'Enter') {
    event.preventDefault();
    moveMatch(event.shiftKey ? 'previous-match' : 'next-match');
  } else if (event.key === 'Escape' && searchInput.value) {
    event.preventDefault();
    event.stopPropagation();
    searchInput.value = '';
    scheduleSearch({immediate: true});
  }
});
$('#clear-search').addEventListener('click', () => {
  searchInput.value = '';
  scheduleSearch({immediate: true});
  searchInput.focus();
});
$('#previous-match').addEventListener('click', () => moveMatch('previous-match'));
$('#next-match').addEventListener('click', () => moveMatch('next-match'));

function enqueueStorage(update) {
  storageQueue = storageQueue.catch(() => {}).then(update).catch((error) => {
    statusMessage(`Could not save settings. ${error?.message || 'Please try again.'}`, true);
    renderSettings();
  });
  return storageQueue;
}

for (const [key, control] of Object.entries(settingControls)) {
  control.addEventListener('change', () => {
    const value = control instanceof HTMLInputElement ? control.checked : control.value;
    enqueueStorage(async () => {
      const stored = await chrome.storage.local.get('pnSettings');
      const next = {...DEFAULTS, ...stored.pnSettings, [key]: value};
      await chrome.storage.local.set({pnSettings: next});
      settings = next;
      renderSettings();
      renderState(pageState);
      statusMessage(key === 'enabled' && !value ? 'Page Navigator is disabled.' : 'Settings saved.');
      clearTimeout(refreshTimer);
      refreshTimer = setTimeout(() => readStatus({quiet: true}), 100);
    });
  });
}

$('#site-enabled').addEventListener('change', () => {
  const hostname = pageState?.hostname;
  if (!hostname) return;
  const enable = $('#site-enabled').checked;
  enqueueStorage(async () => {
    const stored = await chrome.storage.local.get('pnDisabledSites');
    const disabled = new Set(Array.isArray(stored.pnDisabledSites) ? stored.pnDisabledSites : []);
    if (enable) disabled.delete(hostname);
    else disabled.add(hostname);
    await chrome.storage.local.set({pnDisabledSites: [...disabled]});
    renderState({...pageState, disabledOnSite: !enable});
    statusMessage(enable ? 'Page Navigator enabled on this site.' : 'Page Navigator disabled on this site.');
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => readStatus({quiet: true}), 100);
  });
});

$('#keyboard-shortcuts').addEventListener('click', async () => {
  try {
    await chrome.tabs.create({url: 'chrome://extensions/shortcuts'});
    window.close();
  } catch {
    statusMessage('Open chrome://extensions/shortcuts in a new tab to customize keyboard shortcuts.', true);
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.pnSettings) {
    settings = {...DEFAULTS, ...changes.pnSettings.newValue};
    renderSettings();
    renderState(pageState);
  }
  if (changes.pnDisabledSites && pageState) {
    const sites = changes.pnDisabledSites.newValue || [];
    renderState({...pageState, disabledOnSite: sites.includes(pageState.hostname)});
  }
});

(async () => {
  try {
    const [storedResult, tabsResult] = await Promise.allSettled([
      chrome.storage.local.get('pnSettings'),
      chrome.tabs.query({active: true, currentWindow: true})
    ]);
    if (storedResult.status === 'fulfilled') settings = {...DEFAULTS, ...storedResult.value.pnSettings};
    renderSettings();
    const activeTab = tabsResult.status === 'fulfilled' ? tabsResult.value[0] : null;
    tabId = activeTab?.id;
    sourceWindowId = activeTab?.windowId;
    $('#open-page-chat').disabled = !Number.isInteger(tabId);
    // Opening ChatGPT does not require a content script or enabled navigation.
    renderCompanion();
    if (!Number.isInteger(tabId)) {
      explainNoConnection();
      return;
    }
    await readStatus();
    if (storedResult.status === 'rejected') {
      statusMessage('Saved settings could not be read. Close and reopen Page Navigator to try again.', true);
    }
  } catch (error) {
    statusMessage(`Could not open Page Navigator. ${error?.message || 'Try closing and reopening this popup.'}`, true);
  }
})();

window.addEventListener('unload', () => {
  clearTimeout(refreshTimer);
  clearTimeout(searchTimer);
  clearTimeout(searchRefreshTimer);
});
