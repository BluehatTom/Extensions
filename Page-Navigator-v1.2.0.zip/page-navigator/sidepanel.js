(() => {
  'use strict';

  const CONNECTOR = 'http://127.0.0.1:43127';
  const CONNECTION_KEY = 'pnChatConnection';
  const EMPTY_SEARCH = Object.freeze({query: '',count: 0,index: 0,limited: false,busy: false});
  const CHAT_TIMEOUT_MS = 100000;

  function canonicalPage(value) {
    try {
      const url = new URL(value);
      if (!['http:', 'https:', 'file:'].includes(url.protocol)) return '';
      if (!/^#!?\//.test(url.hash)) url.hash = '';
      return url.href;
    } catch { return ''; }
  }

  function normalizeText(value) { return String(value || '').replace(/\s+/g, ' ').trim(); }

  function validateContext(raw, scope) {
    if (!raw || typeof raw !== 'object' || !['page', 'selection'].includes(raw.scope) || (scope && raw.scope !== scope)) throw new Error('The page returned an invalid text selection. Choose the text again.');
    if (typeof raw.id !== 'string' || !/^[\w-]{1,120}$/.test(raw.id) || typeof raw.url !== 'string' || raw.url.length > 4096 || !canonicalPage(raw.url)) throw new Error('The page context is no longer available. Refresh the page and try again.');
    if (!Array.isArray(raw.blocks) || !raw.blocks.length || raw.blocks.length > 200) throw new Error('No readable text was found. Try highlighting a passage and choosing Use selection.');
    const seen = new Set();
    let characters = 0;
    const blocks = raw.blocks.map(block => {
      if (!block || typeof block.id !== 'string' || !/^[\w-]{1,120}$/.test(block.id) || seen.has(block.id) || typeof block.text !== 'string' || !block.text.trim() || block.text.length > 6000) throw new Error('The page returned an invalid passage. Choose the text again.');
      seen.add(block.id);
      characters += block.text.length;
      return Object.freeze({id: block.id,text: block.text,label: String(block.label || 'Passage').slice(0,120)});
    });
    if (characters > 60000) throw new Error('The selected text is too long. Choose a smaller passage.');
    return Object.freeze({id: raw.id,url: raw.url,title: String(raw.title || 'Current page').slice(0,500),scope: raw.scope,capturedAt: Number.isFinite(raw.capturedAt) ? raw.capturedAt : Date.now(),characters,truncated: raw.truncated === true,blocks: Object.freeze(blocks)});
  }

  function safeCitations(context, values) {
    const blocks = new Map(context.blocks.map(block => [block.id, block]));
    const seen = new Set();
    const result = [];
    for (const item of Array.isArray(values) ? values.slice(0,30) : []) {
      const block = blocks.get(item?.blockId);
      const quote = typeof item?.quote === 'string' ? item.quote.trim() : '';
      if (!block || seen.has(block.id) || !quote || quote.length > 1500 || !normalizeText(block.text).includes(normalizeText(quote))) continue;
      seen.add(block.id);
      result.push({blockId: block.id,quote,label: block.label});
      if (result.length === 12) break;
    }
    return result;
  }

  function recentMessages(messages, contextId, question) {
    const history = messages.filter(message => message.context.id === contextId && message.status === 'complete');
    const result = [{role: 'user',content: question}];
    let characters = question.length;
    // Include complete recent turns. Never silently cut a prior question or answer in half.
    for (let index = history.length - 1; index >= 1; index -= 2) {
      const assistant = history[index];
      const user = history[index - 1];
      if (assistant.role !== 'assistant' || user.role !== 'user') break;
      if (result.length + 2 > 12 || characters + user.text.length + assistant.text.length > 20000) break;
      result.unshift({role: 'user',content: user.text},{role: 'assistant',content: assistant.text});
      characters += user.text.length + assistant.text.length;
    }
    return result;
  }

  function appendInline(document, parent, text) {
    // Text nodes are the only route for page/model text into the document.
    for (const part of String(text).split(/(`[^`\n]+`|\*\*[^*\n]+\*\*|__[^_\n]+__|\*[^*\n]+\*)/g)) {
      if (!part) continue;
      let tag, value;
      if (part.startsWith('`') && part.endsWith('`')) { tag = 'code'; value = part.slice(1,-1); }
      else if ((part.startsWith('**') && part.endsWith('**')) || (part.startsWith('__') && part.endsWith('__'))) { tag = 'strong'; value = part.slice(2,-2); }
      else if (part.startsWith('*') && part.endsWith('*')) { tag = 'em'; value = part.slice(1,-1); }
      if (tag) { const element = document.createElement(tag); element.textContent = value; parent.append(element); }
      else parent.append(document.createTextNode(part));
    }
  }

  function tableCells(line) {
    return line.trim().replace(/^\|/, '').replace(/\|$/, '').split(/(?<!\\)\|/).map(cell => cell.trim().replace(/\\\|/g, '|'));
  }

  function renderMarkdown(document, parent, text) {
    const lines = String(text).slice(0,24000).replace(/\r\n?/g, '\n').split('\n');
    let index = 0;
    while (index < lines.length) {
      const line = lines[index];
      if (!line.trim()) { index++; continue; }
      if (/^\s*```/.test(line)) {
        index++;
        const code = [];
        while (index < lines.length && !/^\s*```/.test(lines[index])) code.push(lines[index++]);
        if (index < lines.length) index++;
        const pre = document.createElement('pre');
        const element = document.createElement('code'); element.textContent = code.join('\n'); pre.append(element); parent.append(pre); continue;
      }
      if (index + 1 < lines.length && line.includes('|') && /^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(lines[index + 1])) {
        const headers = tableCells(line);
        const wrap = document.createElement('div'); wrap.className = 'table-scroll';
        const table = document.createElement('table');
        const head = document.createElement('thead'); const headRow = document.createElement('tr');
        for (const value of headers) { const th = document.createElement('th'); th.setAttribute('scope','col'); appendInline(document,th,value); headRow.append(th); }
        head.append(headRow); table.append(head);
        const body = document.createElement('tbody'); index += 2;
        while (index < lines.length && lines[index].includes('|') && lines[index].trim()) {
          const values = tableCells(lines[index++]); const tr = document.createElement('tr');
          for (let cell = 0; cell < headers.length; cell++) { const td = document.createElement('td'); appendInline(document,td,values[cell] || ''); tr.append(td); }
          body.append(tr);
        }
        table.append(body); wrap.append(table); parent.append(wrap); continue;
      }
      const heading = line.match(/^\s{0,3}(#{1,6})\s+(.+)$/);
      if (heading) { const element = document.createElement(`h${Math.min(6,heading[1].length + 3)}`); appendInline(document,element,heading[2]); parent.append(element); index++; continue; }
      const list = line.match(/^\s*(?:([-*+])|(\d+)\.)\s+(.+)$/);
      if (list) {
        const ordered = !!list[2]; const element = document.createElement(ordered ? 'ol' : 'ul');
        while (index < lines.length) {
          const item = lines[index].match(/^\s*(?:([-*+])|(\d+)\.)\s+(.+)$/);
          if (!item || !!item[2] !== ordered) break;
          const li = document.createElement('li'); appendInline(document,li,item[3]); element.append(li); index++;
        }
        parent.append(element); continue;
      }
      const paragraph = [line]; index++;
      while (index < lines.length && lines[index].trim() && !/^\s*(?:```|#{1,6}\s|[-*+]\s|\d+\.\s)/.test(lines[index])) {
        if (index + 1 < lines.length && lines[index].includes('|') && /^\s*\|?\s*:?-{3,}/.test(lines[index + 1])) break;
        paragraph.push(lines[index++]);
      }
      const p = document.createElement('p'); appendInline(document,p,paragraph.join('\n')); parent.append(p);
    }
  }

  class PageChatController {
    constructor({chromeApi,fetchImpl,notify = () => {},setTimer = setTimeout,clearTimer = clearTimeout}) {
      this.chrome = chromeApi;
      this.fetch = fetchImpl;
      this.notify = notify;
      this.setTimer = setTimer;
      this.clearTimer = clearTimer;
      this.windowId = null;
      this.token = '';
      this.enabled = true;
      this.alive = true;
      this.pageEpoch = 0;
      this.pageRead = 0;
      this.pageTask = null;
      this.contextRead = 0;
      this.connectionRead = 0;
      this.chatSequence = 0;
      this.messageSequence = 0;
      this.searchVersion = 0;
      this.searchTimer = null;
      this.searchComposing = false;
      this.searchHydrated = false;
      this.searchEdited = false;
      this.queuedMatch = null;
      this.activeChat = null;
      this.state = {
        page: null,pageNotice: '',context: null,contextNotice: '',contextError: false,capturing: false,
        messages: [],prompt: '',chatBusy: false,chatNotice: 'Connect the assistant to send questions.',chatError: false,
        connection: {state: 'unconfigured',model: '',message: 'Start the local connector, then enter its connection code.',error: false},
        search: {...EMPTY_SEARCH},searchInput: '',searchPending: false,searchError: '',navigationBusy: false
      };
    }

    emit(kind = 'state') { if (this.alive) this.notify(this.state,kind); }
    available() { return this.enabled && !!this.state.page?.available && !!this.state.page?.enabled; }
    current(epoch,tabId) { return this.alive && epoch === this.pageEpoch && tabId === this.state.page?.tabId; }
    notice(message,error = false) { this.state.chatNotice = message; this.state.chatError = error; this.emit('notice'); }

    async withTimeout(promise, milliseconds, message) {
      let timer;
      try {
        return await Promise.race([promise,new Promise((_,reject) => { timer = this.setTimer(() => reject(new Error(message)), milliseconds); })]);
      } finally { this.clearTimer(timer); }
    }

    async initialize() {
      const results = await Promise.allSettled([
        this.chrome.storage.local.get(['pnSettings',CONNECTION_KEY]),
        this.chrome.windows.getCurrent()
      ]);
      if (!this.alive) return;
      if (results[0].status === 'fulfilled') {
        const saved = results[0].value;
        this.enabled = saved.pnSettings?.enabled !== false;
        if (typeof saved[CONNECTION_KEY]?.token === 'string') this.token = saved[CONNECTION_KEY].token.trim();
      }
      if (results[1].status === 'fulfilled' && Number.isInteger(results[1].value?.id)) this.windowId = results[1].value.id;
      this.emit('initialize');
      const tasks = [this.refreshActive()];
      if (this.token) tasks.push(this.connect(this.token,{save: false}));
      await Promise.allSettled(tasks);
    }

    resetPage(page, message = '') {
      this.cancelChat('',false);
      this.pageEpoch++;
      this.contextRead++;
      this.searchVersion++;
      this.clearTimer(this.searchTimer); this.searchTimer = null;
      this.searchComposing = false; this.searchHydrated = false; this.searchEdited = false; this.queuedMatch = null;
      this.state.page = page;
      this.state.pageNotice = message;
      this.state.context = null; this.state.capturing = false; this.state.contextNotice = ''; this.state.contextError = false;
      this.state.messages = []; this.state.prompt = ''; this.state.navigationBusy = false;
      this.state.search = {...EMPTY_SEARCH}; this.state.searchInput = ''; this.state.searchPending = false; this.state.searchError = '';
      this.state.chatNotice = message || 'Choose the page or a selection to start a conversation.'; this.state.chatError = false;
      this.emit('page');
    }

    loading(tabId) {
      if (this.state.page?.tabId !== tabId) return;
      this.pageRead++;
      this.pageTask = null;
      this.resetPage({...this.state.page,available: false,enabled: false},'Page changed. Waiting for the page to finish loading…');
    }

    refreshActive({force = false} = {}) {
      // Polling, focus, and a user's action may all request the same fresh status.
      // Share that read so routine refreshes cannot starve the user's operation.
      if (this.pageTask && !force) return this.pageTask;
      const task = this.readActivePage();
      this.pageTask = task;
      const finished = () => { if (this.pageTask === task) this.pageTask = null; };
      task.then(finished,finished);
      return task;
    }

    async readActivePage() {
      const read = ++this.pageRead;
      const query = Number.isInteger(this.windowId) ? {active: true,windowId: this.windowId} : {active: true,currentWindow: true};
      let tab;
      try {
        [tab] = await this.chrome.tabs.query(query);
        if (!this.alive || read !== this.pageRead) return false;
        if (!Number.isInteger(tab?.id)) {
          if (this.state.page || this.state.context) this.resetPage(null,'Open an ordinary webpage to use Page Navigator.');
          else { this.state.pageNotice = 'Open an ordinary webpage to use Page Navigator.'; this.emit('page'); }
          return false;
        }
        if (this.state.page?.tabId !== tab.id) this.resetPage({tabId: tab.id,windowId: tab.windowId,url: '',title: 'Current page',available: false,enabled: false},'Choose text from this tab to start a conversation.');
        const status = await this.withTimeout(this.chrome.tabs.sendMessage(tab.id,{type: 'PN_STATUS'},{frameId: 0}),5000,'The page did not respond. Refresh it to reconnect.');
        if (!this.alive || read !== this.pageRead || tab.id !== this.state.page?.tabId) return false;
        if (!status?.ok) throw new Error(status?.error || 'Page Navigator is unavailable on this tab.');
        // PN_STATUS supplies these fields without requiring the broad tabs permission.
        const url = canonicalPage(status.pageUrl || status.url || tab.url || '');
        const title = String(status.pageTitle || status.title || tab.title || status.hostname || 'Current page').slice(0,500);
        const page = {tabId: tab.id,windowId: tab.windowId,url,title,available: true,enabled: this.enabled && !status.disabledOnSite && status.enabled !== false};
        if ((this.state.page.url && url && this.state.page.url !== url) || (this.state.context && (!page.enabled || canonicalPage(this.state.context.url) !== url))) {
          this.resetPage(page,page.enabled ? 'Page changed. Choose the page or selection again.' : 'Page Navigator is disabled on this page. Enable it from the extension popup.');
        } else this.state.page = page;
        this.state.pageNotice = page.enabled ? '' : 'Page Navigator is disabled on this page. Enable it from the extension popup.';
        if (!url) this.state.pageNotice = 'Refresh this page after updating the extension so page chat can identify it.';
        this.acceptSearch(status);
        this.emit('page-status');
        return page.enabled && !!url;
      } catch (error) {
        if (!this.alive || read !== this.pageRead) return false;
        const unavailable = 'Page content is unavailable. Refresh an ordinary webpage. Chrome system pages, the Web Store, and the built-in PDF viewer are not supported.';
        if (this.state.context || this.state.messages.length || this.state.chatBusy) this.resetPage(tab ? {tabId: tab.id,windowId: tab.windowId,url: '',title: 'Page unavailable',available: false,enabled: false} : null,unavailable);
        else {
          if (this.state.page) this.state.page = {...this.state.page,available: false,enabled: false};
          this.state.pageNotice = unavailable;
          this.state.searchPending = false;
          this.emit('page-status');
        }
        return false;
      }
    }

    async capture(scope) {
      if (this.state.capturing || this.state.chatBusy) return;
      if (!this.available()) { this.state.contextNotice = 'Enable Page Navigator on an ordinary webpage before choosing text.'; this.state.contextError = true; this.emit('context'); return; }
      const tabId = this.state.page.tabId, epoch = this.pageEpoch, read = ++this.contextRead;
      this.state.capturing = true; this.state.contextNotice = scope === 'selection' ? 'Reading your selection…' : 'Reading loaded page text…'; this.state.contextError = false; this.emit('context');
      try {
        const ready = await this.refreshActive();
        if (!ready || !this.current(epoch,tabId) || read !== this.contextRead) return;
        const response = await this.withTimeout(this.chrome.tabs.sendMessage(tabId,{type: 'PN_CONTEXT',scope},{frameId: 0}),12000,'Reading the page took too long. Try a smaller selection.');
        if (!this.current(epoch,tabId) || read !== this.contextRead) return;
        if (!response?.ok) throw new Error(response?.error || 'Could not read the page text. Refresh the page and try again.');
        const context = validateContext(response.context,scope);
        if (canonicalPage(context.url) !== this.state.page.url) { await this.refreshActive(); throw new Error('The page changed while text was being selected. Choose the text again.'); }
        this.state.context = context;
        this.state.contextNotice = `${scope === 'selection' ? 'Selection' : 'Page text'} is ready. Ask a question below.`;
        this.state.contextError = false;
        this.state.chatNotice = this.state.connection.state === 'connected' ? 'Your chosen text will be sent with your question.' : 'Connect the assistant to send questions.';
        this.state.chatError = false;
        this.emit('context');
      } catch (error) {
        if (this.current(epoch,tabId) && read === this.contextRead) { this.state.contextNotice = error.message || 'Could not read the page.'; this.state.contextError = true; this.emit('context'); }
      } finally {
        if (this.current(epoch,tabId) && read === this.contextRead) { this.state.capturing = false; this.emit('context'); }
      }
    }

    clearContext() {
      this.contextRead++; this.cancelChat('',false);
      this.state.context = null; this.state.capturing = false; this.state.contextNotice = 'Context removed. Choose text before sending another question.'; this.state.contextError = false;
      this.emit('context');
    }

    newChat() {
      this.clearContext(); this.state.messages = []; this.state.prompt = '';
      this.state.contextNotice = ''; this.state.chatNotice = 'New conversation. Choose the page or a selection.'; this.state.chatError = false;
      this.emit('messages');
    }

    async parseJSON(response) {
      const text = await response.text();
      if (text.length > 180000) throw new Error('The connector returned too much data. Try a shorter question.');
      try { return JSON.parse(text); }
      catch { throw new Error('The local connector returned an invalid response. Restart it and try again.'); }
    }

    async connect(code,{save = true} = {}) {
      const token = String(code || '').trim();
      const request = ++this.connectionRead;
      if (!/^[A-Za-z0-9_-]{32,256}$/.test(token) || token.startsWith('sk-')) {
        this.state.connection = {...this.state.connection,state: 'error',message: token.startsWith('sk-') ? 'Enter the connector’s connection code here. Enter your API key only in its local setup screen.' : 'Paste the complete connection code from the local connector.',error: true};
        this.emit('connection'); return false;
      }
      this.cancelChat('',false);
      this.state.connection = {state: 'connecting',model: '',message: 'Checking the local connector…',error: false}; this.emit('connection');
      const controller = new AbortController();
      const timer = this.setTimer(() => controller.abort(),7000);
      try {
        const response = await this.fetch(`${CONNECTOR}/status`,{method: 'GET',headers: {Authorization: `Bearer ${token}`},cache: 'no-store',redirect: 'error',signal: controller.signal});
        const data = await this.parseJSON(response);
        if (!this.alive || request !== this.connectionRead) return false;
        if (!response.ok || !data?.ok) throw new Error(data?.error || (response.status === 401 ? 'The connection code was not accepted. Copy it again from the connector.' : 'The local connector is not ready.'));
        this.token = token;
        let saved = true;
        if (save) {
          try { await this.chrome.storage.local.set({[CONNECTION_KEY]: {token}}); }
          catch { saved = false; }
          if (!this.alive || request !== this.connectionRead) return false;
        }
        this.state.connection = {
          state: data.configured === true ? 'connected' : 'needs-key',model: String(data.model || '').slice(0,100),
          message: data.configured === true ? (saved ? 'Connected. You can ask about the page or your selection.' : 'Connected for this sidebar session. The connection code could not be saved.') : 'Connector found. Complete its local setup with your API key, then choose Connect again.',error: data.configured !== true
        };
        this.state.chatNotice = data.configured === true ? (this.state.context ? 'Ready. Ask about your chosen text.' : 'Choose the page or a selection to start chatting.') : 'Complete the connector setup to send questions.';
        this.state.chatError = false; this.emit('connection'); return data.configured === true;
      } catch (error) {
        if (!this.alive || request !== this.connectionRead) return false;
        const failedNetwork = error instanceof TypeError || error.name === 'AbortError';
        const message = failedNetwork ? 'The local connector could not be reached. Run START-WINDOWS.cmd and keep its window open, then connect again.' : String(error.message || 'Could not connect.').replaceAll(token,'[connection code]');
        this.state.connection = {state: 'error',model: '',message,error: true};
        this.state.chatNotice = 'Connect the local assistant to send questions.'; this.state.chatError = false; this.emit('connection'); return false;
      } finally { this.clearTimer(timer); }
    }

    async forgetConnection() {
      this.connectionRead++; this.cancelChat('',false); this.token = '';
      this.state.connection = {state: 'unconfigured',model: '',message: 'Connection forgotten. You can enter a new code at any time.',error: false};
      this.state.chatNotice = 'Connect the assistant to send questions.'; this.state.chatError = false; this.emit('connection');
      try { await this.chrome.storage.local.remove(CONNECTION_KEY); }
      catch { this.state.connection.message = 'Disconnected for this sidebar session, but the saved code could not be removed. Try Forget connection again.'; this.state.connection.error = true; this.emit('connection'); }
    }

    setPrompt(value) { this.state.prompt = String(value || '').slice(0,4000); this.emit('prompt'); }

    async sendQuestion() {
      if (this.state.chatBusy) return;
      const question = this.state.prompt.trim();
      if (!question) { this.notice('Write a question first.'); return; }
      if (question.length > 4000) { this.notice('Keep your question within 4,000 characters.',true); return; }
      if (this.state.connection.state !== 'connected' || !this.token) { this.notice('Connect the local assistant first. Your API key belongs in the connector setup screen.',true); return; }
      if (!this.state.context || !this.available()) { this.notice('Choose Use this page or Use selection before sending.',true); return; }
      const context = this.state.context, epoch = this.pageEpoch, tabId = this.state.page.tabId;
      const serial = ++this.chatSequence;
      const request = {serial,epoch,tabId,context,question,controller: new AbortController(),messageId: `m${++this.messageSequence}`,timer: null,timedOut: false,completed: false,failed: false};
      this.activeChat = request; this.state.chatBusy = true; this.state.chatNotice = 'Checking the page…'; this.state.chatError = false; this.emit('busy');
      const current = () => this.activeChat === request && this.current(epoch,tabId) && this.state.context?.id === context.id;
      try {
        if (!(await this.refreshActive()) || !current()) return;
        const messages = recentMessages(this.state.messages,context.id,question);
        this.state.messages.push({id: request.messageId,role: 'user',text: question,status: 'pending',context,tabId});
        this.state.chatNotice = 'Asking about your chosen text…'; this.emit('messages');
        request.timer = this.setTimer(() => { request.timedOut = true; request.controller.abort(); },CHAT_TIMEOUT_MS);
        const response = await this.fetch(`${CONNECTOR}/chat`,{
          method: 'POST',headers: {'Content-Type': 'application/json',Authorization: `Bearer ${this.token}`},
          body: JSON.stringify({context,messages}),cache: 'no-store',redirect: 'error',signal: request.controller.signal
        });
        const data = await this.parseJSON(response);
        if (!current()) return;
        if (!response.ok || !data?.ok) throw new Error(data?.error || 'The assistant could not answer. Your question is still here so you can try again.');
        if (typeof data.answer !== 'string' || !data.answer.trim() || data.answer.length > 24000) throw new Error('The assistant returned an invalid answer. Try a shorter question.');
        // An SPA can change its route without a tab loading event. Verify the page again.
        if (!(await this.refreshActive()) || !current()) return;
        const user = this.state.messages.find(message => message.id === request.messageId);
        if (!user) return;
        user.status = 'complete';
        request.completed = true;
        this.state.messages.push({id: `m${++this.messageSequence}`,role: 'assistant',text: data.answer,status: 'complete',context,tabId,citations: safeCitations(context,data.citations),model: String(data.model || '').slice(0,100)});
        while (this.state.messages.length > 60) this.state.messages.splice(0,2);
        if (this.state.prompt.trim() === question) this.state.prompt = '';
        this.state.chatNotice = 'Answer ready. Source buttons jump to passages on the page.'; this.state.chatError = false; this.emit('messages');
      } catch (error) {
        if (!current()) return;
        request.failed = true;
        this.state.messages = this.state.messages.filter(message => message.id !== request.messageId);
        let message;
        if (request.timedOut) message = 'The answer took too long. Your question is still here; you can send it again.';
        else if (error.name === 'AbortError') message = 'Stopped waiting for the answer. Your question is still here.';
        else if (error instanceof TypeError) message = 'The local connector could not be reached. Start it again, then retry your question.';
        else message = String(error.message || 'Could not get an answer. Try again.').replaceAll(this.token,'[connection code]');
        this.state.chatNotice = message; this.state.chatError = true; this.emit('messages');
      } finally {
        this.clearTimer(request.timer);
        if (this.activeChat === request) {
          if (!request.completed) {
            this.state.messages = this.state.messages.filter(message => message.id !== request.messageId);
            if (!request.failed) { this.state.chatNotice = 'The page could not be verified. Your question is still here; try again when the page is ready.'; this.state.chatError = true; }
          }
          this.activeChat = null; this.state.chatBusy = false; this.emit('busy');
        }
      }
    }

    cancelChat(message = 'Stopped waiting for the answer. Your question is still here.',emit = true) {
      if (this.activeChat) {
        const request = this.activeChat;
        this.activeChat = null; this.chatSequence++; this.clearTimer(request.timer); request.controller.abort();
        this.state.messages = this.state.messages.filter(item => item.id !== request.messageId || item.status === 'complete');
      }
      this.state.chatBusy = false;
      if (message) { this.state.chatNotice = message; this.state.chatError = false; }
      if (emit) this.emit('messages');
    }

    async jumpToSource(messageId,blockId) {
      const message = this.state.messages.find(item => item.id === messageId && item.role === 'assistant');
      if (!message || !message.citations.some(item => item.blockId === blockId)) return;
      const epoch = this.pageEpoch;
      if (!(await this.refreshActive()) || !this.current(epoch,message.tabId) || this.state.page.url !== canonicalPage(message.context.url)) { this.state.contextNotice = 'That source belongs to a different page. Choose text from this page again.'; this.state.contextError = true; this.emit('context'); return; }
      try {
        const result = await this.chrome.tabs.sendMessage(message.tabId,{type: 'PN_CONTEXT_JUMP',contextId: message.context.id,blockId},{frameId: 0});
        if (!this.current(epoch,message.tabId)) return;
        if (!result?.ok) throw new Error(result?.error || 'That passage has changed. Choose the page again to refresh its sources.');
        this.state.contextNotice = 'Moved to the source passage.'; this.state.contextError = false; this.emit('context');
      } catch (error) {
        if (this.current(epoch,message.tabId)) { this.state.contextNotice = error.message || 'The source passage is no longer available.'; this.state.contextError = true; this.emit('context'); }
      }
    }

    acceptSearch(status) {
      if (!this.searchHydrated) { if (!this.searchEdited) this.state.searchInput = String(status.searchQuery || '').slice(0,200); this.searchHydrated = true; }
      if (this.state.searchPending || String(status.searchQuery || '').trim() !== this.state.searchInput.trim()) return;
      const count = Math.max(0,Number(status.searchCount) || 0);
      this.state.search = {query: String(status.searchQuery || ''),count,index: Math.min(count,Math.max(0,Number(status.searchIndex) || 0)),limited: !!status.searchLimited,busy: !!status.searchBusy};
    }

    setSearch(value,{composing = false,immediate = false} = {}) {
      this.clearTimer(this.searchTimer); this.searchTimer = null;
      this.searchEdited = true; this.searchComposing = composing; this.queuedMatch = null;
      const version = ++this.searchVersion;
      this.state.searchInput = String(value || '').slice(0,200); this.state.searchError = '';
      this.state.searchPending = this.available();
      if (!this.state.searchInput.trim()) this.state.search = {...EMPTY_SEARCH};
      this.emit('search');
      if (composing || !this.available()) return;
      const query = this.state.searchInput;
      const run = () => { this.searchTimer = null; this.requestSearch(query.trim() ? 'search' : 'clear-search',query,version); };
      if (immediate || !query.trim()) run();
      else this.searchTimer = this.setTimer(run,180);
    }

    async requestSearch(action,query,version) {
      if (!this.available() || version !== this.searchVersion) return;
      const epoch = this.pageEpoch, tabId = this.state.page.tabId;
      try {
        const message = {type: 'PN_ACTION',action,source: 'popup'};
        if (action === 'search') message.value = query;
        const result = await this.chrome.tabs.sendMessage(tabId,message,{frameId: 0});
        if (!this.current(epoch,tabId) || version !== this.searchVersion || query.trim() !== this.state.searchInput.trim()) return;
        this.state.searchPending = false;
        if (!result?.ok) throw new Error(result?.error || 'Search could not be completed.');
        if (String(result.searchQuery || '').trim() !== query.trim()) throw new Error('The page changed during search. Type again to update the results.');
        this.acceptSearch(result); this.state.searchError = ''; this.emit('search');
        const queued = this.queuedMatch; this.queuedMatch = null;
        if (queued && this.state.search.count) this.moveMatch(queued);
      } catch (error) {
        if (!this.current(epoch,tabId) || version !== this.searchVersion) return;
        this.state.searchPending = false; this.queuedMatch = null; this.state.searchError = error.message || 'Refresh the page to reconnect search.'; this.emit('search');
      }
    }

    moveMatch(action) {
      if (!this.available() || this.searchComposing || !this.state.searchInput.trim()) return;
      if (this.state.searchPending) {
        this.queuedMatch = action;
        if (this.searchTimer !== null) { this.clearTimer(this.searchTimer); this.searchTimer = null; this.requestSearch('search',this.state.searchInput,this.searchVersion); }
        return;
      }
      if (this.state.search.query.trim() !== this.state.searchInput.trim()) {
        this.queuedMatch = action; this.state.searchPending = true;
        const version = ++this.searchVersion; this.emit('search'); this.requestSearch('search',this.state.searchInput,version); return;
      }
      if (this.state.search.busy || !this.state.search.count) return;
      this.state.searchPending = true;
      const version = ++this.searchVersion; this.emit('search'); this.requestSearch(action,this.state.searchInput,version);
    }

    async navigate(action) {
      if (!['top','middle','end'].includes(action) || !this.available() || this.state.navigationBusy) return;
      const tabId = this.state.page.tabId, epoch = this.pageEpoch;
      this.state.navigationBusy = true; this.emit('navigation');
      try {
        const response = await this.chrome.tabs.sendMessage(tabId,{type: 'PN_ACTION',action,source: 'popup'},{frameId: 0});
        if (!this.current(epoch,tabId)) return;
        if (!response?.ok) throw new Error(response?.error || 'Navigation could not be completed.');
        this.state.pageNotice = ''; this.emit('navigation');
      } catch (error) {
        if (this.current(epoch,tabId)) { this.state.pageNotice = error.message || 'Refresh this page to reconnect navigation.'; this.emit('navigation'); }
      } finally { if (this.current(epoch,tabId)) { this.state.navigationBusy = false; this.emit('navigation'); } }
    }

    async storageChanged(changes,area) {
      if (area !== 'local') return;
      if (changes.pnSettings) {
        this.enabled = changes.pnSettings.newValue?.enabled !== false;
        if (!this.enabled && this.state.page) this.resetPage({...this.state.page,enabled: false},'Page Navigator is disabled. Enable it from the extension popup.');
      }
      if (changes.pnSettings || changes.pnDisabledSites) this.refreshActive();
      if (changes[CONNECTION_KEY]) {
        const next = String(changes[CONNECTION_KEY].newValue?.token || '').trim();
        if (next === this.token) return;
        if (next) this.connect(next,{save: false});
        else { this.connectionRead++; this.cancelChat('',false); this.token = ''; this.state.connection = {state: 'unconfigured',model: '',message: 'Enter a connection code to connect.',error: false}; this.state.chatNotice = 'Connect the assistant to send questions.'; this.state.chatError = false; this.emit('connection'); }
      }
    }

    dispose() { this.alive = false; this.pageRead++; this.connectionRead++; this.contextRead++; this.cancelChat('',false); this.clearTimer(this.searchTimer); }
  }

  function boot() {
    const $ = selector => document.querySelector(selector);
    const controller = new PageChatController({chromeApi: chrome,fetchImpl: (...args) => fetch(...args),notify: render});
    const renderedMessages = new Map();
    let previewId = null;
    let connectionShown = false;
    const question = $('#question'), search = $('#page-search'), dialog = $('#connection-dialog');

    function showNotice(element,text,error = false) { element.textContent = text; element.hidden = !text; element.classList.toggle('error',error); }

    function renderMessages(state) {
      const log = $('#conversation'), area = $('#chat-area');
      const nearBottom = area.scrollHeight - area.scrollTop - area.clientHeight < 90;
      const present = new Set(state.messages.map(message => message.id));
      for (const [id,node] of renderedMessages) if (!present.has(id)) { node.remove(); renderedMessages.delete(id); }
      let added = false;
      for (const message of state.messages) {
        if (renderedMessages.has(message.id)) continue;
        const article = document.createElement('article'); article.className = `message ${message.role}`;
        const heading = document.createElement('h3'); heading.className = 'message-heading';
        const author = document.createElement('span'); author.textContent = message.role === 'user' ? 'You' : 'Page assistant';
        const scope = document.createElement('span'); scope.className = 'message-scope'; scope.textContent = message.context.scope === 'selection' ? 'Selected text' : 'Page text'; scope.title = message.context.title;
        heading.append(author,scope); article.append(heading);
        const body = document.createElement('div'); body.className = 'message-body';
        if (message.role === 'assistant') renderMarkdown(document,body,message.text);
        else { const paragraph = document.createElement('p'); paragraph.textContent = message.text; body.append(paragraph); }
        article.append(body);
        if (message.citations?.length) {
          const sources = document.createElement('div'); sources.className = 'sources';
          const label = document.createElement('p'); label.className = 'sources-label'; label.textContent = 'Jump to a source'; sources.append(label);
          message.citations.forEach((citation,index) => {
            const button = document.createElement('button'); button.type = 'button'; button.className = 'source-button';
            const name = document.createElement('strong'); name.textContent = `${index + 1}. ${citation.label}`;
            const quote = document.createElement('span'); quote.textContent = citation.quote.length > 170 ? `${citation.quote.slice(0,167)}…` : citation.quote;
            button.title = `${message.context.title}\n${citation.quote}`; button.append(name,quote);
            button.addEventListener('click',() => controller.jumpToSource(message.id,citation.blockId)); sources.append(button);
          });
          article.append(sources);
        }
        renderedMessages.set(message.id,article); log.append(article); added = true;
      }
      $('#empty-chat').hidden = state.messages.length > 0;
      $('#thinking').hidden = !state.chatBusy;
      if (added && nearBottom) area.scrollTop = area.scrollHeight;
    }

    function renderPreview(context) {
      $('#context-preview').hidden = !context;
      if (context?.id === previewId) return;
      previewId = context?.id || null;
      $('#context-blocks').replaceChildren();
      $('#context-preview').open = false;
      if (!context) return;
      $('#context-summary').textContent = `${context.scope === 'selection' ? 'Selection' : 'Page text'} · ${context.characters.toLocaleString()} characters · Preview`;
      $('#context-source').textContent = context.title;
      $('#context-source').title = context.url;
      const limit = $('#context-limit'); limit.hidden = !context.truncated;
      limit.textContent = 'Only part of the loaded text fits in this context. Select a specific passage for a more focused answer.';
      for (const block of context.blocks) {
        const item = document.createElement('div'); item.className = 'context-block';
        const label = document.createElement('strong'); label.textContent = block.label;
        item.append(label,document.createTextNode(block.text)); $('#context-blocks').append(item);
      }
    }

    function render(state,kind) {
      const available = controller.available();
      $('#page-title').textContent = state.page?.title || 'Open a webpage to begin';
      $('#page-title').title = state.page?.url || '';
      showNotice($('#page-status'),state.pageNotice,!!state.pageNotice && !available);
      document.querySelectorAll('[data-nav]').forEach(button => { button.disabled = !available || state.navigationBusy; });
      search.disabled = !available;
      if (search.value !== state.searchInput && (!controller.searchEdited || kind === 'page')) search.value = state.searchInput;
      const hasSearch = !!state.searchInput.trim();
      $('#clear-search').disabled = !available || !state.searchInput;
      const canMove = available && hasSearch && !state.searchPending && !state.search.busy && !controller.searchComposing && state.search.count > 0 && state.search.query.trim() === state.searchInput.trim();
      $('#previous-match').disabled = $('#next-match').disabled = !canMove;
      let searchCount = 'Searches as you type';
      if (!available) searchCount = 'Search is unavailable on this page';
      else if (state.searchError) searchCount = state.searchError;
      else if (hasSearch && (state.searchPending || state.search.busy || controller.searchComposing)) searchCount = 'Searching…';
      else if (hasSearch) searchCount = state.search.count ? `${state.search.index} of ${state.search.count} matches${state.search.limited ? ' · limited results' : ''}` : (state.search.limited ? 'Scan limit reached · no matches found' : 'No matches');
      $('#search-count').textContent = searchCount; $('#search-count').classList.toggle('error',!!state.searchError);
      $('#use-page').disabled = $('#use-selection').disabled = !available || state.capturing || state.chatBusy;
      $('#use-page-label').textContent = state.capturing ? 'Reading…' : 'Use this page';
      $('#clear-context').hidden = !state.context; $('#clear-context').disabled = state.capturing;
      renderPreview(state.context);
      showNotice($('#context-notice'),state.contextNotice,state.contextError);
      renderMessages(state);
      if (question.value !== state.prompt) question.value = state.prompt;
      question.disabled = state.chatBusy;
      $('#question-count').textContent = `${state.prompt.length.toLocaleString()} / 4,000`;
      $('#send-chat').hidden = state.chatBusy; $('#stop-chat').hidden = !state.chatBusy;
      $('#send-chat').disabled = state.chatBusy || state.capturing || !available || !state.context || !state.prompt.trim() || state.connection.state !== 'connected';
      document.querySelectorAll('[data-prompt]').forEach(button => { button.disabled = !state.context || state.chatBusy; });
      showNotice($('#chat-notice'),state.chatNotice,state.chatError);
      const connected = state.connection.state === 'connected';
      $('#connection-label').textContent = connected ? 'Connected' : (state.connection.state === 'connecting' ? 'Connecting' : 'Connect');
      $('#connection-dot').classList.toggle('ready',connected); $('#connection-dot').classList.toggle('error',state.connection.error);
      showNotice($('#connection-status'),state.connection.message,state.connection.error);
      $('#connection-model').hidden = !state.connection.model; $('#connection-model').textContent = state.connection.model ? `Model: ${state.connection.model}` : '';
      $('#connect').disabled = state.connection.state === 'connecting'; $('#forget-connection').disabled = !controller.token && !$('#connection-code').value;
      if (kind === 'initialize' && controller.token) $('#connection-code').value = controller.token;
      if (kind === 'messages' && state.messages.at(-1)?.role === 'assistant') $('#announcement').textContent = 'Answer ready. Source buttons are available below the answer.';
    }

    function openConnection() {
      if (controller.token && !$('#connection-code').value) $('#connection-code').value = controller.token;
      if (!dialog.open) dialog.showModal();
      connectionShown = true;
    }

    $('#connection-button').addEventListener('click',openConnection);
    $('#close-connection').addEventListener('click',() => dialog.close());
    $('#connection-form').addEventListener('submit',async event => {
      event.preventDefault();
      const connected = await controller.connect($('#connection-code').value);
      if (connected) { $('#announcement').textContent = 'Page chat connected.'; dialog.close(); question.focus(); }
    });
    $('#connection-code').addEventListener('input',() => { $('#forget-connection').disabled = !controller.token && !$('#connection-code').value; });
    $('#forget-connection').addEventListener('click',async () => { $('#connection-code').value = ''; await controller.forgetConnection(); });
    $('#use-page').addEventListener('click',() => controller.capture('page'));
    $('#use-selection').addEventListener('click',() => controller.capture('selection'));
    $('#clear-context').addEventListener('click',() => controller.clearContext());
    $('#new-chat').addEventListener('click',() => { controller.newChat(); question.focus(); });
    document.querySelectorAll('[data-nav]').forEach(button => button.addEventListener('click',() => controller.navigate(button.dataset.nav)));
    question.addEventListener('input',() => controller.setPrompt(question.value));
    question.addEventListener('keydown',event => {
      if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
        event.preventDefault();
        if (controller.state.connection.state !== 'connected') { controller.notice('Connect the assistant to send your question.'); openConnection(); }
        else controller.sendQuestion();
      }
    });
    $('#question-form').addEventListener('submit',event => { event.preventDefault(); controller.sendQuestion(); });
    $('#stop-chat').addEventListener('click',() => controller.cancelChat());
    document.querySelectorAll('[data-prompt]').forEach(button => button.addEventListener('click',() => {
      const prompts = {
        summarize: 'Summarize the key points and cite the supporting passages.',
        explain: `Explain ${controller.state.context?.scope === 'selection' ? 'the selected passage' : 'this page'} in plain language.`,
        find: 'Find the section about ',
        extract: 'Extract the dates, deadlines, and requirements into a table. Cite the supporting passages.'
      };
      controller.setPrompt(prompts[button.dataset.prompt]); question.focus(); question.setSelectionRange(question.value.length,question.value.length);
    }));
    search.addEventListener('input',event => controller.setSearch(search.value,{composing: event.isComposing || controller.searchComposing}));
    search.addEventListener('compositionstart',() => controller.setSearch(search.value,{composing: true}));
    search.addEventListener('compositionend',() => controller.setSearch(search.value));
    search.addEventListener('keydown',event => {
      if (event.isComposing || controller.searchComposing) return;
      if (event.key === 'Enter') { event.preventDefault(); controller.moveMatch(event.shiftKey ? 'previous-match' : 'next-match'); }
      else if (event.key === 'Escape' && search.value) { event.preventDefault(); search.value = ''; controller.setSearch('',{immediate: true}); }
    });
    $('#clear-search').addEventListener('click',() => { search.value = ''; controller.setSearch('',{immediate: true}); search.focus(); });
    $('#previous-match').addEventListener('click',() => controller.moveMatch('previous-match'));
    $('#next-match').addEventListener('click',() => controller.moveMatch('next-match'));
    const activated = info => { if (controller.windowId === null || info.windowId === controller.windowId) controller.refreshActive({force: true}); };
    const updated = (tabId,info) => { if (tabId !== controller.state.page?.tabId) return; if (info.status === 'loading') controller.loading(tabId); else if (info.status === 'complete' || info.url || info.title) controller.refreshActive(); };
    const removed = tabId => { if (tabId === controller.state.page?.tabId) { controller.resetPage(null,'The tab was closed.'); controller.refreshActive(); } };
    const storage = (changes,area) => controller.storageChanged(changes,area);
    chrome.tabs.onActivated.addListener(activated); chrome.tabs.onUpdated.addListener(updated); chrome.tabs.onRemoved.addListener(removed); chrome.storage.onChanged.addListener(storage);
    const timer = setInterval(() => { if (!document.hidden) controller.refreshActive(); },2000);
    window.addEventListener('focus',() => controller.refreshActive());
    window.addEventListener('unload',() => {
      clearInterval(timer); controller.dispose();
      chrome.tabs.onActivated.removeListener(activated); chrome.tabs.onUpdated.removeListener(updated); chrome.tabs.onRemoved.removeListener(removed); chrome.storage.onChanged.removeListener(storage);
    });
    controller.initialize().then(() => { if (!controller.token && !connectionShown) $('#connection-button').title = 'Connect the local assistant. Navigation and search are ready to use.'; });
  }

  if (typeof module !== 'undefined' && module.exports) module.exports = {PageChatController,canonicalPage,validateContext,safeCitations,recentMessages,renderMarkdown,CONNECTOR,CHAT_TIMEOUT_MS};
  else boot();
})();
