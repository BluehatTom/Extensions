'use strict';

// The active tab ID, windows API, and messaging API do not require "tabs".
const VALID_COMMANDS = new Set([
  'top', 'middle', 'end', 'toggle', 'page-up', 'page-down',
  'previous-heading', 'next-heading', 'previous-spot',
  'save-spot', 'restore-spot', 'outline', 'open-search'
]);
const COMPANION_URL = 'https://chatgpt.com/';
const COMPANION_SESSION_KEY = 'pnCompanionWindowsV1';
let companionRecords = null;
let companionQueue = Promise.resolve();
const pendingCompanions = new Map();

function validId(value) {
  return Number.isSafeInteger(value) && value >= 0;
}

function enqueueCompanion(operation) {
  const result = companionQueue.then(operation);
  companionQueue = result.catch(() => undefined);
  return result;
}

async function loadCompanions() {
  if (companionRecords) return;
  companionRecords = {};
  try {
    const stored = (await chrome.storage.session.get(COMPANION_SESSION_KEY))[COMPANION_SESSION_KEY];
    for (const context of ['normal', 'incognito']) {
      const record = stored?.[context];
      if (record && validId(record.windowId) && validId(record.tabId) && record.incognito === (context === 'incognito')) {
        companionRecords[context] = { windowId: record.windowId, tabId: record.tabId, incognito: record.incognito };
      }
    }
  } catch (_) {
    // A usable window can still be tracked in memory if session storage is unavailable.
  }
}

async function saveCompanions() {
  try {
    await chrome.storage.session.set({ [COMPANION_SESSION_KEY]: companionRecords });
  } catch (_) {
    // Creation/focus has already succeeded; a bookkeeping failure must not claim otherwise.
    console.warn('Page Navigator could not save companion ownership for this browser session.');
  }
}

function normalizedRect(value) {
  if (!value || !['left', 'top', 'width', 'height'].every(key => typeof value[key] === 'number' && Number.isFinite(value[key]))) return null;
  if (Math.abs(value.left) > 1000000 || Math.abs(value.top) > 1000000 || value.width < 1 || value.height < 1 || value.width > 100000 || value.height > 100000) return null;
  return {
    left: Math.round(value.left), top: Math.round(value.top),
    width: Math.max(1, Math.round(value.width)), height: Math.max(1, Math.round(value.height))
  };
}

function companionBounds(source, suppliedScreen) {
  const sourceRect = normalizedRect(source);
  let available = normalizedRect(suppliedScreen);
  // A stale screen snapshot from another monitor must not place this popup off the source display.
  if (available && sourceRect && (
    sourceRect.left >= available.left + available.width || sourceRect.left + sourceRect.width <= available.left ||
    sourceRect.top >= available.top + available.height || sourceRect.top + sourceRect.height <= available.top
  )) available = null;
  available = available || sourceRect;
  if (!available) return { width: 480, height: 720 };

  const marginX = Math.min(16, Math.floor((available.width - 1) / 2));
  const marginY = Math.min(16, Math.floor((available.height - 1) / 2));
  const width = Math.max(1, Math.min(480, available.width - marginX * 2));
  const height = Math.max(1, Math.min(720, available.height - marginY * 2));
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const idealLeft = sourceRect ? sourceRect.left + sourceRect.width - width - marginX : available.left + available.width - width - marginX;
  const idealTop = sourceRect ? sourceRect.top + marginY : available.top + marginY;
  return {
    width, height,
    left: clamp(idealLeft, available.left + marginX, available.left + available.width - marginX - width),
    top: clamp(idealTop, available.top + marginY, available.top + available.height - marginY - height)
  };
}

function isChatGPTUrl(value) {
  if (typeof value !== 'string' || !value) return false;
  try { return new URL(value).origin === 'https://chatgpt.com'; }
  catch (_) { return false; }
}

async function companionTabIsChatGPT(tab) {
  // Prefer the destination of an in-flight navigation over the page it is leaving.
  const url = typeof tab.pendingUrl === 'string' && tab.pendingUrl ? tab.pendingUrl : tab.url;
  if (typeof url === 'string' && url) return isChatGPTUrl(url);

  // Chrome may omit URLs without a host/tabs permission. Ask our existing top-frame
  // content script for its hostname; page scripts cannot forge this internal reply.
  // Failure, a restricted page, or a navigation to another host is never treated as proof.
  let timer;
  try {
    const status = await Promise.race([
      chrome.tabs.sendMessage(tab.id, { type: 'PN_STATUS' }, { frameId: 0 }),
      new Promise(resolve => { timer = setTimeout(() => resolve(null), 1500); })
    ]);
    return status?.ok === true && status.hostname === 'chatgpt.com';
  } catch (_) {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

async function reusableCompanion(record, incognito) {
  if (!record) return null;
  try {
    const window = await chrome.windows.get(record.windowId, { populate: true });
    if (window.id !== record.windowId || window.type !== 'popup' || window.incognito !== incognito || record.incognito !== incognito) return null;
    let tab = window.tabs?.find(item => item.id === record.tabId);
    if (!tab) tab = await chrome.tabs.get(record.tabId);
    if (tab.id !== record.tabId || tab.windowId !== record.windowId || tab.incognito !== incognito || !(await companionTabIsChatGPT(tab))) return null;
    return { window, tab };
  } catch (_) {
    return null;
  }
}

async function openCompanion(request) {
  await loadCompanions();
  // Resolve the source before reusing a window so normal/incognito sessions stay separate.
  const source = validId(request.sourceWindowId)
    ? await chrome.windows.get(request.sourceWindowId)
    : await chrome.windows.getLastFocused();
  if (!source || !validId(source.id) || typeof source.incognito !== 'boolean') {
    throw new Error('Chrome could not identify the browser window. Try the ChatGPT button again.');
  }
  const incognito = source.incognito;
  const context = incognito ? 'incognito' : 'normal';
  const existing = await reusableCompanion(companionRecords[context], incognito);
  if (existing) {
    await chrome.tabs.update(existing.tab.id, { active: true });
    const update = { focused: true };
    if (existing.window.state === 'minimized') update.state = 'normal';
    await chrome.windows.update(existing.window.id, update);
    return { ok: true, windowId: existing.window.id, reused: true };
  }

  // Forget stale ownership; never navigate, close, or repurpose an unrelated window.
  if (companionRecords[context]) {
    delete companionRecords[context];
    await saveCompanions();
  }
  const created = await chrome.windows.create({
    url: COMPANION_URL, type: 'popup', focused: true, incognito,
    ...companionBounds(source, request.screen)
  });
  if (!created || !validId(created.id)) {
    throw new Error('Chrome did not open a ChatGPT companion window. Try again.');
  }
  let tab = created.tabs?.find(item => validId(item.id));
  if (!tab) {
    const tabs = await chrome.tabs.query({ windowId: created.id });
    tab = tabs.find(item => validId(item.id));
  }
  if (tab) {
    companionRecords[context] = { windowId: created.id, tabId: tab.id, incognito };
    await saveCompanions();
  }
  return { ok: true, windowId: created.id, reused: false };
}

function requestCompanion(message, sender = {}) {
  const sourceWindowId = validId(sender.tab?.windowId) ? sender.tab.windowId : message.sourceWindowId;
  if (sourceWindowId !== undefined && !validId(sourceWindowId)) {
    return Promise.reject(new Error('The browser window ID is invalid. Try opening the extension again.'));
  }
  const request = { sourceWindowId, screen: message.screen };
  // Coalesce rapid clicks from the same source while the new page is still being opened.
  // All other requests are serialized before reading or changing session ownership.
  const key = validId(sourceWindowId) ? `window:${sourceWindowId}` : 'last-focused';
  const pending = pendingCompanions.get(key);
  if (pending) return pending.then(result => ({ ...result, reused: true }));
  const operation = enqueueCompanion(() => openCompanion(request));
  pendingCompanions.set(key, operation);
  operation.then(
    () => { if (pendingCompanions.get(key) === operation) pendingCompanions.delete(key); },
    () => { if (pendingCompanions.get(key) === operation) pendingCompanions.delete(key); }
  );
  return operation;
}

function companionError(error) {
  return error?.message || 'Chrome could not open the ChatGPT companion. Try again.';
}

function openPageChat(message = {}, sender = {}) {
  const tabId = validId(sender.tab?.id) ? sender.tab.id : message.tabId;
  if (!validId(tabId)) throw new Error('Open Page Navigator from a browser tab to use page chat.');
  if (typeof chrome.sidePanel?.open !== 'function') throw new Error('Page chat requires Chrome 116 or later.');
  // Keep this call before any await: Chrome requires the originating user gesture.
  return chrome.sidePanel.open({ tabId }).then(() => ({ ok: true }));
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!['PN_COMPANION', 'PN_OPEN_CHAT'].includes(message?.type)) return false;
  const reply = value => { try { sendResponse(value); } catch (_) { /* Popup may already have closed. */ } };
  if (message.type === 'PN_OPEN_CHAT') {
    if (sender.id && sender.id !== chrome.runtime.id) {
      reply({ ok: false, error: 'Unknown page chat request.' });
      return false;
    }
    try { openPageChat(message, sender).then(reply, error => reply({ ok: false, error: error?.message || 'Could not open page chat.' })); }
    catch (error) { reply({ ok: false, error: error?.message || 'Could not open page chat.' }); return false; }
    return true;
  }
  if (message.action !== 'open' || (sender.id && sender.id !== chrome.runtime.id)) {
    reply({ ok: false, error: 'Unknown companion request.' });
    return false;
  }
  requestCompanion(message, sender).then(reply, error => reply({ ok: false, error: companionError(error) }));
  return true;
});

chrome.windows.onRemoved.addListener(windowId => {
  enqueueCompanion(async () => {
    await loadCompanions();
    let changed = false;
    for (const context of ['normal', 'incognito']) {
      if (companionRecords[context]?.windowId === windowId) {
        delete companionRecords[context];
        changed = true;
      }
    }
    if (changed) await saveCompanions();
  }).catch(() => undefined);
});

chrome.commands.onCommand.addListener(async (command, commandTab) => {
  if (!VALID_COMMANDS.has(command) && !['open-chatgpt', 'open-page-chat'].includes(command)) return;
  let tabId;
  try {
    const [tab] = validId(commandTab?.id) ? [commandTab] : await chrome.tabs.query({ active: true, currentWindow: true });
    if (validId(tab?.id)) tabId = tab.id;
    if (command === 'open-page-chat') {
      await openPageChat({ tabId });
    } else if (command === 'open-chatgpt') {
      await requestCompanion({ sourceWindowId: tab?.windowId });
    } else {
      if (tabId === undefined) return;
      const result = await chrome.tabs.sendMessage(
        tabId,
        { type: 'PN_ACTION', action: command, source: 'command' },
        { frameId: 0 }
      );
      if (!result?.ok) {
        throw new Error(result?.error || result?.message || 'Enable Page Navigator for this page to use this shortcut.');
      }
    }
    if (tabId === undefined) return;
    await Promise.all([
      chrome.action.setBadgeText({ tabId, text: '' }),
      chrome.action.setTitle({ tabId, title: 'Page Navigator' })
    ]);
  } catch (error) {
    if (tabId === undefined) return;
    const expected = error?.message;
    const title = command !== 'open-chatgpt' && /receiving end|establish connection|message port|tab was closed/i.test(expected || '')
      ? 'Page Navigator: refresh a normal webpage. Chrome system pages and the built-in PDF viewer are not supported.'
      : `Page Navigator: ${expected || 'Refresh the page and try again.'}`;
    // A tab may close while the shortcut is in flight. Do not leave an unhandled rejection.
    await Promise.allSettled([
      chrome.action.setBadgeBackgroundColor({ tabId, color: '#9a3412' }),
      chrome.action.setBadgeText({ tabId, text: '!' }),
      chrome.action.setTitle({ tabId, title })
    ]);
  }
});
