/* Offline export helpers for Miami Course List Lightweight. No external libraries or network. */
(() => {
  'use strict';
  const COLS = [
    ['term', 'Term'], ['course', 'Course'], ['title', 'Course Title'],
    ['section', 'Section'], ['crn', 'CRN'], ['campus', 'Campus'],
    ['modality', 'Modality'], ['instructor', 'Instructor'],
    ['meeting', 'Days / Time'], ['credits', 'Credit Hours'],
    ['status', 'Status / Seats'], ['details', 'Additional Details']
  ];
  const text = v => String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, ' ').trim();
  function sourceColumns(row) {
    if (Array.isArray(row.columns) && row.columns.length) {
      return row.columns.slice(0, 48).map((c, i) => ({
        label: text(c?.label || `Column ${i + 1}`).slice(0, 90),
        value: text(c?.value).slice(0, 650)
      }));
    }
    // Old v1.5 selections lack original columns. Preserve their compatibility;
    // newly checked courses export their real, original columns instead.
    return COLS.map(([key, label]) => ({ label, value: text(row[key]) }));
  }
  function columnKey(label, occurrence) { return label.toLowerCase() + '\u001f' + occurrence; }
  function schema(rows) {
    // First selected row establishes its exact source column order. When later
    // searches use different layouts, append any new headings in encounter order.
    const columns = [], seen = new Set();
    for (const row of rows) {
      const counts = new Map();
      for (const col of sourceColumns(row)) {
        const label = col.label;
        const occurrence = (counts.get(label.toLowerCase()) || 0) + 1;
        counts.set(label.toLowerCase(), occurrence);
        const key = columnKey(label, occurrence);
        if (!seen.has(key)) { seen.add(key); columns.push({ label, key }); }
      }
    }
    return columns;
  }
  function table(rows) {
    const cols = schema(rows);
    const data = rows.map(row => {
      const counts = new Map(), values = new Map();
      for (const col of sourceColumns(row)) {
        const label = col.label.toLowerCase();
        const occurrence = (counts.get(label) || 0) + 1;
        counts.set(label, occurrence);
        values.set(columnKey(col.label, occurrence), col.value);
      }
      return cols.map(col => values.get(col.key) || '');
    });
    return [cols.map(c => c.label), ...data];
  }
  const xml = v => text(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
  const encoder = new TextEncoder();

  function csv(rows) {
    // BOM helps Excel decode Unicode correctly; neutralize formula injection in text cells.
    const data = table(rows).map((row, index) => row.map(value => {
      const safe = index > 0 && /^[\s\u0000-\u001f]*[=+@\-]/.test(value) ? "'" + value : value;
      return '"' + safe.replace(/"/g, '""') + '"';
    }).join(',')).join('\r\n') + '\r\n';
    return new Blob(['\ufeff', data], { type: 'text/csv;charset=utf-8' });
  }

  const CRC_TABLE = (() => {
    const out = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let i = 0; i < 8; i++) c = (c & 1) ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      out[n] = c >>> 0;
    }
    return out;
  })();
  function crc32(bytes) {
    let crc = 0xffffffff;
    for (const b of bytes) crc = CRC_TABLE[(crc ^ b) & 255] ^ (crc >>> 8);
    return (crc ^ 0xffffffff) >>> 0;
  }
  function zip(files) {
    const pieces = [], central = [];
    let offset = 0;
    const u16 = (v, arr) => { arr.push(v & 255, (v >>> 8) & 255); };
    const u32 = (v, arr) => { u16(v & 65535, arr); u16((v >>> 16) & 65535, arr); };
    for (const [name, data] of files) {
      const filename = encoder.encode(name);
      const bytes = encoder.encode(data);
      const crc = crc32(bytes);
      const local = [];
      u32(0x04034b50, local); u16(20, local); u16(0x0800, local); u16(0, local);
      u16(0, local); u16(0, local); u32(crc, local); u32(bytes.length, local); u32(bytes.length, local);
      u16(filename.length, local); u16(0, local);
      pieces.push(new Uint8Array(local), filename, bytes);
      const entry = [];
      u32(0x02014b50, entry); u16(20, entry); u16(20, entry); u16(0x0800, entry); u16(0, entry);
      u16(0, entry); u16(0, entry); u32(crc, entry); u32(bytes.length, entry); u32(bytes.length, entry);
      u16(filename.length, entry); u16(0, entry); u16(0, entry); u16(0, entry); u16(0, entry);
      u32(0, entry); u32(offset, entry);
      central.push(new Uint8Array(entry), filename);
      offset += local.length + filename.length + bytes.length;
    }
    const centralSize = central.reduce((sum, item) => sum + item.length, 0);
    const end = [];
    u32(0x06054b50, end); u16(0, end); u16(0, end);
    u16(files.length, end); u16(files.length, end);
    u32(centralSize, end); u32(offset, end); u16(0, end);
    return new Blob([...pieces, ...central, new Uint8Array(end)],
      { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }
  function excelCol(n) {
    let s = '';
    for (let x = n + 1; x > 0; x = Math.floor((x - 1) / 26)) s = String.fromCharCode(65 + ((x - 1) % 26)) + s;
    return s;
  }
  function xlsx(rows, options = {}) {
    const data = table(rows);
    const last = excelCol(data[0].length - 1);
    const widths = data[0].map((label, i) => {
      const sample = data.slice(1, 35).map(row => String(row[i] || '').length);
      return Math.min(58, Math.max(12, Math.min(36, label.length + 4), Math.min(58, Math.max(0, ...sample) + 2)));
    });
    const cells = data.map((values, rowIndex) => {
      const style = rowIndex === 0 ? 1 : rowIndex % 2 === 0 ? 2 : 0;
      const cs = values.map((value, i) => {
        const address = excelCol(i) + (rowIndex + 1);
        // Inline strings deliberately prevent interpreting course values as formulas.
        return `<c r="${address}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${xml(value)}</t></is></c>`;
      }).join('');
      return `<row r="${rowIndex + 1}"${rowIndex === 0 ? ' ht="27" customHeight="1"' : ''}>${cs}</row>`;
    }).join('');
    const sheet = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1" autoPageBreaks="0"/></sheetPr><dimension ref="A1:${last}${data.length}"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="17"/><cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>${cells}</sheetData><autoFilter ref="A1:${last}${data.length}"/><printOptions horizontalCentered="1"/><pageMargins left="0.25" right="0.25" top="0.4" bottom="0.4" header="0.15" footer="0.15"/><pageSetup paperSize="8" orientation="landscape" fitToWidth="1" fitToHeight="1"/></worksheet>`;
    const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Aptos"/><color rgb="FF243041"/></font><font><b/><sz val="11"/><name val="Aptos"/><color rgb="FFFFFFFF"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFB31B34"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF2F5F9"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1" applyNumberFormat="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="49" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1" applyNumberFormat="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="49" fontId="0" fillId="3" borderId="0" xfId="0" applyAlignment="1" applyNumberFormat="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
    const types = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>`;
    const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const sheetName = options.kind === 'Schedule' ? 'Draft Schedule' : 'Selected Courses';
    const workbook = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${sheetName}" sheetId="1" r:id="rId1"/></sheets><definedNames><definedName name="_xlnm.Print_Area" localSheetId="0">'${sheetName}'!$A$1:$${last}$${data.length}</definedName></definedNames></workbook>`;
    const workbookRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
    return zip([
      ['[Content_Types].xml', types], ['_rels/.rels', rels],
      ['xl/workbook.xml', workbook], ['xl/_rels/workbook.xml.rels', workbookRels],
      ['xl/worksheets/sheet1.xml', sheet], ['xl/styles.xml', styles]
    ]);
  }

  function printable(v) {
    // Standard PDF fonts use WinAnsi; replace unsupported glyphs gracefully.
    return text(v).replace(/[\u2010\u2011\u2012\u2013\u2014]/g, '-').replace(/[\u2018\u2019]/g, "'")
      .replace(/[\u201c\u201d]/g, '"').replace(/\u2026/g, '...').replace(/\u00a0/g, ' ')
      .replace(/[\u2022\u25cf]/g, '*').replace(/[^\u0020-\u007e\u00a0-\u00ff]/g, '?');
  }
  function pdfQuoted(v) {
    return printable(v).replace(/[\\()]/g, '\\$&').replace(/[\u007f-\u00ff]/g, c => '\\' + c.charCodeAt(0).toString(8).padStart(3, '0'));
  }
  function wrap(v, max) {
    const s = printable(v);
    if (!s) return [];
    const words = s.split(/\s+/), lines = [];
    let line = '';
    for (let word of words) {
      if (word.length > max) {
        if (line) { lines.push(line); line = ''; }
        while (word.length > max) { lines.push(word.slice(0, max)); word = word.slice(max); }
      }
      if (!line) line = word;
      else if ((line + ' ' + word).length <= max) line += ' ' + word;
      else { lines.push(line); line = word; }
    }
    if (line) lines.push(line);
    return lines;
  }
  // All exports use table(rows), so the PDF cannot silently omit or reorder
  // a field relative to the CSV or Excel export. It always contains one page.
  function pdf(rows, options = {}) {
    const matrix = table(rows), headings = matrix[0] || [], records = matrix.slice(1);
    if (!headings.length) throw new Error('There are no course columns to export.');
    const PAGE_SIZES = [
      [792, 612], [1191, 842], [1684, 1191], [2384, 1684], [3370, 2384],
      [4768, 3370], [6750, 4768], [9550, 6750], [13500, 9550]
    ];
    const TITLE = printable(options.title || (options.kind === 'Schedule' ? 'Draft course schedule' : 'Selected courses')).slice(0, 116);
    const FONT = 8.6;
    const weights = headings.map((heading, index) => {
      const lengths = records.slice(0, 85).map(row => String(row[index] || '').length).sort((a, b) => a - b);
      const p75 = lengths.length ? lengths[Math.floor((lengths.length - 1) * .75)] : 0;
      return Math.max(62, Math.min(290, Math.max(heading.length * 4 + 20, Math.min(p75, 90) * 2.2 + 36)));
    });
    const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
    const measure = (W, H, font) => {
      const M = Math.max(35, Math.min(75, W * .031));
      const TOP = 105, BOTTOM = 40, PAD = Math.max(2, font * .5), LINE = font * 1.24;
      const usable = W - M * 2;
      const widths = weights.map(weight => usable * weight / totalWeight);
      const charLimit = width => Math.max(1, Math.floor((width - PAD * 2 - 1) / (font * .535)));
      const headLines = headings.map((heading, i) => wrap(heading, charLimit(widths[i])));
      const headingHeight = Math.max(25, Math.max(1, ...headLines.map(lines => lines.length)) * LINE + PAD * 2 + 3);
      const rowLines = records.map(record => record.map((value, index) => wrap(value, charLimit(widths[index]))));
      const rowHeights = rowLines.map(lines => Math.max(1, ...lines.map(col => col.length)) * LINE + PAD * 2 + 2);
      const allHeight = headingHeight + rowHeights.reduce((sum, h) => sum + h, 0);
      return { W, H, M, TOP, BOTTOM, PAD, LINE, font, widths, headLines, headingHeight, rowLines, rowHeights, allHeight,
        fits: allHeight <= H - TOP - BOTTOM };
    };
    let layout;
    // Prefer US Letter landscape for small selections; increase the PDF's physical page
    // size rather than silently splitting columns onto additional pages.
    // A very large table still prints as one page after 'Fit to page' in the
    // system printer. Text may become small on ordinary letter paper.
    for (const [W, H] of PAGE_SIZES) {
      const candidate = measure(W, H, FONT);
      if (candidate.fits) { layout = candidate; break; }
    }
    if (!layout) {
      for (const font of [7, 6, 5, 4, 3]) {
        const candidate = measure(13500, 9550, font);
        if (candidate.fits) { layout = candidate; break; }
      }
    }
    if (!layout) throw new Error('This selection is too large for a one-page PDF. Export to Excel and print with Fit to One Page.');
    const { W, H, M, TOP, PAD, LINE, font, widths, headLines, headingHeight, rowLines, rowHeights } = layout;
    const ops = [];
    const fill = (x, bottom, w, h, color) => ops.push(`${color} rg ${x.toFixed(2)} ${bottom.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re f`);
    const line = (x1,y1,x2,y2,color='0.86 0.89 0.92') => ops.push(`${color} RG 0.35 w ${x1.toFixed(2)} ${y1.toFixed(2)} m ${x2.toFixed(2)} ${y2.toFixed(2)} l S`);
    const txt = (textValue, x, y, sz=font, bold=false, color='0.15 0.18 0.24') =>
      ops.push(`${color} rg BT /${bold ? 'F2' : 'F1'} ${sz.toFixed(2)} Tf 1 0 0 1 ${x.toFixed(2)} ${y.toFixed(2)} Tm (${pdfQuoted(textValue)}) Tj ET`);
    txt('MIAMI UNIVERSITY  /  COURSE LIST', M, H-31, 10, true, '0.69 0.11 0.20');
    txt(TITLE, M, H-58, 17, true);
    txt(`${records.length} course row${records.length===1?'':'s'}  |  ${headings.length} source columns  |  ${new Date().toLocaleDateString('en-US')}`,
      M, H-78, 9);
    line(M,H-90,W-M,H-90);
    let y=H-TOP;
    const xs=[]; let xpos=M;
    for (const width of widths) { xs.push(xpos); xpos+=width; }
    fill(M,y-headingHeight,W-2*M,headingHeight,'0.69 0.11 0.20');
    for(let c=0;c<headings.length;c++) {
      for(let j=0;j<headLines[c].length;j++) {
        txt(headLines[c][j],xs[c]+PAD,y-PAD-(j+1)*LINE+font*.25,font,true,'1 1 1');
      }
    }
    y-=headingHeight;
    for(let r=0;r<records.length;r++) {
      const height=rowHeights[r];
      if(r%2===0)fill(M,y-height,W-2*M,height,'0.955 0.968 0.983');
      for(let c=0;c<headings.length;c++) {
        const parts=rowLines[r][c];
        for(let j=0;j<parts.length;j++)
          txt(parts[j],xs[c]+PAD,y-PAD-(j+1)*LINE+font*.25,font);
        if(c>0)line(xs[c],y,xs[c],y-height,'0.90 0.92 0.95');
      }
      y-=height;
      line(M,y,W-M,y);
    }
    txt('Source columns shown in their original left-to-right order  |  One-page print layout',M,19,8,false,'0.38 0.43 0.52');
    const stream=ops.join('\n')+'\n';
    const objects=[''];
    const add=entry=>{objects.push(entry);return objects.length-1;};
    const pagesId=add('');
    const fontId=add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    const boldId=add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    const contentId=add(`<< /Length ${encoder.encode(stream).length} >>\nstream\n${stream}endstream`);
    const pageId=add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 ${fontId} 0 R /F2 ${boldId} 0 R >> >> /Contents ${contentId} 0 R >>`);
    objects[pagesId]=`<< /Type /Pages /Count 1 /Kids [${pageId} 0 R] >>`;
    const catalog=add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);
    let output='%PDF-1.4\n% Miami one-page table\n';
    const offsets=[0];
    for(let i=1;i<objects.length;i++){offsets[i]=output.length;output+=`${i} 0 obj\n${objects[i]}\nendobj\n`;}
    const xref=output.length;
    output+=`xref\n0 ${objects.length}\n0000000000 65535 f \n`;
    for(let i=1;i<objects.length;i++)output+=`${String(offsets[i]).padStart(10,'0')} 00000 n \n`;
    output+=`trailer\n<< /Size ${objects.length} /Root ${catalog} 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
    // The PDF binary stream is ASCII-only: all non-ASCII text passes through
    // pdfQuoted() as WinAnsi octal escapes.
    return new Blob([output],{type:'application/pdf'});
  }

  function filename(kind, format, value) {
    if (!['xlsx','csv','pdf','json'].includes(format)) throw new Error('Unsupported export format.');
    const now = new Date();
    const day = [now.getFullYear(), String(now.getMonth()+1).padStart(2,'0'), String(now.getDate()).padStart(2,'0')].join('-');
    let base = String(value ?? '').trim().replace(/\.(?:pdf|csv|xlsx|json)$/i,'')
      .replace(/[\\/:*?"<>|\u0000-\u001f\u007f]/g,'-')
      .replace(/\s+/g,' ').trim().replace(/^[-.\s]+|[-.\s]+$/g,'').slice(0,90);
    if (!base) base = `Miami_Course_List_${kind === 'Schedule' ? 'Schedule' : kind === 'Backup' ? 'Backup' : 'Selected'}_${day}`;
    if (/^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/i.test(base)) base='_'+base;
    return `${base}.${format}`;
  }
  function rememberFilename(input, kind) {
    if (!input) return;
    const key = `mcl_lite_export_name_${kind === 'Schedule' ? 'schedule' : kind === 'Backup' ? 'backup' : 'selected'}_v1`;
    let touched = false;
    input.addEventListener('input', () => { touched = true; });
    input.addEventListener('change', () => {
      try { globalThis.chrome?.storage?.local?.set?.({[key]:String(input.value || '').slice(0,90)}); } catch { /* optional preference */ }
    });
    try {
      globalThis.chrome?.storage?.local?.get?.(key, (stored) => {
        const name=stored?.[key];
        if (!touched && !input.value && typeof name === 'string') input.value=name.slice(0,90);
      });
    } catch { /* no persisted name available */ }
  }
  globalThis.MCLCourseExporters = Object.freeze({ csv, xlsx, pdf, filename, rememberFilename, COLS });
})();
