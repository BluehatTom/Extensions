/* Offline export helpers for Miami Course List Lightweight. No external libraries or network. */
(() => {
  'use strict';
  const COLS = [
    ['term', 'Term'], ['course', 'Course'], ['title', 'Course Title'],
    ['section', 'Section'], ['crn', 'CRN'], ['campus', 'Campus'],
    ['modality', 'Modality'], ['instructor', 'Instructor'],
    ['meeting', 'Days / Time'], ['credits', 'Credit Hours'],
    ['status', 'Status / Seats'], ['details', 'Additional Details']
  ];
  const text = v => String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, ' ').trim();
  function sourceColumns(row) {
    if (Array.isArray(row.columns) && row.columns.length) {
      return row.columns.slice(0, 48).map((c, i) => ({
        label: text(c?.label || `Column ${i + 1}`).slice(0, 90),
        value: text(c?.value).slice(0, 650)
      }));
    }
    // Old v1.5 selections lack original columns. Preserve their compatibility;
    // newly checked courses export their real, original columns instead.
    return COLS.map(([key, label]) => ({ label, value: text(row[key]) }));
  }
  function columnKey(label, occurrence) { return label.toLowerCase() + '\u001f' + occurrence; }
  function schema(rows) {
    // First selected row establishes its exact source column order. When later
    // searches use different layouts, append any new headings in encounter order.
    const columns = [], seen = new Set();
    for (const row of rows) {
      const counts = new Map();
      for (const col of sourceColumns(row)) {
        const label = col.label;
        const occurrence = (counts.get(label.toLowerCase()) || 0) + 1;
        counts.set(label.toLowerCase(), occurrence);
        const key = columnKey(label, occurrence);
        if (!seen.has(key)) { seen.add(key); columns.push({ label, key }); }
      }
    }
    return columns;
  }
  function table(rows) {
    const cols = schema(rows);
    const data = rows.map(row => {
      const counts = new Map(), values = new Map();
      for (const col of sourceColumns(row)) {
        const label = col.label.toLowerCase();
        const occurrence = (counts.get(label) || 0) + 1;
        counts.set(label, occurrence);
        values.set(columnKey(col.label, occurrence), col.value);
      }
      return cols.map(col => values.get(col.key) || '');
    });
    return [cols.map(c => c.label), ...data];
  }
  const xml = v => text(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
  const encoder = new TextEncoder();

  function csv(rows) {
    // BOM helps Excel decode Unicode correctly; neutralize formula injection in text cells.
    const data = table(rows).map((row, index) => row.map(value => {
      const safe = index > 0 && /^[\s\u0000-\u001f]*[=+@\-]/.test(value) ? "'" + value : value;
      return '"' + safe.replace(/"/g, '""') + '"';
    }).join(',')).join('\r\n') + '\r\n';
    return new Blob(['\ufeff', data], { type: 'text/csv;charset=utf-8' });
  }

  const CRC_TABLE = (() => {
    const out = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let i = 0; i < 8; i++) c = (c & 1) ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      out[n] = c >>> 0;
    }
    return out;
  })();
  function crc32(bytes) {
    let crc = 0xffffffff;
    for (const b of bytes) crc = CRC_TABLE[(crc ^ b) & 255] ^ (crc >>> 8);
    return (crc ^ 0xffffffff) >>> 0;
  }
  function zip(files) {
    const pieces = [], central = [];
    let offset = 0;
    const u16 = (v, arr) => { arr.push(v & 255, (v >>> 8) & 255); };
    const u32 = (v, arr) => { u16(v & 65535, arr); u16((v >>> 16) & 65535, arr); };
    for (const [name, data] of files) {
      const filename = encoder.encode(name);
      const bytes = encoder.encode(data);
      const crc = crc32(bytes);
      const local = [];
      u32(0x04034b50, local); u16(20, local); u16(0x0800, local); u16(0, local);
      u16(0, local); u16(0, local); u32(crc, local); u32(bytes.length, local); u32(bytes.length, local);
      u16(filename.length, local); u16(0, local);
      pieces.push(new Uint8Array(local), filename, bytes);
      const entry = [];
      u32(0x02014b50, entry); u16(20, entry); u16(20, entry); u16(0x0800, entry); u16(0, entry);
      u16(0, entry); u16(0, entry); u32(crc, entry); u32(bytes.length, entry); u32(bytes.length, entry);
      u16(filename.length, entry); u16(0, entry); u16(0, entry); u16(0, entry); u16(0, entry);
      u32(0, entry); u32(offset, entry);
      central.push(new Uint8Array(entry), filename);
      offset += local.length + filename.length + bytes.length;
    }
    const centralSize = central.reduce((sum, item) => sum + item.length, 0);
    const end = [];
    u32(0x06054b50, end); u16(0, end); u16(0, end);
    u16(files.length, end); u16(files.length, end);
    u32(centralSize, end); u32(offset, end); u16(0, end);
    return new Blob([...pieces, ...central, new Uint8Array(end)],
      { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }
  function excelCol(n) {
    let s = '';
    for (let x = n + 1; x > 0; x = Math.floor((x - 1) / 26)) s = String.fromCharCode(65 + ((x - 1) % 26)) + s;
    return s;
  }
  function xlsx(rows, options = {}) {
    const data = table(rows);
    const last = excelCol(data[0].length - 1);
    const widths = data[0].map((label, i) => {
      const sample = data.slice(1, 35).map(row => String(row[i] || '').length);
      return Math.min(58, Math.max(12, Math.min(36, label.length + 4), Math.min(58, Math.max(0, ...sample) + 2)));
    });
    const cells = data.map((values, rowIndex) => {
      const style = rowIndex === 0 ? 1 : rowIndex % 2 === 0 ? 2 : 0;
      const cs = values.map((value, i) => {
        const address = excelCol(i) + (rowIndex + 1);
        // Inline strings deliberately prevent interpreting course values as formulas.
        return `<c r="${address}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${xml(value)}</t></is></c>`;
      }).join('');
      return `<row r="${rowIndex + 1}"${rowIndex === 0 ? ' ht="27" customHeight="1"' : ''}>${cs}</row>`;
    }).join('');
    const sheet = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1" autoPageBreaks="1"/></sheetPr><dimension ref="A1:${last}${data.length}"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="17"/><cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>${cells}</sheetData><autoFilter ref="A1:${last}${data.length}"/><printOptions horizontalCentered="1"/><pageMargins left="0.25" right="0.25" top="0.4" bottom="0.4" header="0.15" footer="0.15"/><pageSetup paperSize="8" orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>`;
    const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Aptos"/><color rgb="FF243041"/></font><font><b/><sz val="11"/><name val="Aptos"/><color rgb="FFFFFFFF"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFB31B34"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF2F5F9"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1" applyNumberFormat="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="49" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1" applyNumberFormat="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="49" fontId="0" fillId="3" borderId="0" xfId="0" applyAlignment="1" applyNumberFormat="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
    const types = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>`;
    const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const sheetName = options.kind === 'Schedule' ? 'Draft Schedule' : 'Selected Courses';
    const workbook = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${sheetName}" sheetId="1" r:id="rId1"/></sheets><definedNames><definedName name="_xlnm.Print_Area" localSheetId="0">'${sheetName}'!$A$1:$${last}$${data.length}</definedName><definedName name="_xlnm.Print_Titles" localSheetId="0">'${sheetName}'!$1:$1</definedName></definedNames></workbook>`;
    const workbookRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
    return zip([
      ['[Content_Types].xml', types], ['_rels/.rels', rels],
      ['xl/workbook.xml', workbook], ['xl/_rels/workbook.xml.rels', workbookRels],
      ['xl/worksheets/sheet1.xml', sheet], ['xl/styles.xml', styles]
    ]);
  }

  function printable(v) {
    // Standard PDF fonts use WinAnsi; replace unsupported glyphs gracefully.
    return text(v).replace(/[\u2010\u2011\u2012\u2013\u2014]/g, '-').replace(/[\u2018\u2019]/g, "'")
      .replace(/[\u201c\u201d]/g, '"').replace(/\u2026/g, '...').replace(/\u00a0/g, ' ')
      .replace(/[\u2022\u25cf]/g, '*').replace(/[^\u0020-\u007e\u00a0-\u00ff]/g, '?');
  }
  function pdfQuoted(v) {
    return printable(v).replace(/[\\()]/g, '\\$&').replace(/[\u007f-\u00ff]/g, c => '\\' + c.charCodeAt(0).toString(8).padStart(3, '0'));
  }
  function wrap(v, max) {
    const s = printable(v);
    if (!s) return [];
    const words = s.split(/\s+/), lines = [];
    let line = '';
    for (let word of words) {
      if (word.length > max) {
        if (line) { lines.push(line); line = ''; }
        while (word.length > max) { lines.push(word.slice(0, max)); word = word.slice(max); }
      }
      if (!line) line = word;
      else if ((line + ' ' + word).length <= max) line += ' ' + word;
      else { lines.push(line); line = word; }
    }
    if (line) lines.push(line);
    return lines;
  }
  // These PDF exports fit ALL source columns across the page width. The rows
  // may continue onto as many pages as necessary, repeating the header.
  // PDF generation runs locally without an API, CDN, or printer plug-in.
  function writePdf(pages) {
    const objects = [''];
    const add = value => { objects.push(value); return objects.length - 1; };
    const pagesId = add('');
    const normalId = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    const boldId = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    const ids = [];
    for (const page of pages) {
      const stream = page.ops.join('\n') + '\n';
      const streamId = add(`<< /Length ${encoder.encode(stream).length} >>\nstream\n${stream}endstream`);
      ids.push(add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${page.width} ${page.height}] /Resources << /Font << /F1 ${normalId} 0 R /F2 ${boldId} 0 R >> >> /Contents ${streamId} 0 R >>`));
    }
    objects[pagesId] = `<< /Type /Pages /Count ${ids.length} /Kids [${ids.map(id => `${id} 0 R`).join(' ')}] >>`;
    const catalogId = add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);
    let output = '%PDF-1.4\n% Offline Miami Course List export\n';
    const offsets = [0];
    for (let i = 1; i < objects.length; i++) {
      offsets[i] = output.length;
      output += `${i} 0 obj\n${objects[i]}\nendobj\n`;
    }
    const xref = output.length;
    output += `xref\n0 ${objects.length}\n0000000000 65535 f \n`;
    for (let i = 1; i < objects.length; i++) output += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
    output += `trailer\n<< /Size ${objects.length} /Root ${catalogId} 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
    return new Blob([output], { type: 'application/pdf' });
  }
  function pdfDraw(page) {
    const f = n => Number(n).toFixed(2);
    const fill = (x, y, w, h, color) => page.ops.push(`${color} rg ${f(x)} ${f(y)} ${f(w)} ${f(h)} re f`);
    const line = (x1, y1, x2, y2, color = '0.84 0.87 0.91', weight = 0.45) =>
      page.ops.push(`${color} RG ${f(weight)} w ${f(x1)} ${f(y1)} m ${f(x2)} ${f(y2)} l S`);
    const textAt = (v, x, y, size = 8, bold = false, color = '0.15 0.20 0.28') =>
      page.ops.push(`${color} rg BT /${bold ? 'F2' : 'F1'} ${f(size)} Tf 1 0 0 1 ${f(x)} ${f(y)} Tm (${pdfQuoted(v)}) Tj ET`);
    return { fill, line, textAt };
  }
  function pdf(rows, options = {}) {
    const matrix = table(rows), headings = matrix[0] || [], records = matrix.slice(1);
    if (!headings.length) throw new Error('There are no course columns to export.');
    // Use landscape letter, legal, or tabloid depending on number of original
    // columns. Never split columns onto a second horizontal page.
    const [W, H] = headings.length <= 8 ? [792, 612] : headings.length <= 12 ? [1008, 612] :
      headings.length <= 18 ? [1224, 792] : [1684, 1191];
    const M = W > 1200 ? 36 : 27;
    const font = headings.length > 24 ? 6.6 : headings.length > 16 ? 7 : 8;
    const lineHeight = font * 1.23, pad = Math.max(2.4, font * .43);
    const title = printable(options.title || (options.kind === 'Schedule' ? 'Draft course schedule' : 'Selected courses')).slice(0, 104);
    const bottom = 37;
    const weights = headings.map((heading, index) => {
      const samples = records.slice(0, 80).map(r => String(r[index] || '').length).sort((a, b) => a - b);
      const p75 = samples.length ? samples[Math.floor((samples.length - 1) * .75)] : 0;
      return Math.max(45, Math.min(240, Math.max(heading.length * 4.1 + 15, Math.min(p75, 85) * 2.15 + 25)));
    });
    const sum = weights.reduce((a, b) => a + b, 0);
    const widths = weights.map(n => (W - 2 * M) * n / sum);
    const positions = []; let x = M;
    for (const width of widths) { positions.push(x); x += width; }
    const charLimit = width => Math.max(3, Math.floor((width - pad * 2 - 2) / (font * .52)));
    const headerLines = headings.map((h, i) => wrap(h, charLimit(widths[i])));
    const headerHeight = Math.max(25, Math.max(1, ...headerLines.map(lines => lines.length)) * lineHeight + pad * 2 + 4);
    const body = records.map(row => row.map((v, i) => wrap(v, charLimit(widths[i]))));
    const pages = [];
    let current, draw, y, index = 0;
    function newPage() {
      const page = { width: W, height: H, ops: [] };
      pages.push(page); current = page; draw = pdfDraw(page);
      draw.textAt('MIAMI UNIVERSITY  /  COURSE LIST', M, H - 28, 10, true, '0.69 0.11 0.20');
      draw.textAt(title, M, H - 49, 15, true);
      draw.textAt(`${records.length} course rows  |  ${headings.length} source columns  |  ${new Date().toLocaleDateString('en-US')}`, M, H - 65, 8.4);
      draw.line(M, H - 74, W - M, H - 74);
      y = H - 86;
      draw.fill(M, y - headerHeight, W - 2 * M, headerHeight, '0.69 0.11 0.20');
      for (let c = 0; c < headings.length; c++) {
        for (let l = 0; l < headerLines[c].length; l++) {
          draw.textAt(headerLines[c][l], positions[c] + pad, y - pad - (l + 1) * lineHeight + font * .2, font, true, '1 1 1');
        }
      }
      y -= headerHeight;
    }
    newPage();
    for (const row of body) {
      const length = Math.max(1, ...row.map(lines => lines.length));
      let at = 0;
      while (at < length) {
        const available = y - bottom;
        const canFit = Math.floor((available - 2 * pad - 2) / lineHeight);
        if (canFit <= 0) { newPage(); continue; }
        const take = Math.min(length - at, canFit);
        const h = take * lineHeight + pad * 2 + 2;
        if (index % 2 === 0) draw.fill(M, y - h, W - 2 * M, h, '0.952 0.964 0.980');
        for (let c = 0; c < headings.length; c++) {
          for (let l = 0; l < take; l++) {
            const word = row[c][at + l];
            if (word !== undefined) draw.textAt(word, positions[c] + pad, y - pad - (l + 1) * lineHeight + font * .2, font);
          }
          if (c > 0) draw.line(positions[c], y, positions[c], y - h, '0.91 0.93 0.96', .28);
        }
        y -= h;
        draw.line(M, y, W - M, y);
        at += take;
        if (at < length) newPage();
      }
      index++;
    }
    pages.forEach((page, i) => {
      const p = pdfDraw(page);
      p.line(M, 31, W - M, 31);
      p.textAt('Source columns retained in their original order  |  All columns fit this page width', M, 18, 7.5, false, '0.36 0.41 0.51');
      p.textAt(`Page ${i + 1} of ${pages.length}`, W - M - 75, 18, 8, true);
    });
    return writePdf(pages);
  }
  // Printable calendar PDF: one landscape page per term. All five weekdays stay
  // together, and longer TBA lists get continuation pages rather than clipping.
  function calendarPdf(groups, options = {}) {
    if (!Array.isArray(groups) || !groups.length) throw new Error('Add a course to the schedule before printing the calendar.');
    const pages = [], W = 792, H = 612, margin = 29;
    const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const start = 8 * 60, end = 21 * 60;
    const gridTop = H - 115, gridBottom = 105, gridHeight = gridTop - gridBottom;
    const timeW = 46, dayW = (W - margin * 2 - timeW) / 5;
    const clockLabel = minute => {
      let h = Math.floor(minute / 60), m = minute % 60;
      return `${h % 12 || 12}${m ? ':' + String(m).padStart(2, '0') : ''}${h >= 12 ? 'p' : 'a'}`;
    };
    const clipped = (v, max) => { const s = printable(v); return s.length > max ? s.slice(0, Math.max(0, max - 2)) + '..' : s; };
    const colors = [
      ['0.88 0.94 1','0.18 0.42 0.65'],['0.89 0.95 0.90','0.15 0.46 0.31'],
      ['0.94 0.91 0.98','0.42 0.30 0.64'],['0.88 0.96 0.96','0.13 0.45 0.48'],
      ['1 0.94 0.84','0.53 0.35 0.14']
    ];
    for (const group of groups) {
      const page = { width: W, height: H, ops: [] };
      const { fill, line, textAt } = pdfDraw(page);
      pages.push(page);
      const title = clipped(String(options.title || 'Five-day weekly schedule').replace(/_/g, ' '), 80);
      textAt('MIAMI UNIVERSITY  /  COURSE LIST', margin, H - 26, 10, true, '0.69 0.11 0.20');
      textAt(title, margin, H - 47, 17, true);
      textAt(clipped(group.term || 'Term not specified', 85), margin, H - 63, 9, true);
      textAt('Monday - Friday  |  8 AM - 9 PM  |  Meeting date ranges matter for sprint courses', margin, H - 78, 8);
      line(margin, H - 86, W - margin, H - 86);
      fill(margin, gridTop, W - 2 * margin, 24, '0.93 0.95 0.98');
      textAt('Time', margin + 5, gridTop + 8, 8.5, true);
      for (let day = 0; day < 5; day++) {
        textAt(dayNames[day], margin + timeW + day * dayW + 11, gridTop + 8, 8.5, true);
      }
      for (let slot = 0; slot <= 26; slot++) {
        const minute = start + slot * 30;
        const y = gridTop - slot * gridHeight / 26;
        line(margin, y, W - margin, y, slot % 2 === 0 ? '0.72 0.78 0.86' : '0.88 0.90 0.94', slot % 2 === 0 ? .7 : .3);
        if (slot < 26 && slot % 2 === 0) textAt(clockLabel(minute), margin + 4, y - 10, 7.4);
      }
      for (let i = 0; i <= 5; i++) line(margin + timeW + i * dayW, gridTop, margin + timeW + i * dayW, gridBottom, '0.76 0.81 0.89', .55);
      const events = [];
      const offgrid = [];
      const seenOffgrid = new Set();
      for (const item of group.items || []) {
        const row = item.row || {}, code = row.course || 'Course code unavailable';
        if (!item.entries?.length) {
          if (!seenOffgrid.has(row.key)) { offgrid.push(`${code}${row.section ? ' Sec ' + row.section : ''}: ${item.description || 'No meeting time listed'}`); seenOffgrid.add(row.key); }
          continue;
        }
        for (const e of item.entries) {
          if (e.day < 1 || e.day > 5 || e.finish <= start || e.begin >= end) {
            const sign = `${row.key}|${e.day}|${e.begin}`;
            if (!seenOffgrid.has(sign)) {
              offgrid.push(`${code}${row.section ? ' Sec ' + row.section : ''}: ${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][e.day]} ${clockLabel(e.begin)}-${clockLabel(e.finish)} (outside grid)`);
              seenOffgrid.add(sign);
            }
            continue;
          }
          events.push({ ...e, row, code, conflict: !!e.conflict, unknownDates: !!e.unknownDates });
        }
      }
      for (let day = 1; day <= 5; day++) {
        const sorted = events.filter(e => e.day === day).sort((a, b) => a.begin - b.begin || a.finish - b.finish);
        // Clock-time overlap determines lanes; a conflict label also requires
        // overlapping real meeting dates, determined by the schedule builder.
        const groupsOfEvents = []; let current = [], until = -1;
        for (const e of sorted) {
          if (current.length && e.begin >= until) { groupsOfEvents.push(current); current = []; until = -1; }
          current.push(e); until = Math.max(until, e.finish);
        }
        if (current.length) groupsOfEvents.push(current);
        for (const batch of groupsOfEvents) {
          const occupied = [];
          for (const e of batch) {
            let lane = occupied.findIndex(t => t <= e.begin);
            if (lane < 0) { lane = occupied.length; occupied.push(e.finish); }
            else occupied[lane] = e.finish;
            e.lane = lane;
          }
          for (const e of batch) e.lanes = occupied.length;
        }
      }
      for (const e of events) {
        const yTop = gridTop - (Math.max(start, e.begin) - start) / (end - start) * gridHeight;
        const yBottom = gridTop - (Math.min(end, e.finish) - start) / (end - start) * gridHeight;
        const laneWidth = dayW / (e.lanes || 1);
        const x = margin + timeW + (e.day - 1) * dayW + (e.lane || 0) * laneWidth + 2;
        const w = laneWidth - 4;
        const y = yBottom + 1, h = Math.max(6, yTop - yBottom - 2);
        let hash = 0; for (const c of e.code) hash = ((hash * 31) + c.charCodeAt(0)) >>> 0;
        const [bg, edge] = e.conflict ? ['1 0.88 0.88','0.69 0.11 0.20'] : colors[hash % colors.length];
        fill(x, y, w, h, bg);
        line(x, y, x, y + h, edge, e.conflict ? 3 : 2);
        const baseline = y + h - 9;
        textAt(clipped(e.code, Math.max(5, Math.floor(w / 4.8))), x + 4, baseline, 7.1, true, e.conflict ? '0.65 0.10 0.15' : '0.13 0.24 0.34');
        if (h >= 30 && w >= 50) {
          textAt(clipped(`Sec ${e.row.section || '?'}  ${clockLabel(e.begin)}-${clockLabel(e.finish)}`, Math.floor(w / 4.3)), x + 4, baseline - 10, 6.4);
        }
        if (h >= 34 && w >= 65 && e.startDate !== null && e.endDate !== null) {
          const d = value => { const date = new Date(value * 86400000); return `${date.getUTCMonth()+1}/${date.getUTCDate()}`; };
          textAt(`${d(e.startDate)}-${d(e.endDate)}${e.unknownDates ? ' (verify)' : ''}`, x + 4, baseline - 20, 6.2);
        }
      }
      line(margin, 96, W - margin, 96);
      textAt('Red bars: overlapping day, time and date range. Verify dates/availability before registering.', margin, 84, 7.4);
      const shown = offgrid.slice(0, 3);
      if (shown.length) {
        textAt('TBA / asynchronous / weekend:', margin, 69, 7.8, true);
        for (let i = 0; i < shown.length; i++) textAt(clipped(shown[i], 125), margin + 13, 57 - i * 10, 7);
      } else textAt('No additional unscheduled meeting blocks.', margin, 64, 7.4);
      if (offgrid.length > 3) {
        for (let i = 3; i < offgrid.length; i += 48) {
          const extra = { width: W, height: H, ops: [] }; pages.push(extra);
          const more = pdfDraw(extra);
          more.textAt(`Additional meetings outside the five-day grid  |  ${group.term || 'Term unspecified'}`, margin, H - 43, 14, true);
          for (let j = 0; j < 48 && offgrid[i + j] !== undefined; j++) {
            more.textAt(clipped(offgrid[i + j], 130), margin, H - 70 - j * 10.5, 8);
          }
        }
      }
    }
    pages.forEach((page, i) => pdfDraw(page).textAt(`Page ${i + 1} of ${pages.length}`, W - 96, 20, 8, true));
    return writePdf(pages);
  }

  function filename(kind, format, value) {
    if (!['xlsx','csv','pdf','json'].includes(format)) throw new Error('Unsupported export format.');
    const now = new Date();
    const day = [now.getFullYear(), String(now.getMonth()+1).padStart(2,'0'), String(now.getDate()).padStart(2,'0')].join('-');
    let base = String(value ?? '').trim().replace(/\.(?:pdf|csv|xlsx|json)$/i,'')
      .replace(/[\\/:*?"<>|\u0000-\u001f\u007f]/g,'-')
      .replace(/\s+/g,' ').trim().replace(/^[-.\s]+|[-.\s]+$/g,'').slice(0,90);
    if (!base) base = `Miami_Course_List_${kind === 'Schedule' ? 'Schedule' : kind === 'Backup' ? 'Backup' : 'Selected'}_${day}`;
    if (/^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/i.test(base)) base='_'+base;
    return `${base}.${format}`;
  }
  function rememberFilename(input, kind) {
    if (!input) return;
    const key = `mcl_lite_export_name_${kind === 'Schedule' ? 'schedule' : kind === 'Backup' ? 'backup' : 'selected'}_v1`;
    let touched = false;
    input.addEventListener('input', () => { touched = true; });
    input.addEventListener('change', () => {
      try { globalThis.chrome?.storage?.local?.set?.({[key]:String(input.value || '').slice(0,90)}); } catch { /* optional preference */ }
    });
    try {
      globalThis.chrome?.storage?.local?.get?.(key, (stored) => {
        const name=stored?.[key];
        if (!touched && !input.value && typeof name === 'string') input.value=name.slice(0,90);
      });
    } catch { /* no persisted name available */ }
  }
  globalThis.MCLCourseExporters = Object.freeze({ csv, xlsx, pdf, calendarPdf, filename, rememberFilename, COLS });
})();
