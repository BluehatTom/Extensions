/* Miami Course List Lightweight - schedule planner (v1.9.0)
 * Offline, local-only schedule, with separate export-and-clear controls.
 * Schedule exports clear scheduled rows and their matching export checkmarks,
 * leaving saved search presets and unscheduled checked rows intact.
 */
(() => {
  'use strict';
  const KEY = 'mcl_lite_schedule_v1'; // Keep constant across extension upgrades.
  const MAX_ROWS = 150;
  const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const schedule = new Map();
  const norm = value => String(value ?? '').replace(/\s+/g, ' ').trim();
  const clean = (value, limit) => norm(value).slice(0, limit);
  let ui = {}, status = () => {}, started = false, saveTimer, exporting = false;

  function columnValue(row, matcher) {
    const col = (row.columns || []).find(c => matcher.test(norm(c.label)));
    return clean(col?.value || '', 650);
  }
  // Disambiguate course codes from room identifiers such as PHS 207.
  // Historically the broad row-text extractor could populate row.course with
  // a building/room value. Existing saved schedules must also be repaired.
  const CODE = /\b([A-Z]{2,4})\s*[- ]?\s*(\d{3,4}[A-Z]?)\b/i;
  const codeIn = value => {
    const match = norm(value).match(CODE);
    return match ? `${match[1]} ${match[2]}`.toUpperCase() : '';
  };
  const COURSE_LABEL = /^(?:course(?:\s+(?:code|number|no\.?|id))?|class(?:\s+(?:code|number|no\.?|id))?|subject\s*(?:&|and|\/)\s*(?:course\s*)?(?:number|no\.?))$/i;
  const LOCATION_LABEL = /(?:building|room|location|venue|facility|address|campus|site)/i;
  function courseIdentity(row) {
    const columns = row.columns || [];
    const subject = columnValue(row, /^(?:subject(?:\s+code)?|subj\.?|dept(?:artment)?(?:\s+code)?)$/i).toUpperCase();
    const number = columnValue(row, /^(?:course\s*(?:number|no\.?|#)|catalog\s*(?:number|no\.?)|class\s*(?:number|no\.?|#)|number)$/i).toUpperCase();
    if (/^[A-Z]{2,4}$/.test(subject) && /^\d{3,4}[A-Z]?$/.test(number)) return `${subject} ${number}`;
    for (const col of columns) {
      if (COURSE_LABEL.test(norm(col.label))) {
        const code = codeIn(col.value);
        if (code) return code;
      }
    }
    for (const col of columns) {
      if (/^(?:course title|class title|title|course name)$/i.test(norm(col.label))) {
        const code = codeIn(col.value);
        if (code) return code;
      }
    }
    const locationCodes = new Set(columns.filter(c => LOCATION_LABEL.test(norm(c.label)))
      .map(c => codeIn(c.value)).filter(Boolean));
    const saved = codeIn(row.course);
    if (saved && !locationCodes.has(saved)) return saved;
    for (const col of columns) {
      if (/^(?:column\s+\d+|details(?:\s+\d+)?)$/i.test(norm(col.label))) {
        const code = codeIn(col.value);
        if (code && !locationCodes.has(code)) return code;
      }
    }
    return '';
  }
  function dayCodes(raw) {
    const s = norm(raw).toLowerCase();
    if (!s || /\b(?:asynchronous|arranged|tba|to be announced)\b/.test(s)) return [];
    const named = /\b(?:monday|mon|tuesday|tues|tue|wednesday|weds|wed|thursday|thurs|thur|thu|friday|fri|saturday|sat|sunday|sun)\b/g;
    const mapName = word => ({ monday: 1, mon: 1, tuesday: 2, tues: 2, tue: 2, wednesday: 3, weds: 3, wed: 3,
      thursday: 4, thurs: 4, thur: 4, thu: 4, friday: 5, fri: 5, saturday: 6, sat: 6, sunday: 0, sun: 0 })[word];
    const full = [...s.matchAll(named)].map(m => mapName(m[0])).filter(n => n !== undefined);
    if (full.length) return [...new Set(full)];
    const withoutTimes = s.replace(/\b\d{1,2}(?::\d{2})?\s*(?:a\.?m\.?|p\.?m\.?)?\b/g, ' ')
      .replace(/\b(?:am|pm|to|and|days|day|meeting|meetings|time|times)\b/g, ' ').trim();
    const aliases = { m: 1, t: 2, tu: 2, w: 3, r: 4, th: 4, f: 5, s: 6, sa: 6, u: 0, su: 0 };
    const found = [];
    for (const token of withoutTimes.split(/[\s,;\/&+()\-]+/).filter(Boolean)) {
      if (aliases[token] !== undefined) { found.push(aliases[token]); continue; }
      // Miami-style day codes: MWF, TR, MW, TTh, TuTh, M/W/F, etc.
      let compact = token;
      if (!/^(?:m|tu|t|w|th|r|f|sa|s|su|u)+$/.test(compact)) continue;
      while (compact) {
        const alias = ['th', 'tu', 'sa', 'su'].find(part => compact.startsWith(part)) || compact[0];
        if (aliases[alias] === undefined) break;
        found.push(aliases[alias]); compact = compact.slice(alias.length);
      }
    }
    return [...new Set(found)];
  }
  function clock(raw, inferred) {
    const m = norm(raw).match(/^(\d{1,2})(?::(\d{2}))?\s*([ap])\.?m?\.?$/i) ||
      norm(raw).match(/^(\d{1,2})(?::(\d{2}))?$/);
    if (!m) return null;
    const h = +m[1], mins = +(m[2] || 0), ap = m[3] ? m[3].toLowerCase() : inferred;
    if (mins > 59 || h > (ap ? 12 : 23) || h < (ap ? 1 : 0)) return null;
    if (!ap) return h >= 13 ? h * 60 + mins : null; // Ambiguous 12-hour times do not drive conflict warnings.
    return ((h % 12) + (ap === 'p' ? 12 : 0)) * 60 + mins;
  }
  function displayClock(value) {
    const h = Math.floor(value / 60), m = value % 60;
    return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
  }
  // Dates are crucial for sprint/half-term courses. Avoid treating the digits
  // inside a calendar date as a meeting time (a problem in prior versions).
  const DATE_TOKEN = /\b(?:20\d{2}-\d{1,2}-\d{1,2}|\d{1,2}[\/.\-]\d{1,2}(?:[\/.\-]\d{2,4})?|(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+\d{1,2}(?:,?\s+\d{2,4})?)\b/gi;
  const TIME_RANGE = /\b(\d{1,2}:\d{2}\s*(?:[ap]\.?\s*m\.?)?)\s*(?:-|–|—|\bto\b)\s*(\d{1,2}:\d{2}\s*(?:[ap]\.?\s*m\.?)?)/gi;
  const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
  const DATE_DAY = 86400000;
  function datePieces(str) {
    const text = norm(str);
    let year = null, month, day, m;
    if ((m = text.match(/^(20\d{2})-(\d{1,2})-(\d{1,2})$/))) {
      year = +m[1]; month = +m[2]; day = +m[3];
    } else if ((m = text.match(/^(\d{1,2})[\/.\-](\d{1,2})(?:[\/.\-](\d{2,4}))?$/))) {
      month = +m[1]; day = +m[2];
      if (m[3]) year = +m[3] < 100 ? 2000 + +m[3] : +m[3];
    } else if ((m = text.match(/^([a-z]+)\.?\s+(\d{1,2})(?:,?\s+(\d{2,4}))?$/i))) {
      month = MONTHS[m[1].slice(0, 3).toLowerCase()]; day = +m[2];
      if (m[3]) year = +m[3] < 100 ? 2000 + +m[3] : +m[3];
    }
    if (!(month >= 1 && month <= 12) || !(day >= 1 && day <= 31) || (year !== null && (year < 2000 || year > 2100))) return null;
    return { year, month, day };
  }
  function calendarDay(parts, defaultYear) {
    if (!parts) return null;
    const year = parts.year ?? defaultYear;
    if (!year) return null;
    const date = new Date(Date.UTC(year, parts.month - 1, parts.day));
    if (date.getUTCFullYear() !== year || date.getUTCMonth() + 1 !== parts.month || date.getUTCDate() !== parts.day) return null;
    return Math.floor(date.getTime() / DATE_DAY);
  }
  function dateWindows(source, term = '') {
    const text = String(source || '');
    DATE_TOKEN.lastIndex = 0;
    const tokens = [...text.matchAll(DATE_TOKEN)].map(m => ({ token: m[0], from: m.index, to: m.index + m[0].length, parts: datePieces(m[0]) })).filter(x => x.parts);
    // A year-free date is usable only when the course term supplies a year (or
    // the other end of the range does). We do not guess from today's date.
    const termYear = +(String(term).match(/20\d{2}/)?.[0] || 0) || null;
    const ranges = [];
    for (let i = 0; i + 1 < tokens.length; i++) {
      const first = tokens[i], second = tokens[i + 1];
      const between = text.slice(first.to, second.from).trim();
      if (between.length > 35 || !(/^(?:[-–—]|to|through|thru|until|\/|\s)*$/i.test(between) ||
        /^(?:end|ending|end\s*date|last\s*date)\s*:?$/i.test(between))) continue;
      let firstYear = first.parts.year ?? second.parts.year ?? termYear;
      let secondYear = second.parts.year ?? first.parts.year ?? termYear;
      if (!firstYear || !secondYear) continue;
      // A Dec-Jan term with an omitted year may cross the new year.
      if (!second.parts.year && second.parts.month < first.parts.month && secondYear === firstYear) secondYear++;
      if (!first.parts.year && first.parts.month > second.parts.month && firstYear === secondYear) firstYear--;
      const startDate = calendarDay(first.parts, firstYear), endDate = calendarDay(second.parts, secondYear);
      if (startDate === null || endDate === null || endDate < startDate) continue;
      ranges.push({ startDate, endDate, from: first.from, to: second.to });
      i++; // Do not treat the same range end as the start of another range.
    }
    return ranges;
  }
  function dateLabel(day) {
    const d = new Date(day * DATE_DAY);
    return `${d.getUTCMonth() + 1}/${d.getUTCDate()}/${d.getUTCFullYear()}`;
  }
  const likelyTime = /\b\d{1,2}:\d{2}\s*(?:[ap]\.?(?:m\.?)?)?/i;
  const isMeetingColumn = label => /(?:meeting|schedule|days?\s*(?:\/|&|and)\s*(?:times?|dates?)|times?\s*(?:\/|&|and)\s*(?:dates?|days?)|dates?\s*(?:\/|&|and)\s*times?|when|class\s*times?)/i.test(label);
  function meetingInfo(row) {
    const columns = row.columns || [];
    const daysRaw = columnValue(row, /^(?:meeting\s*)?days?(?:\s+of\s+week)?$/i);
    const timesRaw = columnValue(row, /^(?:meeting\s*)?(?:times?|time\s*pattern|start\s*[-/]\s*end\s*time)$/i);
    const startTime = columnValue(row, /^(?:meeting\s*)?start\s*time$/i);
    const endTime = columnValue(row, /^(?:meeting\s*)?end\s*time$/i);
    const startDate = columnValue(row, /^(?:meeting\s*)?(?:start|begin|from)\s*date$/i);
    const endDate = columnValue(row, /^(?:meeting\s*)?(?:end|through|to)\s*date$/i);
    const dates = columnValue(row, /^(?:meeting\s*)?dates?(?:\s*range)?$/i);
    const defaults = dateWindows([startDate, endDate].filter(Boolean).join(' - ') || dates, row.term);
    // The university's far-right column carries dates and meeting times.
    // Prefer it even when the heading is "Meeting Dates and Times" or a
    // generic "Column 9". Earlier builds inspected only a narrow list of names.
    const last = columns.at(-1);
    const rightmost = last && likelyTime.test(last.value) &&
      (isMeetingColumn(last.label) || /^(?:column\s+\d+|details(?:\s+\d+)?)$/i.test(norm(last.label)) ||
       dateWindows(last.value, row.term).length || dayCodes(last.value).length) ? (row.meetingDetails || last.value) : '';
    const labeled = [...columns].reverse().find(col => isMeetingColumn(col.label) && likelyTime.test(col.value))?.value || '';
    const timeSpan = timesRaw || (startTime && endTime ? `${startTime} - ${endTime}` : '');
    const combined = rightmost || labeled || row.meetingDetails ||
      [daysRaw, timeSpan, dates || (startDate && endDate ? `${startDate} - ${endDate}` : '')].filter(Boolean).join(' ')
      || row.meeting || '';
    const raw = norm(combined);
    if (/\b(?:asynchronous|arranged|tba|to be announced)\b/i.test(raw) && !likelyTime.test(raw)) {
      return { entries: [], description: raw || 'No scheduled meeting time', source: 'unscheduled' };
    }
    const windows = dateWindows(raw, row.term);
    const defaultWindow = windows.length === 1 ? windows[0] : (defaults.length === 1 ? defaults[0] : null);
    const entries = [], seen = new Set();
    TIME_RANGE.lastIndex = 0;
    const ranges = [...raw.matchAll(TIME_RANGE)];
    for (let idx = 0; idx < ranges.length; idx++) {
      const m = ranges[idx];
      const a = norm(m[1]), b = norm(m[2]);
      const aMeridiem = /([ap])\s*\.?m?\.?$/i.exec(a)?.[1]?.toLowerCase();
      const bMeridiem = /([ap])\s*\.?m?\.?$/i.exec(b)?.[1]?.toLowerCase();
      let begin = clock(a, aMeridiem || bMeridiem), finish = clock(b, bMeridiem || aMeridiem);
      // Explicit two-digit, zero-padded clock fields are treated as 24-hour
      // times when neither endpoint contains AM/PM (e.g. 09:05–10:00).
      if (begin === null && finish === null && !aMeridiem && !bMeridiem &&
          /^\d{2}:\d{2}$/.test(a) && /^\d{2}:\d{2}$/.test(b)) {
        const as24 = text => { const [h, m] = text.split(':').map(Number); return h <= 23 && m <= 59 ? h * 60 + m : null; };
        begin = as24(a); finish = as24(b);
      }
      if (begin !== null && finish !== null && finish <= begin && !aMeridiem && bMeridiem) {
        const alt = clock(a, bMeridiem === 'p' ? 'a' : 'p');
        if (alt !== null && alt < finish) begin = alt;
      }
      if (begin === null || finish === null || finish <= begin || finish - begin > 12 * 60) continue;
      const previous = idx ? ranges[idx - 1].index + ranges[idx - 1][0].length : 0;
      const next = idx + 1 < ranges.length ? ranges[idx + 1].index : raw.length;
      const prefix = raw.slice(Math.max(previous, m.index - 80), m.index);
      const suffix = raw.slice(m.index + m[0].length, Math.min(next, m.index + m[0].length + 40));
      // Use the day pattern nearest the time range, falling back to the site's
      // separate Days field if the last column contains only time/date.
      const days = dayCodes(prefix).length ? dayCodes(prefix) : dayCodes(suffix).length ? dayCodes(suffix) : dayCodes(daysRaw);
      const midpoint = m.index + m[0].length / 2;
      const closest = windows.length > 1 ? windows.reduce((best, win) => {
        const dist = Math.min(Math.abs(midpoint - win.from), Math.abs(midpoint - win.to));
        const priorDist = best ? Math.min(Math.abs(midpoint - best.from), Math.abs(midpoint - best.to)) : Infinity;
        return dist < priorDist ? win : best;
      }, null) : defaultWindow;
      for (const day of days) {
        const entry = { day, begin, finish, startDate: closest?.startDate ?? null, endDate: closest?.endDate ?? null };
        const signature = [day, begin, finish, entry.startDate, entry.endDate].join('|');
        if (!seen.has(signature)) { entries.push(entry); seen.add(signature); }
      }
    }
    // If the far-right column only contains part of the pattern, try the site's
    // separate Days and Times cells. Never invent days or times when absent.
    if (!entries.length && combined && timeSpan && daysRaw && combined !== `${daysRaw} ${timeSpan}`) {
      const fallback = meetingInfo({ ...row, columns: [
        { label: 'Days', value: daysRaw }, { label: 'Time', value: timeSpan },
        ...(defaultWindow ? [{ label: 'Dates', value: `${dateLabel(defaultWindow.startDate)} - ${dateLabel(defaultWindow.endDate)}` }] : [])
      ], meetingDetails: '', meeting: '' });
      if (fallback.entries.length) return fallback;
    }
    return { entries: entries.sort((a, b) => a.day - b.day || a.begin - b.begin),
      description: raw || 'Meeting days and times not listed', source: rightmost ? 'rightmost' : labeled ? 'meeting-column' : 'fallback' };
  }
  function overlappingDates(a, b) {
    // Unknown date ranges cannot establish a definite non-overlap. Keep such
    // cases as *potential* conflicts instead of silently suppressing them.
    if (a.startDate === null || a.endDate === null || b.startDate === null || b.endDate === null) return { overlap: true, unknownDates: true };
    const left = Math.max(a.startDate, b.startDate), right = Math.min(a.endDate, b.endDate);
    if (left > right) return { overlap: false, unknownDates: false };
    // The overlapping interval must actually contain the common weekday.
    const weekday = new Date(left * DATE_DAY).getUTCDay();
    const firstSharedDay = left + ((a.day - weekday + 7) % 7);
    return { overlap: firstSharedDay <= right, unknownDates: false };
  }
  function normalizeRow(raw) {
    if (!raw || typeof raw.key !== 'string' || !raw.key || raw.key.length > 4000) return null;
    return {
      key: raw.key,
      course: clean(courseIdentity(raw), 22), title: clean(raw.title, 250), crn: clean(raw.crn, 20),
      section: clean(raw.section, 50), term: clean(raw.term, 100), campus: clean(raw.campus, 100),
      modality: clean(raw.modality, 100), meeting: clean(raw.meeting, 320), meetingDetails: clean(raw.meetingDetails, 1600),
      columns: Array.isArray(raw.columns) ? raw.columns.slice(0, 48).map(c => ({
        label: clean(c?.label, 90), value: clean(c?.value, 650)
      })) : []
    };
  }
  async function readSaved() {
    try {
      const result = await new Promise(resolve => chrome.storage.local.get(KEY, resolve));
      if (!Array.isArray(result?.[KEY])) return;
      for (const raw of result[KEY].slice(0, MAX_ROWS)) {
        const row = normalizeRow(raw);
        if (row) schedule.set(row.key, row);
      }
    } catch (error) { status('Could not load the saved schedule: ' + error.message, 'warn'); }
  }
  function persistSchedule() {
    return new Promise((resolve, reject) => chrome.storage.local.set({ [KEY]: [...schedule.values()] }, () => {
      if (chrome.runtime?.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve();
    }));
  }
  function scheduleSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      try { await persistSchedule(); }
      catch (error) { status('Could not save the schedule: ' + error.message, 'warn'); }
    }, 130);
  }
  function addChecked() {
    if (exporting) return;
    const picked = globalThis.MCLCourseResults?.getSelected?.() || [];
    if (!picked.length) { status('Check courses in the search results before adding to the schedule.', 'warn'); return; }
    let added = 0, updated = 0;
    for (const item of picked) {
      const row = normalizeRow(item);
      if (!row) continue;
      if (!schedule.has(row.key) && schedule.size >= MAX_ROWS) {
        status('Schedule limit is 150 sections. Remove a section before adding more.', 'warn'); break;
      }
      if (schedule.has(row.key)) updated++; else added++;
      schedule.set(row.key, row);
    }
    scheduleSave(); render();
    status(`${added} new section${added === 1 ? '' : 's'} added to the schedule${updated ? `; ${updated} already present` : ''}.`, 'ok');
  }
  function remove(key) {
    if (exporting) return;
    schedule.delete(key); scheduleSave(); render();
    status('Section removed from schedule. Export selections are unchanged.', 'ok');
  }
  function clearSchedule() {
    if (exporting || !schedule.size) return;
    if (schedule.size > 1 && !window.confirm(`Clear all ${schedule.size} scheduled sections?`)) return;
    schedule.clear(); scheduleSave(); render();
    status('Schedule cleared. Checked courses and saved filters remain unchanged.', 'ok');
  }
  const EXPORT_TYPES = {
    xlsx: { label: 'Excel workbook', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' },
    csv: { label: 'CSV file', mime: 'text/csv' },
    pdf: { label: 'PDF file', mime: 'application/pdf' }
  };
  async function downloadSchedule(blob, filename, format) {
    // On supported browsers, wait for a real file write to finish. A canceled
    // picker or failed write must NOT erase the schedule. No new permissions.
    if (typeof window.showSaveFilePicker === 'function') {
      const handle = await window.showSaveFilePicker({
        suggestedName: filename,
        types: [{ description: EXPORT_TYPES[format].label,
          accept: { [EXPORT_TYPES[format].mime]: ['.' + format] } }]
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return;
    }
    // Fallback for browsers without File System Access. The browser controls
    // the rest of the download, which content scripts cannot observe.
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    try {
      link.href = url; link.download = filename; link.style.display = 'none';
      document.body.append(link); link.click();
    } finally {
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 30_000);
    }
  }
  async function exportSchedule(format) {
    if (exporting) return;
    const rows = [...schedule.values()];
    if (!rows.length) { status('Add course sections to the schedule before exporting.', 'warn'); return; }
    const exporter = globalThis.MCLCourseExporters?.[format];
    if (!exporter || !EXPORT_TYPES[format]) { status('Export formatter unavailable. Reload the extension.', 'error'); return; }
    exporting = true; render();
    try {
      const blob = exporter(rows);
      if (!(blob instanceof Blob) || !blob.size) throw new Error('No file was generated.');
      const now = new Date();
      const day = [now.getFullYear(), String(now.getMonth() + 1).padStart(2, '0'),
        String(now.getDate()).padStart(2, '0')].join('-');
      const filename = `Miami_Course_List_Schedule_${day}.${format}`;
      await downloadSchedule(blob, filename, format);
      // Cancel pending older saves before persisting the empty schedule.
      // Only the rows actually included in this export are removed.
      clearTimeout(saveTimer);
      const keys = rows.map(row => row.key), snapshot = new Map(schedule);
      for (const key of keys) schedule.delete(key);
      try { await persistSchedule(); }
      catch (storageError) {
        schedule.clear();
        for (const [key, row] of snapshot) schedule.set(key, row);
        throw new Error('File exported, but the saved schedule could not be cleared: ' + storageError.message);
      }
      const unchecked = globalThis.MCLCourseResults?.removeSelectedByKeys?.(keys) || 0;
      status(`${rows.length} scheduled section${rows.length === 1 ? '' : 's'} exported to ${format.toUpperCase()}; schedule cleared${unchecked ? ` and ${unchecked} checked row${unchecked === 1 ? '' : 's'} unchecked` : ''}. Saved filters were kept.`, 'ok');
    } catch (error) {
      if (error?.name === 'AbortError') status('Export canceled. Your schedule is unchanged.', 'info');
      else status('Schedule export failed: ' + (error?.message || 'unknown error') + '. Your draft was kept when possible.', 'error');
    } finally { exporting = false; render(); }
  }
  const CAL_START = 8 * 60, CAL_END = 21 * 60, CAL_ROW_PX = 28;
  const CAL_DAY_PX = 124, CAL_TIME_PX = 54;
  const CAL_DAYS = [1, 2, 3, 4, 5];
  function calTone(code) {
    let hash = 0;
    for (const ch of code) hash = ((hash * 31) + ch.charCodeAt(0)) >>> 0;
    return String(hash % 5);
  }
  function calendarLabels(block) {
    const course = courseIdentity(block.row) || 'Course code unavailable';
    const sec = block.row.section ? ` · Sec ${block.row.section}` : '';
    const crn = block.row.crn ? ` · CRN ${block.row.crn}` : '';
    const title = block.row.title ? ` · ${block.row.title}` : '';
    const dates = block.startDate !== null && block.endDate !== null
      ? ` · ${dateLabel(block.startDate)}–${dateLabel(block.endDate)}` : ' · dates unconfirmed';
    const room = columnValue(block.row, /^(?:building(?:\s*\/\s*room|\s+and\s+room)?|room|classroom|facility|location)$/i);
    return { course, room,
      full: `${course}${sec}${crn}${title}; ${DAYS[block.day]} ${displayClock(block.begin)}–${displayClock(block.finish)}${dates}${room ? '; ' + room : ''}${block.conflictText ? '; ' + block.conflictText : ''}` };
  }
  function slotPlacement(events) {
    // Greedy lane assignment, with lanes shared only by events that do not
    // overlap in clock time. Events in separate sprint dates may still be
    // drawn side by side, but only true date conflicts are colored red.
    const sorted = [...events].sort((a, b) => a.begin - b.begin || a.finish - b.finish);
    const groups = []; let group = [], groupEnd = -1;
    for (const event of sorted) {
      if (group.length && event.begin >= groupEnd) { groups.push(group); group = []; groupEnd = -1; }
      group.push(event); groupEnd = Math.max(groupEnd, event.finish);
    }
    if (group.length) groups.push(group);
    for (const eventsInGroup of groups) {
      const occupied = [];
      for (const event of eventsInGroup) {
        let lane = occupied.findIndex(end => end <= event.begin);
        if (lane < 0) { lane = occupied.length; occupied.push(event.finish); }
        else occupied[lane] = event.finish;
        event.lane = lane;
      }
      const lanes = occupied.length;
      for (const event of eventsInGroup) event.lanes = lanes;
    }
    return sorted;
  }
  function drawTermCalendar(container, term, items, marked) {
    const heading = document.createElement('h3');
    heading.className = 'mcl-calendar-term'; heading.textContent = term;
    container.append(heading);
    const weekdays = new Map(CAL_DAYS.map(day => [day, []]));
    const offgrid = [];
    const offgridSet = new Set();
    const addOffgrid = (item, message) => {
      const key = `${item.row.key}|${message}`;
      if (offgridSet.has(key)) return;
      offgridSet.add(key);
      offgrid.push({ row: item.row, reason: message });
    };
    for (const item of items) {
      if (!item.entries.length) {
        addOffgrid(item, item.description || 'Asynchronous / time not specified');
        continue;
      }
      for (const meeting of item.entries) {
        if (!CAL_DAYS.includes(meeting.day)) {
          addOffgrid(item, `${DAYS[meeting.day]} ${displayClock(meeting.begin)}–${displayClock(meeting.finish)}`);
          continue;
        }
        if (meeting.finish <= CAL_START || meeting.begin >= CAL_END) {
          addOffgrid(item, `${DAYS[meeting.day]} ${displayClock(meeting.begin)}–${displayClock(meeting.finish)} (outside 8 AM–9 PM)`);
          continue;
        }
        const reasons = [...(marked.get([item.row.key, meeting.day, meeting.begin, meeting.finish, meeting.startDate, meeting.endDate].join('|')) || [])];
        weekdays.get(meeting.day).push({ ...meeting, row: item.row,
          conflictText: reasons.join('; '), uncertain: reasons.some(reason => reason.includes('verify dates')) });
      }
    }
    const hasEvents = [...weekdays.values()].some(v => v.length);
    if (hasEvents) {
      const scroll = document.createElement('div');
      scroll.className = 'mcl-calendar-scroll'; scroll.tabIndex = 0;
      scroll.setAttribute('role', 'region');
      scroll.setAttribute('aria-label', `${term}, Monday through Friday schedule; scroll horizontally for more days`);
      const canvas = document.createElement('div'); canvas.className = 'mcl-calendar-canvas';
      const table = document.createElement('table'); table.className = 'mcl-calendar-table';
      table.setAttribute('aria-label', `Half-hour time grid for ${term}, Monday to Friday`);
      const cols = document.createElement('colgroup');
      const timeCol = document.createElement('col'); timeCol.className = 'time-col'; cols.append(timeCol);
      for (let i = 0; i < 5; i++) { const col = document.createElement('col'); col.className='day-col'; cols.append(col); }
      table.append(cols);
      const thead = document.createElement('thead');
      const trHead = document.createElement('tr');
      for (const label of ['Time', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri']) {
        const th = document.createElement('th'); th.scope = 'col'; th.textContent = label; trHead.append(th);
      }
      thead.append(trHead); table.append(thead);
      const tbody = document.createElement('tbody');
      for (let minute = CAL_START; minute < CAL_END; minute += 30) {
        const tr = document.createElement('tr');
        const th = document.createElement('th'); th.scope = 'row';
        th.textContent = displayClock(minute).replace(':00 ', ' ');
        tr.append(th);
        for (let day = 0; day < 5; day++) {
          const td = document.createElement('td');
          td.setAttribute('aria-label', `${DAYS[day + 1]} ${displayClock(minute)}–${displayClock(minute + 30)}`);
          tr.append(td);
        }
        tbody.append(tr);
      }
      table.append(tbody); canvas.append(table);
      const overlays = document.createElement('div'); overlays.className = 'mcl-calendar-overlays';
      for (let dayIndex = 0; dayIndex < 5; dayIndex++) {
        const day = dayIndex + 1;
        const track = document.createElement('div'); track.className = 'mcl-calendar-track';
        track.style.left = `${CAL_TIME_PX + dayIndex * CAL_DAY_PX}px`;
        const positioned = slotPlacement(weekdays.get(day) || []);
        for (const event of positioned) {
          const top = (Math.max(event.begin, CAL_START) - CAL_START) * CAL_ROW_PX / 30;
          const height = (Math.min(event.finish, CAL_END) - Math.max(event.begin, CAL_START)) * CAL_ROW_PX / 30;
          const card = document.createElement('div'); card.className = 'mcl-calendar-block';
          card.style.top = `${top + 1}px`;
          card.style.height = `${Math.max(13, height - 2)}px`;
          card.style.left = `calc(${event.lane * 100 / event.lanes}% + 2px)`;
          card.style.width = `calc(${100 / event.lanes}% - 4px)`;
          const labels = calendarLabels(event);
          card.dataset.tone = calTone(labels.course);
          if (event.lanes >= 3) card.dataset.narrow = 'true';
          if (event.conflictText) card.dataset.conflict = 'true';
          if (event.uncertain) card.dataset.uncertain = 'true';
          card.title = labels.full;
          card.setAttribute('role', 'group'); card.tabIndex = 0;
          card.setAttribute('aria-label', labels.full);
          const code = document.createElement('span'); code.className = 'mcl-calendar-code';
          if (event.lanes >= 3 && /^[A-Z]{2,4}\s+\d{3,4}[A-Z]?$/i.test(labels.course)) {
            const [subject, number] = labels.course.split(/\s+/);
            const left = document.createElement('span'); left.className = 'mcl-calendar-subject'; left.textContent = subject + ' ';
            const right = document.createElement('span'); right.className = 'mcl-calendar-number'; right.textContent = number;
            code.append(left, right);
          } else code.textContent = labels.course;
          card.append(code);
          if (height >= 34) {
            const clockLine = document.createElement('span'); clockLine.className = 'mcl-calendar-eventtime';
            clockLine.textContent = `${displayClock(event.begin).replace(' AM', 'a').replace(' PM','p')}–${displayClock(event.finish).replace(' AM','a').replace(' PM','p')}`;
            card.append(clockLine);
          }
          if (height >= 71 && labels.room) {
            const room = document.createElement('span'); room.className = 'mcl-calendar-eventroom';
            room.textContent = labels.room; card.append(room);
          }
          track.append(card);
        }
        overlays.append(track);
      }
      canvas.append(overlays); scroll.append(canvas); container.append(scroll);
      const legend = document.createElement('div'); legend.className = 'mcl-calendar-key';
      for (const [label, extra] of [['Class meeting', ''], ['Overlapping day, time and dates', 'conflict']]) {
        const item = document.createElement('span'); item.className = 'mcl-calendar-key-item';
        const swatch = document.createElement('i'); swatch.className = `mcl-calendar-swatch ${extra}`.trim(); swatch.setAttribute('aria-hidden', 'true');
        item.append(swatch, document.createTextNode(label)); legend.append(item);
      }
      container.append(legend);
    } else {
      addLine(container, 'No Monday–Friday meetings with confirmed times in this term.', 'mcl-calendar-help');
    }
    if (offgrid.length) {
      const box = document.createElement('section'); box.className = 'mcl-calendar-offgrid';
      addLine(box, 'Asynchronous, TBA, weekend or outside grid', 'mcl-calendar-offgrid-heading');
      const ul = document.createElement('ul');
      for (const { row, reason } of offgrid) {
        const li = document.createElement('li');
        li.textContent = `${courseIdentity(row) || 'Course code unavailable'}${row.section ? ' · Sec ' + row.section : ''}: ${reason}`;
        ul.append(li);
      }
      box.append(ul); container.append(box);
    }
  }
  function addLine(container, text, cls) {
    const node = document.createElement('div');
    node.className = cls;
    node.textContent = text;
    container.append(node);
    return node;
  }
  function render() {
    if (!started) return;
    const selectedCount = globalThis.MCLCourseResults?.getSelected?.().length || 0;
    ui.add.disabled = exporting || !selectedCount;
    ui.clear.disabled = exporting || !schedule.size;
    for (const control of [ui.xlsx, ui.csv, ui.pdf]) control.disabled = exporting || !schedule.size;
    ui.summary.textContent = `${schedule.size} section${schedule.size === 1 ? '' : 's'}`;
    ui.stats.textContent = '';
    ui.selectedHint.textContent = selectedCount
      ? `${selectedCount} checked section${selectedCount === 1 ? '' : 's'} available to add (across searches).`
      : 'Check course result rows, then add them to the schedule.';
    ui.list.replaceChildren();
    ui.calendars.replaceChildren();
    if (!schedule.size) {
      addLine(ui.calendars, 'Add checked course sections to see your Monday–Friday calendar.', 'mcl-schedule-empty');
      addLine(ui.list, 'Your schedule is empty. Apply filters, check course sections, then choose Add checked courses.', 'mcl-schedule-empty');
      return;
    }
    const byTerm = new Map(), marked = new Map();
    for (const row of schedule.values()) {
      const term = row.term || 'Term not specified';
      if (!byTerm.has(term)) byTerm.set(term, []);
      byTerm.get(term).push({ row, ...meetingInfo(row) });
    }
    let conflicts = 0, unknown = 0, unknownDates = 0;
    const slotKey = event => [event.row.key, event.day, event.begin, event.finish, event.startDate, event.endDate].join('|');
    const summaries = [];
    for (const [term, items] of byTerm) {
      const title = document.createElement('h3'); title.className = 'mcl-schedule-term';
      title.textContent = term; ui.list.append(title);
      const byDay = new Map(), unscheduled = [];
      for (const item of items) {
        if (!item.entries.length) { unscheduled.push(item); unknown++; }
        for (const event of item.entries) {
          const arr = byDay.get(event.day) || [];
          arr.push({ ...event, row: item.row }); byDay.set(event.day, arr);
        }
      }
      const conflictPairs = new Set();
      for (const [day, events] of byDay) {
        events.sort((a, b) => a.begin - b.begin || a.finish - b.finish);
        for (let i = 0; i < events.length; i++) for (let j = i + 1; j < events.length; j++) {
          const first = events[i], second = events[j];
          if (second.begin >= first.finish) break;
          if (first.row.key === second.row.key) continue;
          const dateTest = overlappingDates(first, second);
          if (!dateTest.overlap) continue;
          const pairKey = [first.row.key, second.row.key].sort().join('|');
          if (!conflictPairs.has(pairKey)) {
            conflicts++; conflictPairs.add(pairKey);
            if (dateTest.unknownDates) unknownDates++;
            const left = courseIdentity(first.row) || first.row.crn || 'Section A';
            const right = courseIdentity(second.row) || second.row.crn || 'Section B';
            summaries.push(`${left} / ${right} · ${DAYS[day]} ${displayClock(Math.max(first.begin, second.begin))}–${displayClock(Math.min(first.finish, second.finish))}${dateTest.unknownDates ? ' (meeting dates unconfirmed)' : ' (date ranges overlap)'}`);
          }
          const reason = `Overlaps ${courseIdentity(second.row) || second.row.crn || 'another section'}${dateTest.unknownDates ? ' · verify dates' : ''}`;
          const reverse = `Overlaps ${courseIdentity(first.row) || first.row.crn || 'another section'}${dateTest.unknownDates ? ' · verify dates' : ''}`;
          const addReason = (slot, message) => {
            const key = slotKey(slot);
            if (!marked.has(key)) marked.set(key, new Set());
            marked.get(key).add(message);
          };
          addReason(first, reason);
          addReason(second, reverse);
        }
      }
      for (let day = 0; day < DAYS.length; day++) {
        const events = byDay.get(day);
        if (!events?.length) continue;
        addLine(ui.list, DAYS[day], 'mcl-schedule-day');
        for (const slot of events) {
          const when = `${displayClock(slot.begin)}–${displayClock(slot.finish)}` +
            (slot.startDate !== null && slot.endDate !== null ? ` · ${dateLabel(slot.startDate)}–${dateLabel(slot.endDate)}` : ' · meeting dates not confirmed');
          renderItem(ui.list, slot.row, when, [...(marked.get(slotKey(slot)) || [])].join(' · '));
        }
      }
      if (unscheduled.length) {
        addLine(ui.list, 'No confirmed meeting time', 'mcl-schedule-day');
        for (const item of unscheduled) renderItem(ui.list, item.row, item.description || 'Time not listed', '');
      }
      drawTermCalendar(ui.calendars, term, items, marked);
    }
    ui.stats.textContent = `${conflicts} potential schedule conflict${conflicts === 1 ? '' : 's'}` +
      (unknownDates ? ` · ${unknownDates} with dates to verify` : '') +
      (unknown ? ` · ${unknown} without usable meeting times` : '');
    if (conflicts) {
      const note = document.createElement('div'); note.className = 'mcl-schedule-warning';
      addLine(note, 'Potential conflicts — shared days/times (meeting dates checked when available):', 'mcl-schedule-clash');
      for (const text of summaries.slice(0, 6)) addLine(note, text, 'mcl-schedule-caption');
      if (summaries.length > 6) addLine(note, `…and ${summaries.length - 6} more`, 'mcl-schedule-caption');
      ui.list.prepend(note);
    }
  }
  function renderItem(container, row, time, conflictReason) {
    const card = document.createElement('div'); card.className = 'mcl-schedule-item';
    if (conflictReason) card.classList.add('mcl-schedule-conflict');
    const body = document.createElement('div'); body.className = 'mcl-schedule-item-content';
    const course = courseIdentity(row) || 'Course code unavailable';
    addLine(body, `${course}${row.section ? ' · Sec ' + row.section : ''}${row.crn ? ' · CRN ' + row.crn : ''}`, 'mcl-schedule-course');
    if (row.title) addLine(body, row.title, 'mcl-schedule-caption');
    addLine(body, time, 'mcl-schedule-time');
    const buildingRoom = columnValue(row, /^(?:building(?:\s*\/\s*room|\s+and\s+room)?|room|classroom|facility|location)$/i);
    if (buildingRoom) addLine(body, buildingRoom, 'mcl-schedule-caption');
    if (row.campus && row.campus !== buildingRoom) addLine(body, row.campus, 'mcl-schedule-caption');
    if (conflictReason) addLine(body, conflictReason, 'mcl-schedule-clash');
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'mcl-schedule-remove'; button.textContent = '×';
    button.disabled = exporting;
    button.title = 'Remove section from schedule';
    button.setAttribute('aria-label', `Remove ${course} ${row.section || row.crn} from schedule`);
    button.addEventListener('click', () => remove(row.key));
    card.append(body, button); container.append(card);
  }
  async function start({ shadow, setStatus }) {
    if (started) return;
    status = setStatus;
    ui = {
      add: shadow.getElementById('scheduleAdd'), clear: shadow.getElementById('scheduleClear'),
      xlsx: shadow.getElementById('scheduleXlsx'), csv: shadow.getElementById('scheduleCsv'),
      pdf: shadow.getElementById('schedulePdf'),
      summary: shadow.getElementById('scheduleSummary'), selectedHint: shadow.getElementById('scheduleSelectedHint'),
      stats: shadow.getElementById('scheduleStats'),
      list: shadow.getElementById('scheduleList'),
      calendars: shadow.getElementById('scheduleCalendars'),
      accordion: shadow.getElementById('scheduleAccordion')
    };
    if (Object.values(ui).some(value => !value)) throw new Error('Schedule panel controls were not found.');
    ui.add.addEventListener('click', addChecked);
    ui.clear.addEventListener('click', clearSchedule);
    for (const format of ['xlsx', 'csv', 'pdf']) {
      ui[format].addEventListener('click', () => exportSchedule(format));
    }
    await readSaved(); started = true;
    if (ui.accordion && schedule.size) ui.accordion.open = true;
    globalThis.MCLCourseResults?.onSelectionChange?.(render);
    render();
  }
  // Expose pure helpers for local regression verification, not site automation.
  globalThis.MCLScheduleBuilder = Object.freeze({ start, dayCodes, meetingInfo, dateWindows, overlappingDates, getSchedule: () => [...schedule.values()] });
})();
