/* Miami Course List: select every result row and export its displayed columns verbatim.
 * v1.8.1: identify course codes using course fields rather than room/building fields.
 * v1.7.0: result rows do not need to repeat a course code; preserve original
 * result headers/values and the order of selection across searches.
 */
(() => {
  'use strict';
  const SELECTION_KEY = 'mcl_lite_selected_courses_v1'; // Never change: preserves v1.5 selections.
  const MAX_SELECTED = 1000;
  const MAX_CANDIDATES = 3000;
  const MAX_COLUMNS = 48;
  const COURSE_RE = /\b([A-Z]{2,4})\s*[- ]?\s*(\d{3}[A-Z]?)\b/i;
  const CRN_RE = /\bCRN\s*[:#-]?\s*(\d{5})\b/i;
  const norm = v => String(v == null ? '' : v).replace(/\s+/g, ' ').trim();
  const cut = (v, n = 1000) => norm(v).slice(0, n);
  const codeIn = v => { const m = norm(v).match(COURSE_RE); return m ? `${m[1]} ${m[2]}`.toUpperCase() : ''; };
  const selected = new Map();
  const selectionListeners = new Set();
  const rowByNode = new WeakMap();
  let status, readTerm, shadow, ui = {}, observer, scanTimer, saveTimer;
  let active = false, loaded = false, lastShown = 0, visible = new Map();

  function sourceText(el) {
    if (!el) return '';
    return cut(String(el.innerText || el.textContent || '')
      .replace(/\b(?:show|hide|view)\s+(?:course\s+)?details\b/gi, '')
      .replace(/\b(?:expand|collapse)\s+(?:course\s+)?details\b/gi, ''), 800);
  }
  function withoutExportText(node) {
    // Used on cards (table cell extraction excludes injected export columns).
    const clone = node.cloneNode(true);
    clone.querySelectorAll('[data-mcl-export-pick], [data-mcl-export-column]').forEach(x => x.remove());
    return sourceText(clone);
  }
  function isVisible(node) {
    if (!node.isConnected || node.closest('#mcl-lite-host, header, nav, footer')) return false;
    if (node.getAttribute('aria-hidden') === 'true' || node.hidden) return false;
    const css = getComputedStyle(node);
    return css.display !== 'none' && css.visibility !== 'hidden' && !!node.getClientRects().length;
  }
  function tableHeaderCells(table) {
    const head = [...table.querySelectorAll('thead tr')].filter(tr => tr.closest('table') === table).at(-1) ||
      [...table.querySelectorAll('tr')].find(tr => tr.closest('table') === table && tr.querySelector('th') && !tr.querySelector('td'));
    return head ? [...head.children].filter(el => el.matches('th,td') && !el.matches('[data-mcl-export-column]')) : [];
  }
  function expandedHeaders(table) {
    const list = [];
    for (const cell of tableHeaderCells(table)) {
      const label = sourceText(cell) || `Column ${list.length + 1}`;
      for (let i = 0; i < Math.min(12, cell.colSpan || 1); i++) list.push(label);
    }
    return list.slice(0, MAX_COLUMNS);
  }
  function tableLayout(table) {
    const headers = expandedHeaders(table);
    const data = new Map();
    const carry = new Map();
    const tableRows = [...table.querySelectorAll('tr')].filter(tr => tr.closest('table') === table &&
      tr.parentElement?.tagName !== 'THEAD');
    for (const tr of tableRows) {
      const slots = [];
      for (const [col, item] of [...carry]) {
        slots[col] = item.text;
        if (--item.remaining <= 0) carry.delete(col);
      }
      const cells = [...tr.children].filter(el => el.matches('td,th') && !el.matches('[data-mcl-export-column]'));
      let index = 0;
      for (const cell of cells) {
        while (slots[index] !== undefined && index < MAX_COLUMNS) index++;
        const text = sourceText(cell);
        const span = Math.min(12, cell.colSpan || 1);
        for (let i = 0; i < span && index + i < MAX_COLUMNS; i++) {
          slots[index + i] = text;
          if ((cell.rowSpan || 1) > 1) carry.set(index + i, { text, remaining: cell.rowSpan - 1 });
        }
        index += span;
      }
      const count = Math.min(MAX_COLUMNS, Math.max(headers.length, slots.length));
      const columns = Array.from({ length: count }, (_, idx) => ({
        label: cut(headers[idx] || `Column ${idx + 1}`, 90), value: cut(slots[idx] || '', 650)
      }));
      data.set(tr, { columns, cells });
    }
    return data;
  }
  function tableLooksLikeCourseResults(table) {
    const labels = expandedHeaders(table).map(h => h.toLowerCase().replace(/[^a-z]+/g, ' ').trim());
    const seen = labels.filter(h => /^(course|course code|subject|class|class code|course title|title|crn|section|sec|course number|instructor|days time|campus)$/.test(h));
    return seen.length >= 2 && seen.some(h => /^(course|course code|course title|crn|section|class|subject)$/.test(h));
  }
  function siteResultsScopes() {
    const selectors = [
      '#results', '#search-results', '#searchResults', '#courseResults', '#course-results',
      '#courseListResults', '#course-list-results', '#courseList', '#resultList',
      '.search-results', '.course-results', '.course-result-list', '.course-list-results',
      '[data-testid="results"]', '[data-testid="course-results"]',
      '[id*="searchResult" i]', '[class*="search-results" i]',
      '[id*="courseResult" i]', '[class*="course-results" i]',
      '[id*="results" i]', '[class*="result-list" i]', '[class*="result-container" i]'
    ];
    const scopes = [...document.querySelectorAll(selectors.join(','))].filter(node => {
      if (!node.isConnected || node.closest('#mcl-lite-host, header, footer, nav')) return false;
      if (node.matches('input,button,select,textarea,label')) return false;
      return !!node.querySelector('table, tr, article, li, [class*="course"], [class*="result"], [role="row"]');
    });
    // The site can replace its results container. Find genuine course grids
    // independently, without accidentally targeting the search form.
    for (const table of document.querySelectorAll('table')) {
      if (table.closest('#mcl-lite-host, header, nav, footer')) continue;
      if (tableLooksLikeCourseResults(table)) scopes.push(table);
    }
    // A heading can identify an unwrapped list of course result cards.
    for (const heading of document.querySelectorAll('h1,h2,h3,h4,[role="heading"]')) {
      if (!/^(?:(?:search|course)\s+results?|results?(?:\s*\([\d,]+\))?|matching\s+(?:courses|classes))\b/i.test(norm(heading.textContent))) continue;
      const sibling = heading.nextElementSibling;
      if (sibling && !sibling.matches('form') && !sibling.closest('#mcl-lite-host')) scopes.push(sibling);
    }
    return [...new Set(scopes)];
  }
  function candidateNodes(scope) {
    const nodes = [];
    if (scope.matches('table')) {
      nodes.push(...scope.querySelectorAll('tr'));
      return nodes.filter(row => row.closest('table') === scope && !!row.querySelector('td'));
    }
    for (const table of scope.querySelectorAll('table')) {
      if (table.closest('#mcl-lite-host')) continue;
      nodes.push(...[...table.querySelectorAll('tr')].filter(tr => tr.closest('table') === table && !!tr.querySelector('td')));
    }
    const selectors = [
      '[data-course-code]', '[data-crn]', '[data-testid*="course-result"]',
      'article', '.course-result', '.class-result', '.course-row', '.class-row',
      '[class*="course-item" i]', '[class*="class-item" i]',
      '[class*="course-card" i]', '[class*="class-card" i]',
      '[class*="section-row" i]', '[role="row"]', '.result-item', '.list-group-item'
    ];
    for (const node of scope.querySelectorAll(selectors.join(','))) {
      if (node.closest('table, #mcl-lite-host') || node.querySelector('form')) continue;
      // A wrapper around individual result cards should not get another pick.
      if (node.querySelector(':scope > article, :scope > .course-result, :scope > .class-result, :scope > [class*="course-card"]')) continue;
      nodes.push(node);
    }
    if (!nodes.some(node => node.tagName !== 'TR' && (codeIn(node.textContent) || CRN_RE.test(node.textContent)))) {
      for (const node of scope.querySelectorAll(':scope > li, :scope > div, :scope > article, :scope > section, :scope > ul > li')) {
        if (node.querySelector('form,table')) continue;
        if (codeIn(node.textContent) || CRN_RE.test(node.textContent)) nodes.push(node);
      }
    }
    if (scope.matches('article,li,.course-result,.class-result,.course-row,.class-row') && !nodes.length) nodes.push(scope);
    return nodes;
  }
  function isCourseTableRow(node, record) {
    if (!record || !record.cells.length) return false;
    if (node.closest('thead,tfoot') || node.matches('[aria-hidden="true"], [hidden]')) return false;
    const original = record.cells.filter(cell => cell.tagName === 'TD');
    if (!original.length) return false;
    const content = record.columns.map(c => c.value).filter(Boolean).join(' ');
    if (!content || /^(no\s+(?:results|courses|matches|records)|loading\s*(?:\.\.\.)?|total\s*:\s*\d+)$/i.test(content)) return false;
    if (original.length === 1 && (original[0].colSpan || 1) > 1 && !/\bCRN\b|\bSection\b/i.test(content)) return false;
    // Unlike 1.5, the section's row does NOT need its own course code.
    return true;
  }
  function cardColumns(node) {
    // Preserve visible block order, including headings and field/value lines.
    const columns = [];
    const pieces = [...node.querySelectorAll('h2,h3,h4,h5,h6,p,li,dt,dd,[role="cell"]')]
      .filter(el => !el.closest('[data-mcl-export-pick], [data-mcl-export-column]'));
    const raw = pieces.length ? pieces : [node];
    let detail = 0;
    for (const el of raw.slice(0, MAX_COLUMNS)) {
      const text = el === node ? withoutExportText(node) : sourceText(el);
      if (!text) continue;
      if (/^H[2-6]$/.test(el.tagName)) { columns.push({ label: 'Course', value: cut(text, 650) }); continue; }
      const m = text.match(/^([^:]{1,58})\s*:\s*(.*)$/);
      if (m) columns.push({ label: cut(m[1], 90), value: cut(m[2], 650) });
      else { detail++; columns.push({ label: detail === 1 ? 'Details' : `Details ${detail}`, value: cut(text, 650) }); }
    }
    if (!columns.length) columns.push({ label: 'Course', value: withoutExportText(node) });
    return columns;
  }
  function namedValue(columns, pattern) {
    return columns.find(c => pattern.test(c.label))?.value || '';
  }
  // Building/room values such as PHS 207 look like course codes to a generic
  // two/three-letter-plus-number regex. Prefer *semantic* course fields, and
  // never take a fallback course code from a location or meeting field.
  const COURSE_FIELD = /^(?:course(?:\s+(?:code|number|no\.?|id))?|class(?:\s+(?:code|number|no\.?|id))?|catalog\s+(?:course|code)|subject\s*(?:\/|&|and)\s*(?:course\s*)?(?:number|no\.?))$/i;
  const SUBJECT_FIELD = /^(?:subject(?:\s+code)?|subj\.?|dept(?:artment)?(?:\s+code)?)$/i;
  const NUMBER_FIELD = /^(?:course\s*(?:number|no\.?|#)|catalog\s*(?:number|no\.?)|class\s*(?:number|no\.?|#)|number)$/i;
  const NOT_COURSE_FIELD = /(?:building|room|location|venue|facility|address|campus|site|days?|times?|meeting|schedule|instructor|faculty|professor|credits?|hours|seats|status|date|delivery|modality|section|crn|notes?)/i;
  function courseFromColumns(columns) {
    // A university result grid may split the subject and number across cells.
    const subject = norm(namedValue(columns, SUBJECT_FIELD)).toUpperCase();
    const number = norm(namedValue(columns, NUMBER_FIELD)).toUpperCase();
    if (/^[A-Z]{2,4}$/.test(subject) && /^\d{3,4}[A-Z]?$/.test(number)) return `${subject} ${number}`;
    for (const col of columns) {
      if (COURSE_FIELD.test(norm(col.label))) {
        const code = codeIn(col.value);
        if (code) return code;
      }
    }
    // Course titles sometimes begin with the code even when no Course column exists.
    for (const col of columns) {
      if (/^(?:course\s+title|class\s+title|title|course\s+name)$/i.test(norm(col.label))) {
        const code = codeIn(col.value);
        if (code) return code;
      }
    }
    // Generic column headings are a last resort, but still exclude location
    // cells rather than extracting the building and room as a course.
    for (const col of columns) {
      if (NOT_COURSE_FIELD.test(norm(col.label))) continue;
      const code = codeIn(col.value);
      if (code && /^(?:column\s+\d+|details(?:\s+\d+)?)$/i.test(norm(col.label))) return code;
    }
    return '';
  }
  function fallbackCourse(node) {
    // Section rows frequently omit Course because a preceding row or a spanning
    // cell contains the course heading. Still check the row even if unresolved.
    if (node.tagName === 'TR') {
      let sibling = node.previousElementSibling;
      for (let tries = 0; sibling && tries < 12; tries++, sibling = sibling.previousElementSibling) {
        const table = sibling.closest('table');
        const headers = table ? expandedHeaders(table) : [];
        const cells = [...sibling.children].filter(el => el.matches('td,th'));
        const courseColumns = cells.map((el, index) => ({ label: headers[index] || `Column ${index + 1}`, value: sourceText(el) }));
        const code = courseFromColumns(courseColumns);
        if (code) return code;
      }
    }
    let parent = node.parentElement;
    for (let i = 0; parent && i < 4; i++, parent = parent.parentElement) {
      const heading = parent.querySelector('h2,h3,h4,h5,.course-title,.course-heading');
      const code = codeIn(heading?.textContent || '');
      if (code) return code;
    }
    return '';
  }
  function makeRow(node, layout) {
    if (node.tagName === 'TR' && !isCourseTableRow(node, layout)) return null;
    const columns = node.tagName === 'TR' ? layout.columns : cardColumns(node);
    if (!columns.length) return null;
    const raw = columns.map(c => c.value).filter(Boolean).join(' | ');
    if (node.tagName !== 'TR' && !codeIn(raw) && !CRN_RE.test(raw) && !/\bSection\s*[:#]/i.test(raw)) return null;
    // Never identify a course by scanning the entire row: Building / Room
    // strings like PHS 207 are ambiguous and belong in location fields.
    const course = courseFromColumns(columns) || fallbackCourse(node);
    const title = cut(namedValue(columns, /^(?:course title|class title|title|course name)$/i), 300);
    const crn = cut(namedValue(columns, /^(?:crn|course reference number|reference number)$/i).match(/\d{5}/)?.[0] || raw.match(CRN_RE)?.[1] || '', 12);
    const section = cut(namedValue(columns, /^(?:section|sec\.?|section number)$/i), 35);
    const term = cut(namedValue(columns, /^(?:term|semester)$/i) || readTerm?.() || '', 90);
    const campus = cut(namedValue(columns, /^(?:campus|location)$/i), 75);
    const modality = cut(namedValue(columns, /^(?:modality|delivery type|delivery|instruction method|instruction type)$/i), 95);
    const instructor = cut(namedValue(columns, /^(?:instructor|faculty|professor)$/i), 120);
    const meeting = cut(namedValue(columns, /^(?:days?\s*\/\s*time|days|times?|schedule|meeting time|meeting dates?\s*(?:and|\/|&)\s*times?|dates?\s*(?:and|\/|&)\s*times?)$/i), 350);
    // Capture the far-right displayed cell independently so line breaks in
    // combined meeting date/time patterns survive without altering exports.
    const finalCell = node.tagName === 'TR' ? layout.cells.at(-1) : null;
    const lastColumn = columns.at(-1);
    const cellRaw = finalCell ? String(finalCell.innerText || finalCell.textContent || '') : '';
    const meetingDetails = (lastColumn && /\b\d{1,2}:\d{2}\b/.test(lastColumn.value) &&
      (/(?:meeting|schedule|days?|times?|dates?|when)/i.test(lastColumn.label) ||
       /\b(?:mon|tue|wed|thu|fri|sat|sun|MWF|TR)\b/i.test(lastColumn.value) ||
       /\b\d{1,2}\/\d{1,2}\/\d{2,4}\b/.test(lastColumn.value)))
      ? cut((cellRaw || lastColumn.value).replace(/\b(?:show|hide|view)\s+(?:course\s+)?details\b/gi, ''), 1600) : '';
    const credits = cut(namedValue(columns, /^(?:credits?|credit hours?|hours?)$/i), 35);
    const statusValue = cut(namedValue(columns, /^(?:status|seats|open seats|availability)$/i), 80);
    const key = crn ? `crn|${term}|${crn}`.toLowerCase() :
      `row|${term}|${columns.map(c => `${c.label}:${c.value}`).join('\u001e')}`.toLowerCase().slice(0, 2800);
    return { key, term, course, title, crn, section, campus, modality, instructor, meeting, meetingDetails, credits, status: statusValue,
      details: cut(raw, 1600), columns: columns.map(c => ({ label: cut(c.label, 90), value: cut(c.value, 650) })) };
  }
  function checkboxFor(node, record) {
    rowByNode.set(node, record);
    let pick = [...node.children].find(el => el.matches?.('[data-mcl-export-pick]')) ||
      node.querySelector(':scope > [data-mcl-export-column] > [data-mcl-export-pick]');
    if (!pick) {
      pick = document.createElement('label');
      pick.dataset.mclExportPick = 'true'; pick.dataset.mclIgnore = 'true';
      pick.style.cssText = 'display:inline-flex;align-items:center;gap:4px;background:#fff7f9;border:1px solid #e7b7c1;border-radius:5px;padding:4px 6px;margin:2px 4px;font:600 12px system-ui,Arial,sans-serif;color:#70182c;cursor:pointer;white-space:nowrap;';
      const input = document.createElement('input');
      input.type = 'checkbox'; input.dataset.mclCourseCheck = 'true';
      input.style.cssText = 'accent-color:#b31b34;width:16px;height:16px;margin:0;cursor:pointer;';
      const label = document.createElement('span'); label.textContent = 'Export';
      pick.append(input, label);
      pick.addEventListener('click', e => e.stopPropagation());
      input.addEventListener('change', e => {
        e.stopPropagation();
        const latest = rowByNode.get(node);
        if (!latest) return;
        if (e.currentTarget.checked) {
          if (!selected.has(latest.key) && selected.size >= MAX_SELECTED) {
            e.currentTarget.checked = false;
            status?.('Selection limit is 1,000 rows. Export or clear selections before adding more.', 'warn');
            return;
          }
          selected.set(latest.key, latest);
        } else selected.delete(latest.key);
        scheduleSave(); syncBoxes(); updatePanel();
      });
      if (node.tagName === 'TR') {
        const cell = document.createElement('td');
        cell.dataset.mclExportColumn = 'true'; cell.dataset.mclIgnore = 'true';
        cell.style.cssText = 'vertical-align:middle;padding:3px;white-space:nowrap;';
        cell.append(pick); node.insertBefore(cell, node.firstElementChild);
        const table = node.closest('table');
        const header = [...(table?.querySelectorAll('thead tr') || [])].filter(tr => tr.closest('table') === table).at(-1);
        if (header && !header.querySelector('[data-mcl-export-column]')) {
          const th = document.createElement('th'); th.dataset.mclExportColumn = 'true'; th.dataset.mclIgnore = 'true';
          th.scope = 'col'; th.textContent = 'Export'; th.style.cssText = 'padding:4px 6px;color:#74142a;';
          header.insertBefore(th, header.firstElementChild);
        }
      } else node.prepend(pick);
    }
    const input = pick.querySelector('[data-mcl-course-check]');
    input.dataset.key = record.key;
    input.setAttribute('aria-label', 'Select ' + (record.course || record.title || record.crn || 'result row') + (record.section ? ' section ' + record.section : '') + ' for export');
    input.checked = selected.has(record.key);
  }
  function scan() {
    scanTimer = null;
    if (!active) return;
    const found = new Map(), seen = new Set(), eligible = new Set(), layouts = new WeakMap();
    let inspected = 0;
    for (const scope of siteResultsScopes()) {
      for (const node of candidateNodes(scope)) {
        if (++inspected > MAX_CANDIDATES) break;
        if (seen.has(node) || !isVisible(node)) continue;
        seen.add(node);
        let layout = null;
        if (node.tagName === 'TR') {
          const table = node.closest('table');
          if (!table) continue;
          if (!layouts.has(table)) layouts.set(table, tableLayout(table));
          layout = layouts.get(table).get(node);
        }
        const row = makeRow(node, layout);
        if (!row) continue;
        if (node.tagName !== 'TR' && node.querySelector('[data-mcl-export-column], [data-mcl-export-pick]')) continue;
        let key = row.key;
        for (let suffix = 2; found.has(key); suffix++) key = row.key + '|duplicate-' + suffix;
        row.key = key;
        found.set(key, row);
        eligible.add(node);
        checkboxFor(node, row);
        // Keep the most recent detail text for previously selected courses.
        if (selected.has(row.key)) selected.set(row.key, row);
      }
      if (inspected > MAX_CANDIDATES) break;
    }
    // The Course List occasionally reuses a row to show an empty-state message.
    // Remove any old export control from a row that is no longer a result.
    for (const input of document.querySelectorAll('input[data-mcl-course-check]')) {
      const pick = input.closest('[data-mcl-export-pick]');
      const row = pick?.closest('tr');
      const candidate = row || pick?.parentElement;
      if (candidate && !eligible.has(candidate)) {
        const cell = pick.closest('[data-mcl-export-column]');
        (cell || pick).remove();
      }
    }
    for (const table of document.querySelectorAll('table')) {
      if (!table.querySelector('input[data-mcl-course-check]')) {
        table.querySelectorAll('thead [data-mcl-export-column]').forEach(th => th.remove());
      }
    }
    visible = found; lastShown = found.size; updatePanel();
  }
  function scheduleScan() {
    if (!active || scanTimer) return;
    scanTimer = setTimeout(scan, 180);
  }
  function syncBoxes() {
    for (const input of document.querySelectorAll('input[data-mcl-course-check]')) {
      input.checked = selected.has(input.dataset.key);
    }
  }
  function scheduleSave() { clearTimeout(saveTimer); saveTimer = setTimeout(save, 130); }
  async function save() {
    if (!loaded) return;
    try {
      await new Promise((resolve, reject) => chrome.storage.local.set({ [SELECTION_KEY]: [...selected.values()] }, () => {
        if (chrome.runtime?.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve();
      }));
    } catch (err) { status?.('Could not persist selected courses: ' + err.message, 'warn'); }
  }
  async function load() {
    try {
      const result = await new Promise(resolve => chrome.storage.local.get(SELECTION_KEY, resolve));
      const values = result?.[SELECTION_KEY];
      if (Array.isArray(values)) for (const raw of values.slice(0, MAX_SELECTED)) {
        if (!raw || typeof raw.key !== 'string' || raw.key.length > 4000) continue;
        if (typeof raw.course !== 'string' && !Array.isArray(raw.columns)) continue;
        const row = {
          key: raw.key, term: cut(raw.term, 90), course: cut(raw.course, 20), title: cut(raw.title, 300),
          section: cut(raw.section, 35), crn: cut(raw.crn, 12), campus: cut(raw.campus, 75),
          modality: cut(raw.modality, 95), instructor: cut(raw.instructor, 120), meeting: cut(raw.meeting, 190), meetingDetails: cut(raw.meetingDetails, 1600),
          credits: cut(raw.credits, 35), status: cut(raw.status, 80), details: cut(raw.details, 1600),
          columns: Array.isArray(raw.columns) ? raw.columns.slice(0, MAX_COLUMNS).map(c => ({ label: cut(c?.label, 90), value: cut(c?.value, 650) })) : []
        };
        selected.set(row.key, row);
      }
    } catch (err) { status?.('Saved selections could not be read: ' + (err.message || ''), 'warn'); }
    finally { loaded = true; }
  }
  function updatePanel() {
    for (const callback of selectionListeners) { try { callback(); } catch (error) { console.warn('[Course List schedule] selection refresh:', error); } }
    if (!ui.count) return;
    ui.count.textContent = `${selected.size} selected  •  ${lastShown} shown`;
    ui.hint.textContent = lastShown ? 'Every displayed result row has an Export checkbox. You can select all rows shown.' :
      'Run Find to show results. Each result row will get a checkbox.';
    ui.selectAll.disabled = !visible.size;
    ui.clear.disabled = !selected.size;
    for (const button of [ui.xlsx, ui.csv, ui.pdf]) button.disabled = !selected.size;
    ui.list.replaceChildren();
    for (const row of [...selected.values()].slice(0, 16)) {
      const li = document.createElement('li'); li.style.cssText = 'display:flex;gap:5px;align-items:start;margin-top:5px;';
      const item = document.createElement('span'); item.style.cssText = 'flex:1;min-width:0;overflow-wrap:anywhere;';
      item.textContent = (row.course || row.title || row.crn || row.columns?.[0]?.value || 'Result row') +
        (row.section ? ' · ' + row.section : '') + (row.crn ? ' · ' + row.crn : '');
      const remove = document.createElement('button'); remove.type = 'button'; remove.textContent = '×';
      remove.title = 'Remove this row'; remove.setAttribute('aria-label', 'Remove selected row ' + item.textContent);
      remove.style.cssText = 'background:#fff;border:1px solid #ddd;border-radius:4px;color:#97192e;cursor:pointer;font-size:15px;';
      remove.addEventListener('click', () => { selected.delete(row.key); scheduleSave(); syncBoxes(); updatePanel(); });
      li.append(item, remove); ui.list.append(li);
    }
    if (selected.size > 16) {
      const extra = document.createElement('li'); extra.textContent = `... and ${selected.size - 16} more. Use Reset checkboxes or uncheck result rows.`;
      ui.list.append(extra);
    }
    ui.details.hidden = !selected.size;
  }
  function pickAllShown() {
    let added = 0;
    for (const [key, row] of visible) {
      if (selected.has(key)) continue;
      if (selected.size >= MAX_SELECTED) { status?.('Selection limit is 1,000 rows.', 'warn'); break; }
      selected.set(key, row); added++;
    }
    scheduleSave(); syncBoxes(); updatePanel();
    status?.(`${added} displayed rows added. Previous selections remain available across searches.`, 'ok');
  }
  function clearAll() {
    if (!selected.size) return;
    if (selected.size > 1 && !window.confirm(`Reset all ${selected.size} export checkboxes? Your draft schedule and saved presets will be kept.`)) return;
    selected.clear(); scheduleSave(); syncBoxes(); updatePanel();
    status?.('All export checkboxes reset. Your draft schedule and saved filters are unchanged.', 'ok');
  }
  // The schedule exporter clears only the rows actually included in that
  // schedule; other checked rows (not yet scheduled) stay available.
  function removeSelectedByKeys(keys) {
    if (!Array.isArray(keys)) return 0;
    let removed = 0;
    for (const key of keys) {
      if (selected.delete(key)) removed++;
    }
    if (removed) { scheduleSave(); syncBoxes(); updatePanel(); }
    return removed;
  }
  function exportSelected(format) {
    if (!selected.size) { status?.('Select at least one course first.', 'warn'); return; }
    const exporter = globalThis.MCLCourseExporters?.[format];
    if (!exporter) { status?.('The export formatter is unavailable. Reload the extension.', 'error'); return; }
    try {
      // Map retains the order the user checked rows; never alphabetize exports.
      const blob = exporter([...selected.values()]);
      const now = new Date();
      const day = [now.getFullYear(), String(now.getMonth() + 1).padStart(2, '0'), String(now.getDate()).padStart(2, '0')].join('-');
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url; link.download = `Miami_Course_List_Selected_${day}.${format}`; link.style.display = 'none';
      document.body.append(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 30_000);
      status?.(`${selected.size} selected rows exported to ${format.toUpperCase()} in the original field order.`, 'ok');
    } catch (error) { status?.('Export failed: ' + (error?.message || 'unknown error'), 'error'); }
  }
  async function start(config) {
    if (active) return;
    shadow = config.shadow; status = config.status; readTerm = config.readTerm;
    for (const name of ['count','hint','selectAll','clear','xlsx','csv','pdf','details','list','rescan'])
      ui[name] = shadow.getElementById('result' + name[0].toUpperCase() + name.slice(1));
    ui.selectAll.addEventListener('click', pickAllShown);
    ui.clear.addEventListener('click', clearAll);
    ui.xlsx.addEventListener('click', () => exportSelected('xlsx'));
    ui.csv.addEventListener('click', () => exportSelected('csv'));
    ui.pdf.addEventListener('click', () => exportSelected('pdf'));
    ui.rescan.addEventListener('click', () => { scan(); status?.(lastShown ? `${lastShown} result rows available.` : 'No course result rows recognized. Run Find and try again.', lastShown ? 'ok' : 'warn'); });
    await load(); active = true;
    observer = new MutationObserver(records => {
      if (records.some(rec => {
        const target = rec.target.nodeType === 1 ? rec.target : rec.target.parentElement;
        if (!target || target.closest('#mcl-lite-host, [data-mcl-export-pick], [data-mcl-export-column]')) return false;
        if (rec.type === 'attributes') return true; // Includes filtered rows revealed/hidden by CSS.
        if (rec.type === 'characterData') return true;
        return [...rec.addedNodes, ...rec.removedNodes].some(node => node.nodeType === 1 &&
          !(node.matches?.('[data-mcl-export-pick], [data-mcl-export-column]')));
      })) scheduleScan();
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true,
      attributes: true, attributeFilter: ['style','class','hidden','aria-hidden'] });
    scan();
  }
  globalThis.MCLCourseResults = Object.freeze({
    start, rescan: scheduleScan,
    getSelected: () => [...selected.values()].map(row => ({ ...row, columns: (row.columns || []).map(c => ({ ...c })) })),
    removeSelectedByKeys,
    onSelectionChange(callback) {
      if (typeof callback !== 'function') return () => {};
      selectionListeners.add(callback);
      return () => selectionListeners.delete(callback);
    }
  });
})();
