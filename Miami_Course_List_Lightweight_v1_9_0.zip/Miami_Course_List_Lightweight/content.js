/*
 * Miami Course List - Lightweight Presets (v1.8.2)
 * In-page panel; no external services; a modality change runs the site Find search.
 * Runs only at https://(www.)apps.miamioh.edu/courselist/...
 */
(() => {
  'use strict';

  if (window.top !== window.self || document.getElementById('mcl-lite-host')) return;
  const STORAGE_KEY = 'mcl_lite_presets_v1';
  const ALLOWED_PATH = /^\/courselist(?:\/|$)/i;
  if (!/^(?:www\.)?apps\.miamioh\.edu$/i.test(location.hostname) ||
      !ALLOWED_PATH.test(location.pathname)) return;

  const FILTER_WORDS = /\b(term|campus|subject|course\s*(?:number|no\.?|level)|attribute|delivery|modality|face.to.face|hybrid|study|open|waitlist|crn|part\s*of\s*term|level|title|instructor|day|credit|start\s*time|end\s*time|class\s*time|hours)\b/i;
  const SENSITIVE_WORDS = /(password|passcode|passwd|security|secret|token|csrf|authenticat|session|captcha|credential|email|phone|user_?id|student_?id)/i;
  const SEARCH_WIDGET_WORDS = /(search[-_ ]?(?:input|box|field)|select2-search|multiselect-filter|dropdown-search)/i;
  const MAX_PRESETS = 50;
  const BACKUP_FORMAT = 'miami-course-list-lightweight-backup';
  const BACKUP_SCHEMA = 1;
  const MAX_BACKUP_BYTES = 2 * 1024 * 1024;
  const MAX_FIELDS_PER_PRESET = 400;
  const AUTO_RESTORE_DELAY = 950;
  // Miami calls modalities "Alternative Delivery Types". Its site exposes individual checkboxes.
  // Match by the site's visible labels rather than assuming stable IDs or numeric checkbox values.
  const MODALITIES = [
    { key: 'face', label: 'Face-to-Face', aliases: ['face to face', 'face-to-face'] },
    { key: 'online-sync', label: 'Online Synchronous', aliases: ['online synchronous'] },
    { key: 'online-async', label: 'Online Asynchronous', aliases: ['online asynchronous'] },
    { key: 'hybrid-sync', label: 'Hybrid Synchronous', aliases: ['hybrid synchronous'] },
    { key: 'hybrid-async', label: 'Hybrid Asynchronous', aliases: ['hybrid asynchronous'] },
    { key: 'video', label: 'Interactive Video Distance Learning', aliases: ['interactive video distance learning', 'interactive video dist learn'] },
    { key: 'abroad', label: 'Study Abroad', aliases: ['study abroad'] },
    { key: 'away', label: 'Study Away', aliases: ['study away'] }
  ];

  // Program definitions supplied by the user; this is a course SEARCH aid, not a degree audit.
  const PROGRAMS = [
    { id: 'sbm-major', label: 'Small Business Management Major', numbers: ['242', '263', '301', '361', '442', '446'] },
    { id: 'sales-major', label: 'Sales Management Major', numbers: ['261', '263', '301', '362', '363', '461'] },
    { id: 'digital-major', label: 'Digital Commerce Major', numbers: ['242', '286', '341', '449'] },
    { id: 'sales-minor', label: 'Sales Management Minor', numbers: ['105', '261', '263', '362', '363', '461'] },
    { id: 'digital-minor', label: 'Digital Commerce Minor', numbers: ['105', '281', '285', '286', '341', '442'] },
    { id: 'commerce-minor', label: 'Commerce Minor', numbers: ['105', '111', '302'] }
  ];
  const COMMERCE_ELECTIVES = ['101', '108', '207', '211', '244', '282', '495'];
  let selectedProgram = '';
  let digitalFirst = 'both', digitalSecond = 'both', digitalSubject = 'CMR';
  let commerceElectiveMode = 'all';
  let commerceSelectedElectives = new Set();

  let state = { presets: [], selectedId: null, lastAppliedId: null, autoRestore: false, side: 'right', collapsed: false };
  let panel, host, shadow, ui = {};
  let busy = false;
  let editingPresetId = null; // Transient editing session; saved presets retain their original IDs.
  let statusTimer = null;

  const STORAGE = {
    get() {
      return new Promise(resolve => {
        try {
          chrome.storage.local.get(STORAGE_KEY, result => {
            if (chrome.runtime?.lastError) return resolve(null);
            resolve(result?.[STORAGE_KEY] || null);
          });
        } catch { resolve(null); }
      });
    },
    set(value) {
      return new Promise((resolve, reject) => {
        try {
          chrome.storage.local.set({ [STORAGE_KEY]: value }, () => {
            if (chrome.runtime?.lastError) return reject(new Error(chrome.runtime.lastError.message));
            resolve();
          });
        } catch (err) { reject(err); }
      });
    }
  };

  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  const norm = s => String(s ?? '').replace(/\s+/g, ' ').replace(/[\u00a0*]+/g, ' ').trim();
  const keyText = s => norm(s).toLowerCase().replace(/[^a-z0-9]+/g, '');
  const trimLabel = s => norm(s).replace(/\s*:?\s*$/, '').slice(0, 120);
  const id = () => 'p_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 9);
  const byId = x => document.getElementById(x);
  const escapeCSS = v => (globalThis.CSS?.escape ? CSS.escape(String(v)) : String(v).replace(/([^a-zA-Z0-9_-])/g, '\\$1'));

  function storageSafeState() {
    return {
      presets: state.presets.slice(0, MAX_PRESETS),
      selectedId: state.selectedId,
      lastAppliedId: state.lastAppliedId,
      autoRestore: !!state.autoRestore,
      side: state.side === 'left' ? 'left' : 'right',
      collapsed: !!state.collapsed
    };
  }
  async function saveState() { await STORAGE.set(storageSafeState()); }

  // Export plain JSON so the same presets can be imported after reinstalling or
  // moved to another computer. Do not change STORAGE_KEY across extension updates.
  function backupDocument() {
    return {
      format: BACKUP_FORMAT,
      schemaVersion: BACKUP_SCHEMA,
      extensionVersion: '1.8.0',
      exportedAt: new Date().toISOString(),
      settings: storageSafeState()
    };
  }

  function backupString(v, maximum, label, fallback = '') {
    if (v == null) return fallback;
    if (typeof v !== 'string' || v.length > maximum) throw new Error('Invalid ' + label + ' in backup.');
    return v;
  }

  function backupOption(v) {
    if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error('Invalid selected option in backup.');
    return { value: backupString(v.value, 4000, 'option value'), text: backupString(v.text, 4000, 'option text') };
  }

  function backupField(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('Invalid field in backup.');
    if (!['INPUT', 'SELECT', 'TEXTAREA'].includes(raw.tag)) throw new Error('Unknown field type in backup.');
    const type = backupString(raw.type, 30, 'field type');
    if (!/^[a-z][a-z0-9-]{0,29}$/.test(type)) throw new Error('Invalid input type in backup.');
    const name = backupString(raw.name, 250, 'field name');
    const idValue = backupString(raw.id, 250, 'field identifier');
    const label = backupString(raw.label, 250, 'field label');
    if (SENSITIVE_WORDS.test([name, idValue, label].join(' '))) throw new Error('The backup includes a field that must not be saved.');
    let value;
    if (type === 'checkbox' || type === 'radio') {
      if (typeof raw.value !== 'boolean') throw new Error('Invalid checkbox value in backup.');
      value = raw.value;
    } else if (raw.tag === 'SELECT') {
      if (Array.isArray(raw.value)) {
        if (raw.value.length > 300) throw new Error('Too many selected options in backup.');
        value = raw.value.map(backupOption);
      } else value = backupOption(raw.value);
    } else {
      value = backupString(raw.value, 10000, 'field value');
    }
    if (!Number.isInteger(raw.ordinal) || raw.ordinal < 0 || raw.ordinal > 1000) throw new Error('Invalid field position in backup.');
    return {
      key: backupString(raw.key, 700, 'field key'), tag: raw.tag, type, name, id: idValue,
      label, ordinal: raw.ordinal, path: backupString(raw.path, 1600, 'field path'),
      optionValue: backupString(raw.optionValue, 4000, 'checkbox option'), value
    };
  }

  function parseBackup(source) {
    let data;
    try { data = JSON.parse(source); } catch { throw new Error('This is not a valid JSON backup file.'); }
    if (!data || typeof data !== 'object' || data.format !== BACKUP_FORMAT) {
      throw new Error('This is not a Miami Course List Lightweight backup.');
    }
    if (data.schemaVersion !== BACKUP_SCHEMA) {
      throw new Error('Unsupported backup format version. Update the extension before importing.');
    }
    const raw = data.settings;
    if (!raw || typeof raw !== 'object' || !Array.isArray(raw.presets)) throw new Error('Backup is missing saved presets.');
    if (raw.presets.length > MAX_PRESETS) throw new Error('Backup has more than 50 presets.');
    const presetIds = new Set();
    const presetNames = new Set();
    const presets = raw.presets.map(item => {
      if (!item || typeof item !== 'object') throw new Error('A saved preset is invalid.');
      const presetId = backupString(item.id, 100, 'preset ID');
      const name = backupString(item.name, 65, 'preset name');
      if (!presetId || !norm(name) || presetIds.has(presetId) || presetNames.has(norm(name).toLowerCase())) {
        throw new Error('Backup contains a missing or duplicate preset ID or name.');
      }
      presetIds.add(presetId);
      presetNames.add(norm(name).toLowerCase());
      if (!Array.isArray(item.fields) || !item.fields.length || item.fields.length > MAX_FIELDS_PER_PRESET) {
        throw new Error('A preset has an invalid number of fields.');
      }
      return {
        id: presetId, name: norm(name), fields: item.fields.map(backupField),
        savedAt: backupString(item.savedAt, 40, 'save date')
      };
    });
    const selectedId = presetIds.has(raw.selectedId) ? raw.selectedId : null;
    const lastAppliedId = presetIds.has(raw.lastAppliedId) ? raw.lastAppliedId : null;
    return {
      presets, selectedId, lastAppliedId,
      autoRestore: raw.autoRestore === true, side: raw.side === 'left' ? 'left' : 'right',
      collapsed: raw.collapsed === true
    };
  }

  function mergeBackup(current, imported) {
    const next = { ...current, presets: current.presets.map(p => ({ ...p })) };
    let added = 0, skipped = 0, renamed = 0;
    const usedIds = new Set(next.presets.map(p => p.id));
    const usedNames = new Set(next.presets.map(p => p.name.toLowerCase()));
    for (const preset of imported.presets) {
      const signature = JSON.stringify(preset.fields);
      const sameContent = p => JSON.stringify(p.fields) === signature;
      const nameMatches = p => {
        if (p.name.toLowerCase() === preset.name.toLowerCase()) return true;
        const suffix = p.name.match(/ \(imported(?: [0-9]+)?\)$/i)?.[0];
        if (!suffix) return false;
        const truncated = preset.name.slice(0, 65 - suffix.length).trimEnd();
        return p.name.slice(0, -suffix.length).toLowerCase() === truncated.toLowerCase();
      };
      if (next.presets.some(p => nameMatches(p) && sameContent(p))) { skipped++; continue; }
      if (next.presets.length >= MAX_PRESETS) throw new Error('Import would exceed 50 presets. Delete some presets or choose Restore everything.');
      let name = preset.name;
      if (usedNames.has(name.toLowerCase())) {
        renamed++;
        let number = 1;
        do {
          const suffix = number === 1 ? ' (imported)' : ' (imported ' + number + ')';
          name = preset.name.slice(0, 65 - suffix.length).trimEnd() + suffix;
          number++;
        } while (usedNames.has(name.toLowerCase()));
      }
      let presetId = preset.id;
      while (usedIds.has(presetId)) presetId = id();
      usedNames.add(name.toLowerCase());
      usedIds.add(presetId);
      next.presets.push({ ...preset, id: presetId, name });
      added++;
    }
    next.presets.sort((a, b) => a.name.localeCompare(b.name));
    return { next, added, skipped, renamed };
  }

  function exportBackup() {
    if (busy) return;
    try {
      const contents = JSON.stringify(backupDocument(), null, 2) + '\n';
      const blob = new Blob([contents], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'Miami_Course_List_Backup_' + new Date().toISOString().slice(0, 10) + '.json';
      document.body.append(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      setStatus('Backup downloaded: ' + state.presets.length + ' presets and panel settings. Keep the JSON file to restore later or import on another computer.', 'ok');
    } catch (err) { setStatus('Could not export backup: ' + (err?.message || 'unknown error'), 'error'); }
  }

  async function importBackup(file) {
    if (!file || busy) return;
    if (file.size > MAX_BACKUP_BYTES) { setStatus('Backup is too large (maximum 2 MB). Nothing was changed.', 'error'); return; }
    busy = true;
    render();
    try {
      const imported = parseBackup(await file.text());
      const mode = ui.importMode.value;
      let next, message;
      if (mode === 'replace') {
        if (state.presets.length && !window.confirm(
          'Restore this backup? This will REPLACE all ' + state.presets.length +
          ' existing presets and panel settings with the ' + imported.presets.length + ' presets in the file.'
        )) { setStatus('Import canceled; nothing was changed.', 'info'); return; }
        next = imported;
        message = 'Restored ' + next.presets.length + ' presets and panel settings from backup.';
      } else {
        const result = mergeBackup(state, imported);
        next = result.next;
        message = 'Added ' + result.added + ' presets; skipped ' + result.skipped +
          ' already present' + (result.renamed ? '; renamed ' + result.renamed + ' conflicts' : '') + '. Current panel settings were kept.';
      }
      // Save before swapping memory state; an invalid file or failed storage write
      // must not destroy existing presets.
      await STORAGE.set(next);
      state = next;
      editingPresetId = null;
      ui.name.value = '';
      placeHost();
      setStatus(message, 'ok');
    } catch (err) {
      setStatus('Import failed: ' + (err?.message || 'unknown error') + ' Nothing was changed.', 'error');
    } finally {
      busy = false;
      render();
      syncModalityFromPage();
    }
  }
  function setStatus(message, kind = 'info') {
    if (!ui.status) return;
    if (statusTimer) clearTimeout(statusTimer);
    ui.status.textContent = message;
    ui.status.dataset.kind = kind;
    statusTimer = null;
  }

  function looksSearchWidgetInput(el) {
    const attrs = [el.name, el.id, el.className, el.getAttribute('placeholder')].join(' ');
    if (SEARCH_WIDGET_WORDS.test(attrs)) return true;
    if (!el.id && !el.name && (el.type === 'search' || /^search\b/i.test(el.placeholder || '')) &&
        el.closest('[role="listbox"], [class*="dropdown"], [class*="select2"], [class*="multiselect"]')) return true;
    return false;
  }

  function getFieldRoot() {
    // Prefer the actual course search form, not a login or navigation form.
    const forms = [...document.querySelectorAll('form')];
    const score = el => {
      const text = norm(el.innerText || el.textContent || '');
      return (/\bTerm\b/i.test(text) ? 2 : 0) +
        (/\bCampus\b/i.test(text) ? 3 : 0) +
        (/\bSubject\b/i.test(text) ? 2 : 0) +
        (/Course Number/i.test(text) ? 2 : 0) +
        (/Advanced Search/i.test(text) ? 1 : 0);
    };
    forms.sort((a, b) => score(b) - score(a));
    if (forms.length && score(forms[0]) >= 4) return { root: forms[0], confident: true };
    const candidates = [...document.querySelectorAll('main, [role="main"], #main, #app, #root, .container')];
    candidates.sort((a, b) => score(b) - score(a));
    if (candidates.length && score(candidates[0]) >= 4) return { root: candidates[0], confident: true };
    return { root: document.body, confident: false };
  }

  function fieldLabel(el) {
    const fromLabels = [...(el.labels || [])].map(l => trimLabel(l.textContent)).filter(Boolean);
    if (fromLabels.length) return fromLabels[0];
    const aria = el.getAttribute('aria-label');
    if (aria) return trimLabel(aria);
    const labelled = el.getAttribute('aria-labelledby');
    if (labelled) {
      const text = labelled.split(/\s+/).map(part => byId(part)?.textContent || '').join(' ');
      if (norm(text)) return trimLabel(text);
    }
    const wrapped = el.closest('label');
    if (wrapped) return trimLabel(wrapped.textContent);
    const grouping = el.closest('fieldset, .form-group, .form-field, .filter-group, .control-group, [class*="filter-row"], [class*="form-field"]');
    if (grouping) {
      const l = grouping.querySelector('legend, label, [class*="label"]');
      if (l) return trimLabel(l.textContent);
    }
    const parent = el.parentElement;
    if (parent) {
      const l = parent.querySelector(':scope > label, :scope > legend, :scope > strong');
      if (l) return trimLabel(l.textContent);
      const sibling = el.previousElementSibling;
      if (sibling && /^(LABEL|LEGEND|STRONG|SPAN)$/.test(sibling.tagName)) return trimLabel(sibling.textContent);
    }
    return trimLabel(el.getAttribute('placeholder') || el.getAttribute('name') || el.id || '');
  }

  function isRelevant(el, rootInfo) {
    if (!el.isConnected || host?.contains(el)) return false;
    if (el.closest('header, nav, footer, [role="navigation"], [role="banner"], [role="contentinfo"]')) return false;
    if (el.closest('[data-mcl-ignore], #mcl-lite-host')) return false;
    if (!rootInfo.root.contains(el)) return false;
    const type = (el.type || '').toLowerCase();
    if (['hidden', 'password', 'email', 'file', 'submit', 'reset', 'button', 'image', 'color'].includes(type)) return false;
    if (!['INPUT', 'SELECT', 'TEXTAREA'].includes(el.tagName)) return false;
    if (SENSITIVE_WORDS.test([el.name, el.id, el.autocomplete].join(' '))) return false;
    if (looksSearchWidgetInput(el)) return false;
    if (type === 'checkbox' && /^(select all|check all|unselect all)$/i.test(fieldLabel(el))) return false;
    if (el.closest('.select2-dropdown, .ng-dropdown-panel, [role="listbox"]') && el.tagName !== 'SELECT' &&
        !el.name && !el.id) return false;
    // If the search is built without a <form>, limit collection to course filter controls.
    if (!rootInfo.confident) {
      const context = [fieldLabel(el), el.name, el.id, el.placeholder, el.closest('fieldset, .form-group')?.textContent?.slice(0, 110)].join(' ');
      return FILTER_WORDS.test(context);
    }
    return true;
  }

  function domPath(el, root) {
    const pieces = [];
    for (let node = el; node && node !== root && node !== document.body; node = node.parentElement) {
      let token = node.tagName.toLowerCase();
      if (node.id && !/^\d/.test(node.id) && !/^(?:react-select|ng-)/i.test(node.id)) {
        token += '#' + escapeCSS(node.id);
        pieces.unshift(token);
        break;
      }
      const parent = node.parentElement;
      if (parent) {
        const peers = [...parent.children].filter(n => n.tagName === node.tagName);
        if (peers.length > 1) token += ':nth-of-type(' + (peers.indexOf(node) + 1) + ')';
      }
      pieces.unshift(token);
      if (pieces.length > 12) break;
    }
    return pieces.join(' > ');
  }

  function fieldDescriptor(el, root, groupIndex) {
    const type = el.tagName === 'SELECT' ? 'select' : el.tagName === 'TEXTAREA' ? 'textarea' : (el.type || 'text').toLowerCase();
    const label = fieldLabel(el);
    const name = el.getAttribute('name') || '';
    const identifier = el.id || '';
    const key = [el.tagName.toLowerCase(), type, name || identifier || keyText(label), groupIndex].join('|');
    return { key, tag: el.tagName, type, name, id: identifier, label, ordinal: groupIndex, path: domPath(el, root) };
  }

  function nativeFieldSnapshot() {
    const rootInfo = getFieldRoot();
    const els = [...rootInfo.root.querySelectorAll('input, select, textarea')].filter(el => isRelevant(el, rootInfo));
    const seen = new Map();
    const fields = els.map(el => {
      const type = el.tagName === 'SELECT' ? 'select' : el.tagName === 'TEXTAREA' ? 'textarea' : (el.type || 'text').toLowerCase();
      const marker = [el.tagName, type, el.name || el.id || keyText(fieldLabel(el))].join('|');
      const ordinal = seen.get(marker) || 0;
      seen.set(marker, ordinal + 1);
      const d = fieldDescriptor(el, rootInfo.root, ordinal);
      let value;
      if (type === 'checkbox' || type === 'radio') value = !!el.checked;
      else if (el.tagName === 'SELECT' && el.multiple) value = [...el.selectedOptions].map(o => ({ value: o.value, text: norm(o.textContent) }));
      else if (el.tagName === 'SELECT') {
        const selected = el.options[el.selectedIndex];
        value = { value: el.value, text: norm(selected?.textContent || '') };
      } else value = el.value;
      // Checkboxes may have the same name (e.g. Subject), so remember option value.
      d.optionValue = type === 'checkbox' || type === 'radio' ? el.value : '';
      return { ...d, value };
    });
    return fields;
  }

  function findField(saved, rootInfo) {
    const all = [...rootInfo.root.querySelectorAll('input, select, textarea')].filter(el => isRelevant(el, rootInfo));
    const sameType = el => el.tagName === saved.tag &&
      (saved.tag === 'SELECT' || saved.tag === 'TEXTAREA' || (el.type || 'text').toLowerCase() === saved.type);
    // Names are usually stable even when the course page rerenders.
    const byName = saved.name ? all.filter(el => sameType(el) && el.name === saved.name) : [];
    const matches = list => {
      if (saved.type === 'checkbox' || saved.type === 'radio') {
        const byValue = list.filter(el => el.value === saved.optionValue);
        if (byValue.length === 1) return byValue[0];
        if (byValue.length > 1) return byValue[saved.ordinal] || byValue[0];
      }
      return list[saved.ordinal] || list[0] || null;
    };
    if (byName.length) return matches(byName);
    if (saved.id) {
      const byElementId = byId(saved.id);
      if (byElementId && rootInfo.root.contains(byElementId) && sameType(byElementId)) return byElementId;
    }
    if (saved.label) {
      const group = all.filter(el => sameType(el) && keyText(fieldLabel(el)) === keyText(saved.label));
      if (group.length) return matches(group);
    }
    if (saved.path) {
      try {
        const candidate = rootInfo.root.querySelector(saved.path);
        if (candidate && sameType(candidate) && isRelevant(candidate, rootInfo)) return candidate;
      } catch { /* site structure changed */ }
    }
    return null;
  }

  function setInputValue(el, value) {
    const target = String(value ?? '');
    if (el.value === target) return false;
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, target);
    else el.value = target;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }
  function announceChanges(el) {
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function chooseOption(select, saved) {
    const options = [...select.options];
    return options.find(o => o.value === saved.value) ||
      options.find(o => norm(o.textContent).toLowerCase() === norm(saved.text).toLowerCase());
  }

  function setNative(saved) {
    const rootInfo = getFieldRoot();
    const el = findField(saved, rootInfo);
    if (!el) return 'missing';
    if (el.disabled) return 'disabled';
    const type = saved.type;
    if (type === 'checkbox' || type === 'radio') {
      const want = !!saved.value;
      if (el.checked !== want) {
        el.checked = want;
        announceChanges(el);
      }
      return 'ok';
    }
    if (saved.tag === 'SELECT') {
      if (el.multiple) {
        const wanted = Array.isArray(saved.value) ? saved.value : [];
        const targets = wanted.map(opt => chooseOption(el, opt));
        if (targets.some(o => !o)) return 'options-not-ready';
        const values = new Set(targets.map(o => o.value));
        let changed = false;
        for (const option of el.options) {
          const selected = values.has(option.value);
          if (option.selected !== selected) { option.selected = selected; changed = true; }
        }
        if (changed) announceChanges(el);
        return 'ok';
      }
      const target = chooseOption(el, saved.value || { value: '', text: '' });
      if (!target) return 'options-not-ready';
      if (el.value !== target.value) { el.value = target.value; announceChanges(el); }
      return 'ok';
    }
    setInputValue(el, saved.value);
    return 'ok';
  }

  function orderFields(fields) {
    const weight = f => {
      const name = [f.name, f.id, f.label].join(' ');
      if (/\bterm\b/i.test(name)) return 0;
      if (/\bcampus\b/i.test(name)) return 1;
      if (/\bsubject\b/i.test(name)) return 2;
      return 3;
    };
    return [...fields].sort((a, b) => weight(a) - weight(b));
  }

  async function restoreNativeFields(fields) {
    const missing = new Set();
    let completed = 0;
    const ordered = orderFields(fields);
    const termFields = ordered.filter(f => /\bterm\b/i.test([f.name, f.id, f.label].join(' ')));
    // Site may load options for other filters after term changes.
    for (const field of termFields) setNative(field);
    if (termFields.length) await wait(260);
    let pending = ordered;
    for (let pass = 0; pass < 12 && pending.length; pass++) {
      if (pass) await wait(pass < 4 ? 175 : 340);
      const next = [];
      for (const field of pending) {
        const result = setNative(field);
        if (result === 'ok') completed++;
        else next.push(field);
      }
      pending = next;
    }
    pending.forEach(f => missing.add(trimLabel(f.label || f.name || f.id || f.type)));
    return { completed, total: fields.length, missing: [...missing].filter(Boolean) };
  }

  // ----- Program course groups -----
  // Course List supports comma-delimited numbers but applies the same numbers
  // to EVERY selected subject. The Digital Commerce substitutions are therefore
  // intentionally split into separate CMR and IMS searches (no cross-product).
  function programPlan() {
    const definition = PROGRAMS.find(item => item.id === selectedProgram);
    if (!definition) return null;
    if (selectedProgram === 'digital-major') {
      const cmr = [...definition.numbers];
      const ims = [];
      for (const [choice, cmrNumber, imsNumber] of [[digitalFirst, '281', '392'], [digitalSecond, '285', '414']]) {
        if (choice === 'both' || choice === 'cmr') cmr.push(cmrNumber);
        if (choice === 'both' || choice === 'ims') ims.push(imsNumber);
      }
      if (!ims.length) digitalSubject = 'CMR';
      return { definition, bySubject: { CMR: cmr, IMS: ims }, group: digitalSubject };
    }
    if (selectedProgram === 'commerce-minor') {
      const chosen = commerceElectiveMode === 'three' && commerceSelectedElectives.size === 3
        ? COMMERCE_ELECTIVES.filter(number => commerceSelectedElectives.has(number))
        : COMMERCE_ELECTIVES;
      return { definition, bySubject: { CMR: [...definition.numbers, ...chosen] }, group: 'CMR',
        needsThree: commerceElectiveMode === 'three' && commerceSelectedElectives.size !== 3 };
    }
    return { definition, bySubject: { CMR: [...definition.numbers] }, group: 'CMR' };
  }

  function renderProgram() {
    if (!ui.program) return;
    ui.program.value = selectedProgram;
    const activeProgram = PROGRAMS.find(p => p.id === selectedProgram)?.label || '';
    if (ui.programHeader) { ui.programHeader.textContent = activeProgram; ui.programHeader.title = activeProgram; }
    const plan = programPlan();
    ui.programDetails.hidden = !plan;
    ui.digitalArea.hidden = selectedProgram !== 'digital-major';
    ui.commerceArea.hidden = selectedProgram !== 'commerce-minor';
    if (!plan) return;
    ui.digitalFirst.value = digitalFirst;
    ui.digitalSecond.value = digitalSecond;
    ui.digitalSubject.value = digitalSubject;
    ui.digitalSubject.querySelector('option[value="IMS"]').disabled = !plan.bySubject.IMS?.length;
    ui.commerceMode.value = commerceElectiveMode;
    ui.commerceChoices.hidden = commerceElectiveMode !== 'three';
    for (const box of ui.commerceChoices.querySelectorAll('input[type="checkbox"]')) {
      box.checked = commerceSelectedElectives.has(box.value);
      box.disabled = busy || (!box.checked && commerceSelectedElectives.size >= 3);
    }
    ui.commerceCount.textContent = commerceElectiveMode === 'three'
      ? `${commerceSelectedElectives.size} of 3 chosen. ${commerceSelectedElectives.size === 3 ? 'Searching only those three electives.' : 'Until three are selected, the search includes all eligible electives.'}`
      : 'The degree requires a choice of three electives; all seven are shown for comparison.';
    const subject = plan.group;
    const numbers = plan.bySubject[subject];
    ui.programSummary.textContent = `${subject} ${numbers.join(', ')}. Term and Campus are left unchanged.`;
    ui.programInfo.textContent = selectedProgram === 'digital-major'
      ? (plan.bySubject.IMS.length
          ? 'CMR and IMS must be searched separately to avoid unrelated subject/number matches. Use Search subject to switch between the two.'
          : 'Only CMR alternatives are selected; no IMS search is needed.')
      : selectedProgram === 'commerce-minor'
        ? 'CMR 105, 111, and 302 are required. Select three from the seven eligible electives, or view them all while planning.'
        : 'Selecting this program applies these course numbers to Subject CMR and runs Find.';
  }

  function clearProgramPicker() {
    selectedProgram = '';
    renderProgram();
  }

  // ----- Reliable page filter mapping -----
  // Search conservatively. If the site's native/custom subject filter cannot be
  // identified AND verified, do not run Find using possibly wrong subjects.
  function codeFromText(text) {
    const m = norm(text).replace(/^[✓✔☑•\s]+/, '').match(/^([A-Za-z]{2,4})(?:\s*[-:–—]\s*|\s*$)/);
    return m ? m[1].toUpperCase() : null;
  }
  function selectOptionCode(option) {
    return codeFromText(option.value) || codeFromText(option.textContent);
  }
  function labeledAsSubject(el) {
    const meta = [el.id, el.name, el.getAttribute('formcontrolname'), el.getAttribute('aria-label'), fieldLabel(el)].join(' ');
    return /subject/i.test(meta);
  }
  function findSubjectSelect() {
    const root = getFieldRoot().root;
    const candidates = [...root.querySelectorAll('select')]
      .filter(el => !host?.contains(el) && !el.disabled)
      .map(el => ({ el, codes: new Set([...el.options].map(selectOptionCode).filter(Boolean)), label: labeledAsSubject(el) }))
      .filter(x => x.codes.has('CMR') || x.codes.has('IMS'))
      .sort((a, b) => (Number(b.label) * 10 + b.codes.size) - (Number(a.label) * 10 + a.codes.size));
    const winner = candidates[0];
    // A field labeled Subject is the most reliable mapping. In an unlabeled
    // mock or select2 widget, require BOTH CMR and IMS unique options.
    if (!winner || (!winner.label && winner.codes.size !== 2)) return null;
    if (candidates[1] && Number(candidates[1].label) * 10 + candidates[1].codes.size ===
        Number(winner.label) * 10 + winner.codes.size) return null;
    return winner.el;
  }
  function findNumberInput() {
    const rootInfo = getFieldRoot();
    const ranked = [...rootInfo.root.querySelectorAll('input, textarea')]
      .filter(el => isRelevant(el, rootInfo) && !el.disabled && /^(text|search|number|textarea)$/i.test(el.type || 'text'))
      .map(el => {
        const label = keyText(fieldLabel(el));
        const name = keyText([el.name, el.id, el.getAttribute('formcontrolname')].join(' '));
        const placeholder = keyText(el.getAttribute('placeholder') || '');
        let score = 0;
        if (label === 'coursenumber' || label === 'courseno') score += 10;
        if (/coursenumber|courseno/.test(name)) score += 9;
        if (/coursenumber|courseno/.test(placeholder)) score += 3;
        return { el, score };
      })
      .filter(x => x.score >= 3)
      .sort((a, b) => b.score - a.score);
    if (!ranked.length || (ranked[1] && ranked[1].score === ranked[0].score)) return null;
    return ranked[0].el;
  }
  function subjectNativeCodes(select) {
    return [...select.selectedOptions].map(selectOptionCode).filter(Boolean).sort();
  }
  function compareCodes(a, b) {
    return [...a].sort().join('|') === [...b].sort().join('|');
  }
  function setNativeSubjects(select, requested) {
    const existing = new Set([...select.options].map(selectOptionCode).filter(Boolean));
    if (requested.some(code => !existing.has(code))) throw new Error('Required subject option is not available.');
    if (!select.multiple && requested.length !== 1) throw new Error('This Subject control does not support multiple subjects.');
    const wanted = new Set(requested);
    let changed = false;
    for (const option of select.options) {
      const code = selectOptionCode(option);
      const next = wanted.has(code);
      if (option.selected !== next) { option.selected = next; changed = true; }
    }
    if (changed) announceChanges(select);
  }

  function subjectWidgets() {
    const root = getFieldRoot().root;
    const candidates = [...root.querySelectorAll('ng-multiselect-dropdown, .multiselect-dropdown, [class*="multiselect-dropdown"]')]
      .filter(el => !host?.contains(el));
    return candidates.map(widget => {
      let score = 0;
      const attrs = [widget.id, widget.getAttribute('formcontrolname'), widget.getAttribute('aria-label'), widget.getAttribute('name')].join(' ');
      if (/subject/i.test(attrs)) score += 20;
      for (let parent = widget.parentElement, depth = 0; parent && depth < 5; parent = parent.parentElement, depth++) {
        const immediateLabels = [...parent.querySelectorAll('label, legend')].filter(label =>
          keyText(label.textContent) === 'subject');
        if (immediateLabels.length) { score += 12 - depth; break; }
        if (parent === root) break;
      }
      const options = widget.querySelectorAll('li, [role="option"]');
      if ([...options].some(el => codeFromText(el.textContent) === 'CMR')) score += 2;
      return { widget, score };
    }).filter(x => x.score > 0).sort((a, b) => b.score - a.score);
  }
  function findCustomSubjectWidget() {
    const choices = subjectWidgets();
    if (choices.length) {
      if (choices[1] && choices[0].score === choices[1].score) return null;
      return choices[0].widget;
    }
    // Some versions of Course List or accessibility-oriented layouts expose
    // ordinary checkboxes inside a clearly named Subject fieldset instead.
    const root = getFieldRoot().root;
    const fieldsets = [...root.querySelectorAll('fieldset')].filter(fieldset =>
      [...fieldset.querySelectorAll('legend')].some(label => keyText(label.textContent) === 'subject') &&
      [...fieldset.querySelectorAll('label')].some(label => codeFromText(label.textContent) === 'CMR' &&
        label.querySelector('input[type="checkbox"]')));
    return fieldsets.length === 1 ? fieldsets[0] : null;
  }
  function subjectChoiceItems(widget) {
    let items = [...widget.querySelectorAll('ul.item2 > li, li.multiselect-item-checkbox, [role="option"]')];
    if (!items.length) items = [...widget.querySelectorAll('li')];
    if (!items.length) items = [...widget.querySelectorAll('label')].filter(label =>
      !!label.querySelector('input[type="checkbox"]'));
    // Ignore auxiliary UI entries such as Select all and search inputs.
    const found = new Map();
    for (const el of items) {
      const code = codeFromText(el.textContent || el.getAttribute('aria-label'));
      if (!code || found.has(code)) continue;
      found.set(code, el);
    }
    return found;
  }
  function checkedCustomOption(item) {
    const checkbox = item.querySelector('input[type="checkbox"]');
    if (checkbox) return !!checkbox.checked;
    return item.getAttribute('aria-selected') === 'true' ||
      item.getAttribute('aria-checked') === 'true' ||
      item.classList.contains('selected') || item.classList.contains('active');
  }
  function customSelectedCodes(widget) {
    return [...subjectChoiceItems(widget)].filter(([, item]) => checkedCustomOption(item)).map(([code]) => code).sort();
  }
  async function setCustomSubjects(widget, requested) {
    const trigger = widget.querySelector('.dropdown-btn, [role="combobox"], button[aria-expanded], button');
    const list = widget.querySelector('.dropdown-list, .multiselect-container, [role="listbox"]');
    const wasOpen = trigger?.getAttribute('aria-expanded') === 'true' ||
      (list && getComputedStyle(list).display !== 'none' && getComputedStyle(list).visibility !== 'hidden');
    if (trigger && !wasOpen) { trigger.click(); await wait(80); }
    try {
      const current = subjectChoiceItems(widget);
      if (requested.some(code => !current.has(code))) throw new Error('Course List Subject choices were not found.');
      // Remove any already-selected subject codes first, then add requested ones.
      // Rebuild the map after each click because Angular can rerender the list.
      const present = [...current].filter(([, item]) => checkedCustomOption(item)).map(([code]) => code);
      for (const code of [...present.filter(code => !requested.includes(code)), ...requested.filter(code => !present.includes(code))]) {
        const latest = subjectChoiceItems(widget).get(code);
        if (!latest) throw new Error('Subject choice disappeared while updating.');
        const desired = requested.includes(code);
        if (checkedCustomOption(latest) !== desired) {
          latest.click();
          await wait(65);
        }
      }
      if (!compareCodes(customSelectedCodes(widget), requested))
        throw new Error('The site did not confirm the selected subject.');
    } finally {
      if (trigger?.isConnected && !wasOpen &&
          (trigger.getAttribute('aria-expanded') === 'true' ||
           (list && getComputedStyle(list).display !== 'none'))) trigger.click();
    }
  }
  function subjectControl() {
    const select = findSubjectSelect();
    if (select) return { type: 'native', el: select };
    const widget = findCustomSubjectWidget();
    if (widget) return { type: 'custom', el: widget };
    return null;
  }
  function currentSubjects(control) {
    if (!control) return [];
    return control.type === 'native' ? subjectNativeCodes(control.el) : customSelectedCodes(control.el);
  }
  async function updateSubjects(requested) {
    const control = subjectControl();
    if (!control) throw new Error('Could not identify the Subject filter. Nothing was searched.');
    if (control.type === 'native') setNativeSubjects(control.el, requested);
    else await setCustomSubjects(control.el, requested);
    await wait(75);
    const check = subjectControl();
    if (!check || !compareCodes(currentSubjects(check), requested))
      throw new Error('Could not verify the new Subject selection.');
  }
  function termCampusSnapshot() {
    const snapshot = nativeFieldSnapshot();
    return snapshot.filter(f => {
      const label = keyText(f.label), name = keyText(f.name), id = keyText(f.id);
      return label === 'term' || label === 'campus' ||
        (/^(?:term|campus|campuses|termcode|campuscode|searchterm|searchcampus)$/.test(name) && !/partofterm/.test(name)) ||
        (/^(?:term|campus|campuses|termcode|campuscode)$/.test(id));
    });
  }
  function sameProtectedFields(before, after) {
    if (before.length !== after.length) return false;
    return before.every((field, i) => field.key === after[i].key &&
      JSON.stringify(field.value) === JSON.stringify(after[i].value));
  }

  async function applyProgramAndFind() {
    if (busy) return;
    const plan = programPlan();
    if (!plan) return;
    const subject = plan.group;
    const numbers = plan.bySubject[subject];
    if (!numbers?.length) { setStatus('There are no courses selected for this subject.', 'warn'); return; }
    const number = findNumberInput(), subjectBefore = subjectControl();
    if (!number || !subjectBefore) {
      setStatus('Could not locate both Subject and Course Number filters on Course List. No search was run.', 'error');
      return;
    }
    const originalNumber = number.value;
    const originalSubjects = currentSubjects(subjectBefore);
    const protectedBefore = termCampusSnapshot();
    busy = true;
    render();
    setStatus(`Applying ${plan.definition.label}: ${subject} ${numbers.join(', ')}...`, 'info');
    let updated = false;
    try {
      await updateSubjects([subject]);
      const latestNumber = findNumberInput();
      if (!latestNumber) throw new Error('Course Number field disappeared.');
      setInputValue(latestNumber, numbers.join(','));
      await wait(110);
      if (!compareCodes(currentSubjects(subjectControl()), [subject]) ||
          findNumberInput()?.value.replace(/\s/g, '') !== numbers.join(','))
        throw new Error('The site did not retain the requested filters.');
      updated = true;
      // Site interactions should not change Term/Campus. If the page does,
      // restore the original values rather than searching a different term.
      let protectedAfter = termCampusSnapshot();
      if (!sameProtectedFields(protectedBefore, protectedAfter)) {
        for (const field of protectedBefore) setNative(field);
        await wait(120);
        protectedAfter = termCampusSnapshot();
        if (!sameProtectedFields(protectedBefore, protectedAfter))
          throw new Error('Term or Campus changed unexpectedly; could not restore it safely.');
      }
      const found = runFind('program');
      if (!found) return;
      if (selectedProgram === 'digital-major') {
        setStatus(`${plan.definition.label}: ${subject} courses applied and Find triggered. ${plan.bySubject.IMS.length ? 'Use Search subject to check the IMS alternatives separately.' : 'All selected alternatives are CMR courses.'}`, 'ok');
      } else if (plan.needsThree) {
        setStatus('Find triggered with all seven Commerce electives. Choose exactly three below to narrow the search.', 'ok');
      } else {
        setStatus(`${plan.definition.label}: ${numbers.length} ${subject} courses applied; Find triggered. Term and Campus were preserved.`, 'ok');
      }
    } catch (error) {
      try {
        if (updated || !compareCodes(currentSubjects(subjectControl()), originalSubjects))
          await updateSubjects(originalSubjects);
        const numberToRestore = findNumberInput();
        if (numberToRestore && numberToRestore.value !== originalNumber) setInputValue(numberToRestore, originalNumber);
      } catch { /* best effort rollback; never trigger Find on an uncertain state */ }
      setStatus('Program filters could not be safely applied: ' + (error?.message || 'unknown error') + ' No search was run; please check Subject and Course Number on the page.', 'error');
    } finally { busy = false; render(); syncModalityFromPage(); }
  }

  async function programChanged() {
    if (busy) return;
    selectedProgram = ui.program.value;
    digitalFirst = 'both'; digitalSecond = 'both'; digitalSubject = 'CMR';
    commerceElectiveMode = 'all'; commerceSelectedElectives.clear();
    renderProgram();
    if (!selectedProgram) { setStatus('Program dropdown cleared. Course List filters were left unchanged.', 'info'); return; }
    await applyProgramAndFind();
  }
  async function digitalChanged() {
    if (busy || selectedProgram !== 'digital-major') return;
    digitalFirst = ui.digitalFirst.value;
    digitalSecond = ui.digitalSecond.value;
    digitalSubject = ui.digitalSubject.value;
    renderProgram();
    await applyProgramAndFind();
  }
  async function commerceModeChanged() {
    if (busy || selectedProgram !== 'commerce-minor') return;
    commerceElectiveMode = ui.commerceMode.value;
    renderProgram();
    await applyProgramAndFind();
  }
  async function commerceElectiveChanged(e) {
    if (busy || selectedProgram !== 'commerce-minor') return;
    const checkbox = e.target;
    if (!checkbox.matches('input[type="checkbox"]')) return;
    if (checkbox.checked && commerceSelectedElectives.size >= 3) {
      checkbox.checked = false;
      setStatus('Only three electives can be selected.', 'warn');
      return;
    }
    if (checkbox.checked) commerceSelectedElectives.add(checkbox.value);
    else commerceSelectedElectives.delete(checkbox.value);
    renderProgram();
    await applyProgramAndFind();
  }

  function modalityKeyForCheckbox(el) {
    const candidates = [
      ...[...(el.labels || [])].map(l => l.textContent),
      el.getAttribute('aria-label'),
      (el.getAttribute('aria-labelledby') || '').split(/\s+/).map(id => byId(id)?.textContent || '').join(' '),
      el.closest('label')?.textContent,
      el.nextElementSibling?.matches('label, span, strong') ? el.nextElementSibling.textContent : '',
      el.previousElementSibling?.matches('label, span, strong') ? el.previousElementSibling.textContent : '',
      el.parentElement?.matches('label, .form-check, .checkbox, .checkbox-item') ? el.parentElement.textContent : ''
    ].filter(Boolean);
    for (const value of candidates) {
      const readable = keyText(value);
      const match = MODALITIES.find(item => item.aliases.some(alias => {
        const key = keyText(alias);
        // A label may include a short explanation following the modality name.
        return readable === key || (readable.startsWith(key) && readable.length < key.length + 90);
      }));
      if (match) return match.key;
    }
    // Fallback for inputs whose labels are only attached through CSS; do not
    // identify from a giant parent container that lists every delivery type.
    const attr = keyText([el.name, el.id].join(' '));
    return MODALITIES.find(item => item.aliases.some(alias => attr.includes(keyText(alias))))?.key || null;
  }

  function modalityCheckboxes() {
    const rootInfo = getFieldRoot();
    const found = new Map();
    const duplicates = new Set();
    for (const input of rootInfo.root.querySelectorAll('input[type="checkbox"]')) {
      if (!isRelevant(input, rootInfo) || input.disabled) continue;
      const key = modalityKeyForCheckbox(input);
      if (!key) continue;
      if (found.has(key)) duplicates.add(key);
      else found.set(key, input);
    }
    for (const key of duplicates) found.delete(key);
    return found;
  }

  function syncModalityFromPage() {
    if (!ui.modality || busy) return;
    const controls = modalityCheckboxes();
    if (controls.size < 6) {
      ui.modality.value = '';
      if (ui.modalityHeader) ui.modalityHeader.textContent = '';
      return;
    }
    const selected = [...controls].filter(([, el]) => el.checked).map(([key]) => key);
    ui.modality.value = selected.length === 0 ? 'any' : selected.length === 1 ? selected[0] : 'multiple';
    if (ui.modalityHeader) {
      const label = selected.length === 0 ? 'Any' : selected.length === 1
        ? (MODALITIES.find(m => m.key === selected[0])?.label || 'Selected') : `${selected.length} selected`;
      ui.modalityHeader.textContent = label;
      ui.modalityHeader.title = label;
    }
  }

  async function selectModalityAndFind() {
    if (busy) return;
    const choice = ui.modality.value;
    if (!choice || choice === 'multiple') return;
    const controls = modalityCheckboxes();
    if (controls.size < 6 || (choice !== 'any' && !controls.has(choice))) {
      setStatus('Could not identify the Course List delivery-type controls reliably. No search was run; choose the modality on the page instead.', 'warn');
      syncModalityFromPage();
      return;
    }
    busy = true;
    render();
    setStatus('Setting modality and searching...', 'info');
    try {
      // First uncheck other modalities, then select the one requested.
      // Re-query each input because the site can re-render controls after a click.
      const keys = [...controls.keys()].filter(k => k !== choice);
      if (choice !== 'any') keys.push(choice);
      for (const key of keys) {
        const input = modalityCheckboxes().get(key);
        if (!input || !input.isConnected || input.disabled) throw new Error('A delivery-type control disappeared while updating.');
        const desired = key === choice;
        if (input.checked !== desired) {
          input.click(); // Actual click triggers the site's own change handlers.
          await wait(35);
        }
      }
      await wait(140);
      const after = modalityCheckboxes();
      const correct = [...controls.keys()].every(key => after.has(key) && after.get(key).checked === (key === choice));
      if (!correct) {
        setStatus('Delivery type could not be confirmed. Check the filters on the page before searching.', 'warn');
        return;
      }
      runFind('modality');
    } catch (err) {
      setStatus('Unable to set modality: ' + (err?.message || 'unknown error') + '. No search was run.', 'error');
    } finally {
      busy = false;
      render();
      syncModalityFromPage();
    }
  }

  function findFindButton() {
    const root = getFieldRoot().root;
    const candidates = [...root.querySelectorAll('button, input[type="submit"], input[type="button"]')];
    return candidates.find(b => /^find(?: courses)?$/i.test(norm(b.textContent || b.value))) ||
      candidates.find(b => /^(?:search|search courses)$/i.test(norm(b.textContent || b.value))) || null;
  }

  const CSS_TEXT = `
    :host { all: initial; color-scheme: light; }
    *, *::before, *::after { box-sizing: border-box; }
    .mcl-panel, .mcl-peek { font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
    .mcl-panel { width: 100%; max-width: 100%; height: 100%; max-height: 100%; overflow: hidden; display: flex; flex-direction: column; color: #27282e;
      background: #fff; border: 0; border-left: 1px solid #d8dce4; border-radius: 0; box-shadow: -4px 0 17px rgba(20,26,34,.14); font-size: 13px; }
    :host([data-side="left"]) .mcl-panel { border-left:0; border-right:1px solid #d8dce4; box-shadow:4px 0 17px rgba(20,26,34,.14); }
    :host([data-side="right"]) .mcl-panel { border-right:0; }
    .mcl-header { flex: 0 0 auto; background: #b31b34; color: #fff; padding: 11px 12px 10px; display: flex; align-items: center; justify-content: space-between; gap: 10px; }
    .mcl-heading { font-size: 14px; font-weight: 750; letter-spacing: -.01em; line-height: 1.25; margin: 0; }
    .mcl-subheading { color: #ffdee5; font-size: 10.5px; line-height: 1.5; margin-top: 2px; }
    .mcl-header-actions { display: flex; gap: 4px; align-items: center; flex: 0 0 auto; }
    .mcl-reset-top { border: 1px solid rgba(255,255,255,.65); background:rgba(255,255,255,.14); border-radius:6px; padding:5px 6px; color:#fff; font-weight:700; font-size:10px; line-height:1.2; max-width:60px; white-space:normal; }
    .mcl-reset-top:hover:not(:disabled) { background:rgba(255,255,255,.28); }
    .mcl-reset-top:disabled { opacity:.5; }
    .mcl-icon { flex-shrink:0; }
    button { cursor: pointer; font: inherit; }
    .mcl-icon { width: 28px; height: 28px; border: 1px solid rgba(255,255,255,.35); border-radius: 6px; background: rgba(255,255,255,.12); color:#fff; display:flex; align-items:center; justify-content:center; font-size: 17px; }
    .mcl-icon:hover, .mcl-icon:focus-visible { background: rgba(255,255,255,.25); }
    .mcl-body { flex:1 1 auto; min-height:0; padding: 12px; overflow-y: auto; overflow-x: hidden; overscroll-behavior:contain; }
    .mcl-section { margin-bottom: 13px; }
    .mcl-section:last-child { margin-bottom: 0; }
    /* Lightweight accordion: multiple workflow sections may remain open.
       This is useful when building a schedule while consulting saved filters. */
    .mcl-accordion { display:block; margin:0 0 9px; border:1px solid #dce2ea; border-radius:8px; background:white; overflow:visible; }
    .mcl-accordion > summary { cursor:pointer; display:list-item; padding:10px 11px; font-size:12px; line-height:1.35; font-weight:750; color:#313d50; border-radius:8px; }
    .mcl-accordion > summary:hover { background:#f6f7fb; }
    .mcl-accordion > summary::marker { color:#b31b34; }
    .mcl-accordion[open] > summary { border-bottom:1px solid #e4e9f1; border-radius:8px 8px 0 0; background:#f9fafd; }
    .mcl-accordion-body { padding:10px 11px 11px; }
    .mcl-accordion-body ol { padding-left:19px; margin:3px 0 8px; font-size:11.5px; line-height:1.55; }
    .mcl-accordion-body li { margin-bottom:5px; }
    .mcl-accordion-body .mcl-section { margin:0; }
    .mcl-summary-count { float:right; max-width:132px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; font-size:10.5px; color:#62718a; font-weight:650; margin-left:4px; }
    .mcl-auto-section { padding:9px 11px; border:1px solid #dce2ea; border-radius:8px; margin:0 0 9px; background:#fff; }
    .mcl-accordion .mcl-schedule-list { margin-top:9px; }
    .mcl-help-actions { margin-top:8px; border-top:1px solid #edf0f3; padding-top:8px; }
    .mcl-help-actions summary { cursor:pointer; color:#5b6577; font-size:11px; }
    .mcl-status { flex:0 0 auto; margin:0 !important; border-radius:0 !important; padding:7px 11px !important; border-top:1px solid #dce2ea; max-height:74px; overflow-y:auto; }
    .mcl-label { display: block; font-size: 11.5px; font-weight: 700; color: #3c4250; margin-bottom: 5px; }
    .mcl-row { display: flex; align-items: center; gap: 6px; }
    .mcl-input, .mcl-select { display: block; width: 100%; border: 1px solid #b8c0ce; border-radius: 6px; padding: 8px 9px; min-height: 34px; background: white; color: #232631; font: inherit; min-width: 0; }
    .mcl-btn { border: 1px solid #b7bfcd; background: #f7f8fb; padding: 8px 10px; border-radius: 6px; color: #28303c; font-weight: 650; white-space: nowrap; min-height: 34px; }
    .mcl-btn.primary { background: #b31b34; color:#fff; border-color:#b31b34; }
    .mcl-btn.secondary { background: #fff; }
    .mcl-btn:hover:not(:disabled) { filter: brightness(.96); }
    .mcl-btn:disabled { opacity: .55; cursor: default; }
    .mcl-btn.fill { flex: 1; }
    .mcl-btn.compact { font-size: 11px; padding: 7px 9px; }
    .mcl-small { font-size: 11px; color: #626a78; line-height: 1.45; }
    .mcl-line { border-top: 1px solid #edf0f3; margin: 11px 0; }
    .mcl-quick { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 7px; max-height: 154px; overflow-y:auto; }
    .mcl-quick-item { display:flex; align-items:stretch; max-width:100%; min-width:0; border:1px solid #cad0da; background:#f6f8fc; border-radius: 16px; overflow:hidden; }
    .mcl-quick-item[data-selected="true"] { background: #fae7eb; border-color: #b31b34; }
    .mcl-quick-item[data-editing="true"] { box-shadow: inset 0 0 0 1px #b31b34; }
    .mcl-quick .mcl-quick-apply { flex: 1 1 auto; min-width:0; max-width:215px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; padding:6px 9px; border:0; background:transparent; color:#283344; font-size:11.5px; font-weight:650; }
    .mcl-quick-item[data-selected="true"] .mcl-quick-apply { color:#8c1026; }
    .mcl-quick .mcl-quick-edit { flex:0 0 auto; border:0; border-left:1px solid #cad0da; background:#fff; color:#8c1026; padding:6px 9px; font-size:11px; font-weight:700; }
    .mcl-quick .mcl-quick-edit[aria-pressed="true"] { background:#b31b34; color:#fff; }
    .mcl-quick button:hover:not(:disabled) { background:#f7e6eb; }
    .mcl-quick .mcl-quick-edit[aria-pressed="true"], .mcl-quick .mcl-quick-edit[aria-pressed="true"]:hover:not(:disabled) { background:#b31b34; color:#fff; }
    .mcl-quick button:disabled { opacity:.58; cursor:default; }
    .mcl-edit-area { margin:0 0 9px; padding:9px; background:#fff7f9; border:1px solid #ebbec8; border-radius:7px; }
    .mcl-edit-area[hidden] { display:none !important; }
    .mcl-edit-copy { color:#5a2633; font-size:11px; line-height:1.45; overflow-wrap:anywhere; }
    .mcl-edit-footer { display:flex; justify-content:flex-end; margin-top:7px; }
    .mcl-checkbox { display: flex; align-items: flex-start; gap: 6px; font-size: 11.5px; color:#373b44; cursor: pointer; line-height: 1.4; }
    .mcl-checkbox input { width: 15px; height: 15px; margin:1px 0 0; accent-color:#b31b34; }
    .mcl-status { margin-top: 11px; border-radius:6px; padding: 7px 8px; color:#344258; background:#f0f3f8; min-height:32px; font-size:11.25px; line-height:1.45; overflow-wrap: anywhere; }
    .mcl-status[data-kind="ok"] { background:#eef7ef; color:#285832; }
    .mcl-status[data-kind="warn"] { background:#fff7e6; color:#775217; }
    .mcl-status[data-kind="error"] { background:#fff0ef; color:#8a2020; }
    .mcl-guide { border-top: 1px solid #e9edf3; padding-top: 9px; }
    .mcl-guide-top { border-top: none; border-bottom: 1px solid #e9edf3; padding: 0 0 10px; margin-bottom: 12px; }
    .mcl-guide summary { cursor:pointer; color:#47536b; font-weight:650; font-size:11.75px; }
    .mcl-guide ol { padding-left: 18px; margin:8px 0 3px; color:#4b5260; font-size:11.5px; line-height:1.55; }
    .mcl-guide li { margin: 0 0 4px; }
    .mcl-program-detail[hidden], .mcl-subchoices[hidden] { display:none !important; }
    .mcl-program-detail { margin-top:9px; border-left: 3px solid #b31b34; background: #f8f9fc; padding:9px 10px; border-radius:0 7px 7px 0; }
    .mcl-program-detail .mcl-label { margin-top:10px; }
    .mcl-program-detail .mcl-label:first-child { margin-top:0; }
    .mcl-choice-list { display:grid; grid-template-columns:repeat(2, 1fr); gap:6px 10px; margin-top:7px; }
    .mcl-choice-list label { display:flex; align-items:center; gap:5px; font-size:11.5px; }
    .mcl-choice-list input { accent-color:#b31b34; }
    .mcl-course-summary { margin-top:8px; overflow-wrap:anywhere; font-size:11px; line-height:1.45; font-weight:650; color:#303b4c; }
    .mcl-export-summary { font-size: 11.5px; color:#3a4252; font-weight:700; margin: 0 0 7px; }
    .mcl-export-row { display:flex; gap:6px; flex-wrap:wrap; margin-top:6px; }
    .mcl-export-row .mcl-btn { flex:1 1 auto; }
    .mcl-export-list { margin:7px 0 0; padding:0; list-style:none; max-height:146px; overflow:auto; font-size:10.5px; }
    .mcl-export-list li { color:#475065; line-height:1.35; }
    .mcl-schedule { margin-top: 13px; }
    .mcl-schedule-actions { display:flex; flex-wrap:wrap; gap:6px; margin:8px 0; }
    .mcl-schedule-actions .mcl-btn { flex:1 1 auto; min-width:0; white-space:normal; }
    .mcl-schedule-list { max-height:315px; overflow-y:auto; background:#fafbfe; border:1px solid #e1e5ec; border-radius:8px; padding:7px 9px; }
    .mcl-schedule-empty { font-size:11px; color:#667084; line-height:1.5; }
    .mcl-schedule-term { margin:9px 0 7px; font-size:11px; line-height:1.3; color:#70182c; font-weight:800; }
    .mcl-schedule-term:first-child { margin-top:0; }
    .mcl-schedule-day { font-size:10px; color:#566071; text-transform:uppercase; font-weight:800; letter-spacing:.05em; margin:9px 0 5px; }
    .mcl-schedule-item { display:flex; align-items:flex-start; gap:5px; border:1px solid #e0e5ec; border-radius:7px; padding:7px; margin:5px 0; background:#fff; }
    .mcl-schedule-item-content { flex:1; min-width:0; overflow-wrap:anywhere; }
    .mcl-schedule-course { font-size:11.5px; font-weight:750; color:#273444; }
    .mcl-schedule-caption { font-size:10px; color:#657184; line-height:1.4; }
    .mcl-schedule-time { font-size:10.75px; color:#293446; font-weight:650; margin-top:3px; }
    .mcl-schedule-clash { font-size:10px; font-weight:750; color:#98252b; margin-top:3px; }
    .mcl-schedule-conflict { background:#fff3f1; border-color:#d99198; }
    .mcl-schedule-warning { margin:2px 0 7px; font-size:10.5px; color:#a02c34; line-height:1.4; }
    .mcl-schedule-remove { padding:1px 6px; border:1px solid #cfd6df; background:white; border-radius:4px; color:#8b2035; font-size:16px; line-height:1.2; min-width:25px; min-height:25px; }
    /* Accessible Mon-Fri calendar: true 30-minute time table, with precisely
       positioned meeting blocks. Horizontal scrolling is internal to panel. */
    .mcl-calendar-details { margin-top:12px; border-top:1px solid #dce2ea; padding-top:9px; }
    .mcl-calendar-details > summary { cursor:pointer; font-size:11.5px; font-weight:800; color:#334054; padding:2px 0 7px; }
    .mcl-calendar-toolbar { display:flex; align-items:center; gap:8px; justify-content:space-between; margin:8px 0; }
    .mcl-calendar-toolbar .mcl-btn { font-size:10.5px; white-space:normal; min-height:30px; padding:5px 7px; }
    .mcl-calendar-help { font-size:10.5px; color:#59677a; line-height:1.4; margin:5px 0 9px; }
    .mcl-calendar-term { margin:11px 0 6px; color:#77223a; font-size:11px; font-weight:800; }
    .mcl-calendar-key { display:flex; gap:9px; flex-wrap:wrap; margin:6px 0 8px; color:#445066; font-size:10px; }
    .mcl-calendar-key-item { display:flex; align-items:center; gap:4px; }
    .mcl-calendar-swatch { display:inline-block; flex-shrink:0; width:11px; height:11px; background:#e3effe; border:1px solid #5985b4; border-radius:2px; }
    .mcl-calendar-swatch.conflict { background:#fff0ed; border:2px solid #bd3140; }
    .mcl-calendar-scroll { overflow-x:auto; overflow-y:hidden; max-width:100%; border:1px solid #ccd4e1; border-radius:7px; overscroll-behavior:contain; scrollbar-width:thin; }
    .mcl-calendar-scroll:focus-visible { outline-offset:-3px; }
    .mcl-calendar-canvas { width:674px; position:relative; background:#fff; }
    .mcl-calendar-table { width:674px; border-collapse:separate; border-spacing:0; table-layout:fixed; color:#47566a; font-size:10px; }
    .mcl-calendar-table col.time-col { width:54px; }
    .mcl-calendar-table col.day-col { width:124px; }
    .mcl-calendar-table thead th { height:36px; background:#f2f5fa; text-align:center; font-weight:800; padding:0 2px; border-right:1px solid #d7deea; border-bottom:2px solid #b9c5d5; }
    .mcl-calendar-table thead th:first-child { font-size:10px; }
    .mcl-calendar-table tbody tr { height:28px; }
    .mcl-calendar-table tbody th { height:28px; font-weight:650; background:#fafbfd; text-align:right; padding:0 5px 0 1px; border-bottom:1px solid #d6dce6; border-right:1px solid #d6dce6; white-space:nowrap; }
    .mcl-calendar-table tbody td { height:28px; padding:0; border-bottom:1px solid #e3e8ef; border-right:1px solid #e3e8ef; background:#fff; }
    .mcl-calendar-table tbody tr:nth-child(even) td { background:#fafbfe; }
    .mcl-calendar-overlays { position:absolute; left:0; right:0; top:36px; height:728px; pointer-events:none; }
    .mcl-calendar-track { position:absolute; top:0; height:728px; width:124px; pointer-events:none; }
    .mcl-calendar-block { position:absolute; box-sizing:border-box; min-height:13px; padding:3px 3px 2px; overflow:hidden; border:1px solid #95b3d6; border-left:3px solid #3977a8; border-radius:4px; background:#e3effe; color:#182e46; pointer-events:auto; font-size:9px; line-height:1.15; box-shadow:0 1px 2px #24354a18; }
    .mcl-calendar-block[data-tone='1'] { background:#e7f4ec; border-color:#87bd99; border-left-color:#368152; color:#16442d; }
    .mcl-calendar-block[data-tone='2'] { background:#f2eafd; border-color:#bc9ce5; border-left-color:#8055b5; color:#402865; }
    .mcl-calendar-block[data-tone='3'] { background:#e0f4f6; border-color:#7bb7bb; border-left-color:#2d858c; color:#164d50; }
    .mcl-calendar-block[data-tone='4'] { background:#fff2df; border-color:#d9b47b; border-left-color:#a86e1b; color:#633c0a; }
    .mcl-calendar-block[data-conflict='true'] { background:#fff0ed !important; border:2px solid #b62b3c !important; color:#741b28 !important; box-shadow:inset 0 0 0 1px #f1b8ba; z-index:2; }
    .mcl-calendar-block[data-uncertain='true'] { border-style:dashed !important; }
    .mcl-calendar-block:hover, .mcl-calendar-block:focus-visible { z-index:5; outline:2px solid #1d5fa1 !important; outline-offset:1px; }
    .mcl-calendar-code { display:block; font-weight:850; letter-spacing:-.01em; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .mcl-calendar-block[data-narrow='true'] { padding:2px 1px; }
    .mcl-calendar-block[data-narrow='true'] .mcl-calendar-code { white-space:normal; overflow:visible; text-overflow:clip; overflow-wrap:normal; font-size:8px; line-height:1.1; }
    .mcl-calendar-block[data-narrow='true'] .mcl-calendar-code .mcl-calendar-subject,
    .mcl-calendar-block[data-narrow='true'] .mcl-calendar-code .mcl-calendar-number { display:block; }
    .mcl-calendar-block[data-narrow='true'] .mcl-calendar-eventtime,
    .mcl-calendar-block[data-narrow='true'] .mcl-calendar-eventroom { display:none; }

    .mcl-calendar-eventtime { display:block; font-size:8.3px; margin-top:2px; }
    .mcl-calendar-eventroom { display:block; font-size:8.3px; margin-top:2px; }
    .mcl-calendar-offgrid { margin:9px 0 0; padding:7px 8px; border:1px solid #e2e6ec; border-radius:6px; background:#fafbfd; font-size:10.5px; }
    .mcl-calendar-offgrid-heading { font-weight:800; margin:0 0 4px; color:#475269; }
    .mcl-calendar-offgrid ul { padding-left:16px; margin:4px 0 2px; }
    .mcl-calendar-offgrid li { margin:3px 0; color:#4c596d; }

    .mcl-backup { margin-top: 13px; padding-top: 11px; }
    .mcl-backup summary { color: #303c56; }
    .mcl-backup-body { padding-top: 9px; }
    .mcl-backup-actions { display:flex; gap:6px; margin-top:10px; }
    .mcl-backup-actions .mcl-btn { flex: 1; min-width: 0; }
    .mcl-peek { display:none; width:36px; height:42px; align-items:center; justify-content:center; margin:8px auto; background:#b31b34; color:white; border:1px solid #fff; border-radius:8px; padding:0; box-shadow:0 3px 10px #17233324; font-size:20px; font-weight:700; }
    :host([data-collapsed="true"]) .mcl-panel { display:none; }
    :host([data-collapsed="true"]) .mcl-peek { display:flex; }
    :focus-visible { outline: 3px solid #2967d0 !important; outline-offset:2px; }
  `;

  // Reserve a strip of the webpage for the extension, rather than covering
  // Course List's search fields or results with a floating overlay. The style
  // only targets the document root; we never move/wrap the university's DOM.
  function installDockStyles() {
    const page = document.documentElement;
    if (document.getElementById('mcl-lite-dock-style')) return;
    const computed = getComputedStyle(page);
    page.style.setProperty('--mcl-lite-base-pad-left', computed.paddingLeft);
    page.style.setProperty('--mcl-lite-base-pad-right', computed.paddingRight);
    const style = document.createElement('style');
    style.id = 'mcl-lite-dock-style';
    style.textContent = `
      html[data-mcl-lite-dock] { box-sizing: border-box !important; min-width:0 !important; }
      html[data-mcl-lite-dock="right"] {
        padding-right: calc(var(--mcl-lite-base-pad-right, 0px) + var(--mcl-lite-dock-width, 320px)) !important;
      }
      html[data-mcl-lite-dock="left"] {
        padding-left: calc(var(--mcl-lite-base-pad-left, 0px) + var(--mcl-lite-dock-width, 320px)) !important;
      }
      html[data-mcl-lite-dock] > body { max-width: 100% !important; box-sizing: border-box !important; }
    `;
    (document.head || page).append(style);
  }

  function buildPanel() {
    installDockStyles();
    host = document.createElement('div');
    host.id = 'mcl-lite-host';
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483646;top:0;bottom:0;right:0;height:100vh;pointer-events:auto';
    shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML = `
      <style>${CSS_TEXT}</style>
      <button class="mcl-peek" id="peek" type="button" aria-label="Open Course List panel" title="Open Course List panel">&#9664;</button>
      <section class="mcl-panel" id="panel" aria-label="Miami Course List presets">
        <div class="mcl-header">
          <div>
            <h2 class="mcl-heading">Course List presets</h2>
            <div class="mcl-subheading">Miami Course List only &bull; saved locally</div>
          </div>
          <div class="mcl-header-actions">
            <button class="mcl-reset-top" type="button" id="resetFields" title="Clear search criteria (keep Term, Campus, saved presets and course selections)">Reset fields</button>
            <button class="mcl-icon" type="button" id="move" title="Move panel to other side" aria-label="Move panel to other side">&#8646;</button>
            <button class="mcl-icon" type="button" id="collapse" title="Collapse docked sidebar" aria-label="Collapse docked sidebar">&#8722;</button>
          </div>
        </div>
        <div class="mcl-body">
          <details class="mcl-accordion" id="instructionsAccordion">
            <summary>Quick instructions</summary>
            <div class="mcl-accordion-body">
            <ol>
              <li>Set Term, Campus, Subject, and any other filters on the page.</li>
              <li>Name the search in <strong>Save current search as</strong> and press <strong>Save</strong>.</li>
              <li>Click a saved-filter button to restore it, then press <strong>Find courses</strong>.</li>
              <li>To update a saved filter, click <strong>Edit</strong> beside its button. Change filters on Course List (and optionally its name), then <strong>Save changes</strong>. Cancel leaves the saved preset untouched.</li>
              <li>Choose a <strong>Major or minor</strong> to set its course filters and Find automatically. Term and Campus remain unchanged.</li>
              <li>For Digital Commerce, switch between CMR and IMS searches. For the Commerce Minor, optionally select three electives.</li>
              <li>Choose a <strong>Modality</strong> to set the delivery type and Find automatically.</li>
              <li>Each results row has an <strong>Export</strong> checkbox. Check rows individually or choose <strong>Select all shown</strong>. Use <strong>Reset checkboxes</strong> to clear all export selections without removing the draft schedule.</li>
              <li>Export selected rows as <strong>Excel, CSV, or PDF</strong>. The original column names, values, and left-to-right order are retained.</li>
              <li>To <strong>build a schedule</strong>, check course rows across searches and click Add checked courses. The schedule includes a Monday–Friday visual calendar (8 AM–9 PM), plus a conflict list. Use <strong>Expand width</strong> to see all five days at once. Exporting the schedule clears that draft.</li>
              <li>Use <strong>Reset fields</strong> in the header to clear search criteria without changing Term, Campus, saved presets, or checked course selections.</li>
              <li>Use <strong>Backup &amp; restore</strong> below to export or import presets between computers or after reinstalling.</li>
            </ol>
            <div class="mcl-small">Presets store search criteria, not passwords or account details. Export a backup after saving your filters.</div>
            </div>
          </details>
          <details class="mcl-accordion" id="savedAccordion" open>
            <summary id="savedHeading">Saved filters <span class="mcl-summary-count" id="count">0 saved presets</span></summary>
            <div class="mcl-accordion-body">
            <div id="quickArea" role="group" aria-labelledby="savedHeading">
              <div class="mcl-quick" id="quick"></div>
            </div>
            <div class="mcl-small" id="emptyPresets" style="display:none">No saved filters yet. Set filters on Course List and save your first preset below.</div>
            <button class="mcl-btn primary" type="button" id="find" style="width:100%;margin-top:10px">Find courses</button>
            <button class="mcl-btn compact secondary" type="button" id="delete" style="margin-top:7px">Delete selected preset</button>
            </div>
          </details>
          <details class="mcl-accordion" id="saveAccordion">
            <summary>Save current search as</summary>
            <div class="mcl-accordion-body">
            <div class="mcl-edit-area" id="editArea" hidden>
              <div class="mcl-edit-copy">Editing <strong id="editName"></strong>. Adjust the filters on Course List or rename below. <strong>Save changes</strong> updates this button, without running Find.</div>
              <div class="mcl-edit-footer"><button class="mcl-btn compact secondary" type="button" id="cancelEdit">Cancel editing</button></div>
            </div>
            <label class="mcl-label" id="nameLabel" for="name">Save current search as</label>
            <div class="mcl-row">
              <input class="mcl-input" id="name" type="text" maxlength="65" placeholder="e.g., CMR Hamilton" autocomplete="off" />
              <button class="mcl-btn primary" type="button" id="save">Save</button>
            </div>
            </div>
          </details>
          <div class="mcl-auto-section"><label class="mcl-checkbox"><input id="auto" type="checkbox" /><span>Automatically restore the last applied preset when I return</span></label></div>
          <details class="mcl-accordion" id="programAccordion">
            <summary>Major or minor <span class="mcl-summary-count" id="programHeader"></span></summary>
            <div class="mcl-accordion-body">
            <label class="mcl-label" for="program">Choose a program</label>
            <select class="mcl-select" id="program">
              <option value="">Choose a major or minor...</option>
              <optgroup label="Majors">
                ${PROGRAMS.filter(p => p.id.endsWith('major')).map(p => `<option value="${p.id}">${p.label}</option>`).join('')}
              </optgroup>
              <optgroup label="Minors">
                ${PROGRAMS.filter(p => p.id.endsWith('minor')).map(p => `<option value="${p.id}">${p.label}</option>`).join('')}
              </optgroup>
            </select>
            <div class="mcl-small" style="margin-top:5px">Selecting a program sets Subject and Course Number, then runs Find. Term and Campus are not changed.</div>
            <div class="mcl-program-detail" id="programDetails" hidden>
              <div class="mcl-small" id="programInfo"></div>
              <div class="mcl-subchoices" id="digitalArea" hidden>
                <label class="mcl-label" for="digitalFirst">CMR 281 or IMS 392</label>
                <select class="mcl-select" id="digitalFirst">
                  <option value="both">Show both options</option><option value="cmr">CMR 281 only</option><option value="ims">IMS 392 only</option>
                </select>
                <label class="mcl-label" for="digitalSecond">CMR 285 or IMS 414</label>
                <select class="mcl-select" id="digitalSecond">
                  <option value="both">Show both options</option><option value="cmr">CMR 285 only</option><option value="ims">IMS 414 only</option>
                </select>
                <label class="mcl-label" for="digitalSubject">Search subject</label>
                <select class="mcl-select" id="digitalSubject">
                  <option value="CMR">CMR courses</option><option value="IMS">IMS alternatives</option>
                </select>
              </div>
              <div class="mcl-subchoices" id="commerceArea" hidden>
                <label class="mcl-label" for="commerceMode">Elective options (choose 3)</label>
                <select class="mcl-select" id="commerceMode">
                  <option value="all">Show all 7 eligible electives</option>
                  <option value="three">Filter to my 3 selected electives</option>
                </select>
                <div class="mcl-subchoices" id="commerceChoices" hidden>
                  <div class="mcl-choice-list">
                    ${COMMERCE_ELECTIVES.map(n => `<label><input type="checkbox" value="${n}">CMR ${n}</label>`).join('')}
                  </div>
                </div>
                <div class="mcl-small" style="margin-top:5px" id="commerceCount" aria-live="polite"></div>
              </div>
              <div class="mcl-course-summary" id="programSummary" aria-live="polite"></div>
            </div>
            </div>
          </details>
          <details class="mcl-accordion" id="modalityAccordion">
            <summary>Modality <span class="mcl-summary-count" id="modalityHeader"></span></summary>
            <div class="mcl-accordion-body">
            <label class="mcl-label" for="modality">Delivery type</label>
            <select class="mcl-select" id="modality">
              <option value="">Choose a modality...</option>
              <option value="any">Any modality (clear filter)</option>
              ${MODALITIES.map(item => `<option value="${item.key}">${item.label}</option>`).join('')}
              <option value="multiple" disabled>Multiple selected on page</option>
            </select>
            <div class="mcl-small" style="margin-top:5px">Choosing a modality updates Course List and runs Find.</div>
            </div>
          </details>
          <details class="mcl-accordion" id="exportAccordion" open>
            <summary id="resultHeading">Select &amp; export courses <span class="mcl-summary-count" id="resultCount" aria-live="polite">0 selected</span></summary>
            <div class="mcl-accordion-body" role="region" aria-labelledby="resultHeading">
            <div class="mcl-small" id="resultHint">Run Find, then check Export beside the courses you want.</div>
            <div class="mcl-export-row">
              <button type="button" class="mcl-btn secondary compact" id="resultSelectAll" disabled>Select all shown</button>
              <button type="button" class="mcl-btn secondary compact" id="resultClear" title="Uncheck all Export selections, while keeping the draft schedule and saved filters" disabled>Reset checkboxes</button>
            </div>
            <div class="mcl-export-row">
              <button type="button" class="mcl-btn primary compact" id="resultXlsx" disabled>Excel</button>
              <button type="button" class="mcl-btn secondary compact" id="resultCsv" disabled>CSV</button>
              <button type="button" class="mcl-btn secondary compact" id="resultPdf" disabled>PDF</button>
            </div>
            <details class="mcl-guide" style="margin-top:9px" id="resultDetails" hidden>
              <summary>Review selected courses</summary>
              <ul class="mcl-export-list" id="resultList"></ul>
            </details>
            <details class="mcl-help-actions">
              <summary>Results troubleshooting</summary>
              <div class="mcl-small" style="margin-top:5px">If a course row has no checkbox after Find, refresh detection.</div>
              <button type="button" class="mcl-btn secondary compact" style="margin-top:7px" id="resultRescan">Refresh result checkboxes</button>
            </details>
            </div>
          </details>
          <details class="mcl-accordion" id="backupArea">
            <summary>Backup &amp; restore</summary>
            <div class="mcl-accordion-body mcl-backup-body">
              <div class="mcl-small">Save all presets and panel settings to a JSON file. Import that file after reinstalling or on another computer. Normal updates in the same extension folder keep your presets automatically.</div>
              <label class="mcl-label" for="importMode" style="margin-top:9px">When importing</label>
              <select id="importMode" class="mcl-select">
                <option value="replace">Restore everything (replace current)</option>
                <option value="merge">Add presets (keep current settings)</option>
              </select>
              <div class="mcl-backup-actions">
                <button type="button" class="mcl-btn secondary compact" id="exportBackup">Export backup</button>
                <button type="button" class="mcl-btn secondary compact" id="importBackup">Import backup</button>
              </div>
              <input type="file" id="backupFile" accept=".json,application/json" style="display:none" aria-label="Select a Miami Course List backup JSON file" />
              <div class="mcl-small" style="margin-top:7px">Import accepts backup files created by this extension. Unsaved filters on the webpage are not included.</div>
            </div>
          </details>
          <details class="mcl-accordion" id="scheduleAccordion">
            <summary id="scheduleHeading">Build schedule <span class="mcl-summary-count" id="scheduleSummary" aria-live="polite">0 sections</span></summary>
            <div class="mcl-accordion-body" role="region" aria-labelledby="scheduleHeading">
            <p class="mcl-small" style="margin:0 0 6px">Use checked sections from several searches. Planning only, not registration.</p>
            <p class="mcl-small" id="scheduleSelectedHint">Check courses to add them.</p>
            <div class="mcl-small" id="scheduleStats" aria-live="polite"></div>
            <div class="mcl-schedule-actions">
              <button type="button" class="mcl-btn primary compact" id="scheduleAdd">Add checked courses</button>
              <button type="button" class="mcl-btn secondary compact" id="scheduleClear">Clear schedule</button>
            </div>
            <div class="mcl-small" style="margin-top:9px;font-weight:700">Export schedule &amp; start fresh</div>
            <div class="mcl-schedule-actions" role="group" aria-label="Export schedule and clear it">
              <button type="button" class="mcl-btn secondary compact" id="scheduleXlsx" disabled>Excel</button>
              <button type="button" class="mcl-btn secondary compact" id="scheduleCsv" disabled>CSV</button>
              <button type="button" class="mcl-btn secondary compact" id="schedulePdf" disabled>PDF</button>
            </div>
            <div class="mcl-small">After saving the file, the schedule and its checked courses are cleared. Saved filter presets stay intact.</div>
            <div class="mcl-schedule-list" id="scheduleList" aria-label="Draft weekly course schedule" aria-live="polite">
              <div class="mcl-schedule-empty">No courses added yet.</div>
            </div>
            <details id="scheduleCalendarSection" class="mcl-calendar-details" open>
              <summary>Visual weekly schedule · Mon–Fri</summary>
              <div class="mcl-calendar-toolbar">
                <span class="mcl-small">8 AM–9 PM · 30-minute grid</span>
                <button type="button" class="mcl-btn secondary compact" id="scheduleCalendarWide" aria-pressed="false" title="Widen the docked panel to view all five weekdays">Expand width</button>
              </div>
              <div class="mcl-calendar-help">Scroll sideways to see all five days, or expand the panel. Blocks show the term-wide pattern; confirm the date ranges for sprint classes. Red borders indicate potential conflicts; dashed borders mean dates need verification.</div>
              <div id="scheduleCalendars" aria-label="Five-day visual calendar by term">
                <p class="mcl-schedule-empty">Add a course to see the Monday–Friday calendar.</p>
              </div>
            </details>
            </div>
          </details>
        </div>
        <div id="status" class="mcl-status" role="status" aria-live="polite">Ready. Set filters on Course List, then save a preset.</div>
      </section>`;
    document.documentElement.append(host);
    ['panel','peek','resetFields','move','collapse','find','savedAccordion','saveAccordion','programAccordion','programHeader','modalityHeader','exportAccordion','quickArea','quick','emptyPresets','program','programDetails','programInfo','digitalArea','digitalFirst','digitalSecond','digitalSubject','commerceArea','commerceMode','commerceChoices','commerceCount','programSummary','modality','editArea','editName','cancelEdit','nameLabel','name','save','count','delete','auto','backupArea','exportBackup','importBackup','backupFile','importMode','status'].forEach(k => ui[k] = shadow.getElementById(k));
    ui.collapse.addEventListener('click', () => toggleCollapsed(true));
    ui.peek.addEventListener('click', () => toggleCollapsed(false));
    ui.move.addEventListener('click', async () => {
      state.side = state.side === 'right' ? 'left' : 'right';
      placeHost();
      await safePersist();
    });
    const calendarWideButton = shadow.getElementById('scheduleCalendarWide');
    calendarWideButton?.addEventListener('click', () => {
      calendarWide = !calendarWide;
      calendarWideButton.setAttribute('aria-pressed', String(calendarWide));
      calendarWideButton.textContent = calendarWide ? 'Normal width' : 'Expand width';
      placeHost();
    });
    ui.modality.addEventListener('change', selectModalityAndFind);
    ui.program.addEventListener('change', programChanged);
    for (const input of [ui.digitalFirst, ui.digitalSecond, ui.digitalSubject]) input.addEventListener('change', digitalChanged);
    ui.commerceMode.addEventListener('change', commerceModeChanged);
    ui.commerceChoices.addEventListener('change', commerceElectiveChanged);
    // Keep the dropdown's label synchronized if the site's checkboxes are changed manually.
    document.addEventListener('change', e => {
      if (e.target instanceof HTMLInputElement && e.target.type === 'checkbox' && modalityKeyForCheckbox(e.target)) {
        syncModalityFromPage();
      }
    }, true);
    ui.name.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); savePreset(); }
      else if (e.key === 'Escape' && editingPresetId) { e.preventDefault(); cancelEditing(); }
    });
    ui.find.addEventListener('click', () => runFind());
    ui.resetFields.addEventListener('click', resetSearchFields);
    ui.save.addEventListener('click', savePreset);
    ui.cancelEdit.addEventListener('click', cancelEditing);
    ui.delete.addEventListener('click', deleteSelected);
    ui.exportBackup.addEventListener('click', exportBackup);
    ui.importBackup.addEventListener('click', () => { if (!busy) ui.backupFile.click(); });
    ui.backupFile.addEventListener('change', e => {
      const selectedFile = e.target.files?.[0];
      e.target.value = ''; // Allow importing the same file again.
      if (selectedFile) importBackup(selectedFile);
    });
    ui.auto.addEventListener('change', async () => {
      state.autoRestore = ui.auto.checked;
      await safePersist();
      setStatus(state.autoRestore ? 'Auto-restore enabled. Your last applied preset will return on a future visit.' : 'Auto-restore turned off.', 'ok');
    });
    placeHost();
    window.addEventListener('resize', placeHost, { passive: true });
  }

  let calendarWide = false; // Temporary display choice; does not alter saved presets.
  function placeHost() {
    if (!host) return;
    const side = state.side === 'left' ? 'left' : 'right';
    // Keep Course List usable on smaller browser windows. The 44px collapsed
    // rail is also reserved, so even its reopen button doesn't obscure data.
    const fullWidth = calendarWide
      ? Math.min(760, Math.max(230, Math.floor(window.innerWidth * 0.60)))
      : Math.min(320, Math.max(230, Math.floor(window.innerWidth * 0.36)));
    const dockWidth = state.collapsed ? 44 : fullWidth;
    host.style.width = dockWidth + 'px';
    host.style.left = side === 'left' ? '0' : 'auto';
    host.style.right = side === 'right' ? '0' : 'auto';
    host.dataset.side = side;
    host.dataset.collapsed = String(!!state.collapsed);
    ui.peek.textContent = side === 'right' ? '◀' : '▶';
    const page = document.documentElement;
    page.style.setProperty('--mcl-lite-dock-width', dockWidth + 'px');
    page.dataset.mclLiteDock = side;
  }
  async function toggleCollapsed(value) {
    state.collapsed = !!value;
    placeHost();
    await safePersist();
    if (!value) (ui.quick.querySelector('button') || ui.find).focus();
    else ui.peek.focus();
  }
  async function safePersist() {
    try { await saveState(); return true; }
    catch (err) { setStatus('Could not save locally: ' + err.message, 'error'); return false; }
  }
  function render() {
    const selected = state.presets.some(p => p.id === state.selectedId);
    const editing = editingPresetId ? state.presets.find(p => p.id === editingPresetId) : null;
    ui.count.textContent = state.presets.length + ' saved preset' + (state.presets.length === 1 ? '' : 's');
    ui.editArea.hidden = !editing;
    ui.editName.textContent = editing?.name || '';
    ui.nameLabel.textContent = editing ? 'Edit preset name (optional)' : 'Preset name';
    ui.save.textContent = editing ? 'Save changes' : 'Save';
    ui.name.placeholder = editing ? 'Name for this saved filter' : 'e.g., CMR Hamilton';
    ui.cancelEdit.disabled = busy;
    ui.delete.disabled = !selected || busy || !!editing;
    ui.save.disabled = busy;
    ui.find.disabled = busy;
    ui.resetFields.disabled = busy;
    ui.modality.disabled = busy;
    ui.program.disabled = busy;
    for (const el of [ui.digitalFirst, ui.digitalSecond, ui.digitalSubject, ui.commerceMode]) el.disabled = busy;
    ui.exportBackup.disabled = busy;
    ui.importBackup.disabled = busy;
    ui.importMode.disabled = busy;
    ui.auto.checked = !!state.autoRestore;
    renderQuick();
    renderProgram();
  }
  function renderQuick() {
    const presets = state.presets;
    ui.quickArea.style.display = presets.length ? 'block' : 'none';
    ui.emptyPresets.style.display = presets.length ? 'none' : 'block';
    ui.quick.replaceChildren();
    for (const preset of presets) {
      const group = document.createElement('div');
      group.className = 'mcl-quick-item';
      group.dataset.selected = String(preset.id === state.selectedId);
      group.dataset.editing = String(preset.id === editingPresetId);

      const recall = document.createElement('button');
      recall.type = 'button';
      recall.className = 'mcl-quick-apply';
      recall.textContent = preset.name;
      recall.title = 'Restore ' + preset.name;
      recall.setAttribute('aria-label', 'Restore saved filter ' + preset.name);
      recall.setAttribute('aria-pressed', String(preset.id === state.selectedId));
      recall.disabled = busy;
      recall.addEventListener('click', () => {
        if (!leaveEditingIfNeeded()) return;
        state.selectedId = preset.id;
        applySelected(false);
      });

      const edit = document.createElement('button');
      edit.type = 'button';
      edit.className = 'mcl-quick-edit';
      edit.textContent = 'Edit';
      edit.title = 'Edit ' + preset.name;
      edit.setAttribute('aria-label', 'Edit saved filter ' + preset.name);
      edit.setAttribute('aria-pressed', String(preset.id === editingPresetId));
      edit.disabled = busy;
      edit.addEventListener('click', () => beginEditing(preset.id));

      group.append(recall, edit);
      ui.quick.append(group);
    }
    ui.delete.disabled = !state.presets.some(p => p.id === state.selectedId) || busy || !!editingPresetId;
  }

  function cancelEditing() {
    if (!editingPresetId || busy) return;
    editingPresetId = null;
    ui.name.value = '';
    render();
    setStatus('Editing canceled. The saved filter is unchanged. Filters currently shown on Course List were not reset.', 'info');
  }

  function leaveEditingIfNeeded() {
    if (!editingPresetId) return true;
    const editing = state.presets.find(p => p.id === editingPresetId);
    if (!window.confirm('Discard unsaved changes to "' + (editing?.name || 'this filter') + '"? The saved preset will remain unchanged.')) return false;
    editingPresetId = null;
    ui.name.value = '';
    return true;
  }

  async function beginEditing(presetId) {
    if (busy) return;
    const preset = state.presets.find(p => p.id === presetId);
    if (!preset) { setStatus('This saved filter is no longer available.', 'warn'); return; }
    if (editingPresetId === presetId) { ui.name.focus(); return; }
    if (!leaveEditingIfNeeded()) return;
    editingPresetId = preset.id;
    state.selectedId = preset.id;
    ui.name.value = preset.name;
    ui.saveAccordion.open = true;
    render();
    // Restore saved values first so that subsequent changes on the website are
    // deliberate. Do not click Find just because the user entered edit mode.
    const result = await applySelected(false);
    if (editingPresetId !== preset.id) return;
    if (result?.missing?.length) {
      setStatus('Editing "' + preset.name + '". Some saved controls could not be restored (' + result.missing.length + '). Check the page before Save changes.', 'warn');
    } else if (result) {
      setStatus('Editing "' + preset.name + '". Change Course List filters and/or its name, then Save changes. No search will run when saving.', 'info');
    } else {
      setStatus('Editing "' + preset.name + '". Could not restore all fields. Review Course List settings before saving.', 'warn');
    }
    ui.name.focus();
  }

  async function savePreset() {
    if (busy) return;
    const name = norm(ui.name.value);
    if (!name || name.length > 65) { setStatus('Enter a filter name (up to 65 characters).', 'warn'); ui.name.focus(); return; }
    const fields = nativeFieldSnapshot();
    if (!fields.length) { setStatus('No Course List filter fields were detected. Open the search filters on the page and try again.', 'error'); return; }
    if (fields.length > MAX_FIELDS_PER_PRESET) { setStatus('Too many filter controls to save safely. Adjust filters and try again.', 'error'); return; }

    const editing = editingPresetId ? state.presets.find(p => p.id === editingPresetId) : null;
    if (editingPresetId && !editing) {
      editingPresetId = null;
      render();
      setStatus('The filter being edited is no longer available. Please select it again.', 'warn');
      return;
    }
    const existing = state.presets.find(p => p.name.toLowerCase() === name.toLowerCase());
    if (editing && existing && existing.id !== editing.id) {
      setStatus('Another saved filter already uses that name. Choose a different name before saving.', 'warn');
      ui.name.focus();
      return;
    }
    if (!editing && existing && !window.confirm('Replace the saved preset "' + existing.name + '" with the current filters?')) return;
    if (!editing && !existing && state.presets.length >= MAX_PRESETS) {
      setStatus('Maximum 50 presets reached. Delete an older preset first.', 'warn');
      return;
    }

    const entry = { id: editing?.id || existing?.id || id(), name, fields, savedAt: new Date().toISOString() };
    const previous = { presets: state.presets, selectedId: state.selectedId };
    const nextPresets = [...state.presets];
    const replaceAt = nextPresets.findIndex(p => p.id === entry.id);
    if (replaceAt !== -1) nextPresets[replaceAt] = entry;
    else nextPresets.push(entry);
    nextPresets.sort((a, b) => a.name.localeCompare(b.name));
    state.presets = nextPresets;
    state.selectedId = entry.id;
    if (!(await safePersist())) {
      // A failed storage write must not discard the previous saved version.
      state.presets = previous.presets;
      state.selectedId = previous.selectedId;
      render();
      return;
    }
    editingPresetId = null;
    render();
    ui.name.value = '';
    setStatus((editing ? 'Updated' : 'Saved') + ' "' + name + '" (' + fields.length + ' controls). Use its button to restore it.', 'ok');
  }

  async function applySelected(auto) {
    if (busy) return;
    const preset = state.presets.find(p => p.id === state.selectedId);
    if (!preset) { setStatus('Choose a saved preset first.', 'warn'); return; }
    if (!Array.isArray(preset.fields) || !preset.fields.length) { setStatus('This preset contains no saved filter settings.', 'warn'); return; }
    busy = true;
    render();
    setStatus((auto ? 'Restoring' : 'Applying') + ' "' + preset.name + '"...', 'info');
    try {
      const result = await restoreNativeFields(preset.fields);
      clearProgramPicker();
      state.lastAppliedId = preset.id;
      await safePersist();
      const summary = 'Restored ' + result.completed + ' of ' + result.total + ' filter controls.';
      if (result.missing.length) {
        setStatus(summary + ' Some fields could not be matched or are not yet available: ' + result.missing.slice(0, 4).join(', ') + (result.missing.length > 4 ? ', ...' : '') + '. Check filters before Find.', 'warn');
      } else {
        setStatus('Applied "' + preset.name + '". ' + summary + ' Press Find courses when ready.', 'ok');
      }
      return result;
    } catch (error) { setStatus('Could not fully apply filters: ' + (error?.message || 'unknown error'), 'error'); return null; }
    finally { busy = false; render(); syncModalityFromPage(); }
  }

  async function deleteSelected() {
    if (busy) return;
    const preset = state.presets.find(p => p.id === state.selectedId);
    if (!preset) return;
    if (!window.confirm('Delete saved preset "' + preset.name + '"?')) return;
    state.presets = state.presets.filter(p => p.id !== preset.id);
    if (editingPresetId === preset.id) editingPresetId = null;
    if (state.lastAppliedId === preset.id) state.lastAppliedId = null;
    state.selectedId = null;
    if (!(await safePersist())) return;
    render();
    setStatus('Deleted "' + preset.name + '".', 'ok');
  }
  function isTermOrCampusField(el) {
    const values = [el.name, el.id, fieldLabel(el), el.getAttribute('aria-label')].map(keyText);
    return values.some(v => /^(?:term|termcode|searchterm|campus|campuses|campuscode|searchcampus)$/.test(v));
  }

  async function resetSearchFields() {
    if (busy) return;
    const rootInfo = getFieldRoot();
    if (!rootInfo.confident) {
      setStatus('Could not reliably identify the Course List search form. Reset was canceled.', 'warn');
      return;
    }
    const inputs = [...rootInfo.root.querySelectorAll('input, select, textarea')]
      .filter(el => isRelevant(el, rootInfo) && !isTermOrCampusField(el) && !el.disabled);
    if (!inputs.length) { setStatus('No search fields available to reset.', 'warn'); return; }
    const protectedBefore = termCampusSnapshot();
    busy = true;
    render();
    let cleared = 0;
    try {
      // Use normal DOM input/change events so the site's own form bindings update.
      for (const el of inputs) {
        if (!el.isConnected || el.disabled || !isRelevant(el, getFieldRoot())) continue;
        const type = (el.type || '').toLowerCase();
        if (type === 'checkbox' || type === 'radio') {
          if (el.checked) { el.checked = false; announceChanges(el); cleared++; }
        } else if (el.tagName === 'SELECT') {
          if (el.multiple) {
            const changed = [...el.options].some(opt => opt.selected);
            if (changed) {
              for (const opt of el.options) opt.selected = false;
              announceChanges(el); cleared++;
            }
          } else {
            const opts = [...el.options];
            const target = opts.find(opt => opt.value === '') || opts.find(opt => opt.defaultSelected) || opts[0];
            if (target && el.value !== target.value) { el.value = target.value; announceChanges(el); cleared++; }
          }
        } else if (el.value) { setInputValue(el, ''); cleared++; }
      }
      // Custom multi-select Subject filters may render outside native <select>s.
      const control = subjectControl();
      if (control?.type === 'custom' && currentSubjects(control).length) {
        await setCustomSubjects(control.el, []);
        cleared++;
      }
      clearProgramPicker();
      ui.modality.value = '';
      await wait(80);
      const after = termCampusSnapshot();
      if (!sameProtectedFields(protectedBefore, after)) {
        await restoreNativeFields(protectedBefore);
        setStatus('Search fields were cleared (' + cleared + ' changed), and Term/Campus were restored. Check their values before Find.', 'warn');
      } else setStatus('Reset ' + cleared + ' search field' + (cleared === 1 ? '' : 's') + '. Term, Campus, saved presets and selected courses were kept. No search was run.', 'ok');
    } catch (err) {
      setStatus('Reset partially completed: ' + (err?.message || err) + '. Review the Course List filters before searching.', 'warn');
    } finally { busy = false; render(); syncModalityFromPage(); }
  }

  function runFind(source = 'manual') {
    const button = findFindButton();
    if (!button || button.disabled) {
      setStatus('Could not use the Course List Find button. Use Find on the page itself.', 'warn');
      return false;
    }
    button.click();
    setStatus(source === 'modality' ? 'Modality selected. Find triggered automatically.' :
      'Course List search submitted using the site\'s Find button.', 'ok');
    return true;
  }

  function currentTermLabel() {
    const selects = [...document.querySelectorAll('select')].filter(el =>
      !host?.contains(el) && /\bterm\b/i.test([el.id, el.name, el.getAttribute('aria-label'), fieldLabel(el)].join(' ')));
    for (const select of selects) {
      const option = select.options[select.selectedIndex];
      if (option && option.value && !/^(?:select|choose|all terms|term)/i.test(norm(option.textContent))) {
        return norm(option.textContent).slice(0,90);
      }
      if (option && option.value && norm(option.textContent)) return norm(option.textContent).slice(0,90);
    }
    return '';
  }

  async function init() {
    const saved = await STORAGE.get();
    if (saved && typeof saved === 'object') {
      state = {
        ...state,
        ...saved,
        presets: Array.isArray(saved.presets) ? saved.presets.filter(p => p && p.id && Array.isArray(p.fields)).slice(0, MAX_PRESETS) : []
      };
    }
    buildPanel();
    if (state.selectedId && !state.presets.some(p => p.id === state.selectedId)) state.selectedId = null;
    placeHost();
    render();
    syncModalityFromPage();
    if (globalThis.MCLCourseResults) {
      try { await globalThis.MCLCourseResults.start({ shadow, status: setStatus, readTerm: currentTermLabel }); }
      catch (error) { setStatus('Course export controls could not start: ' + (error?.message || error), 'warn'); }
    }
    if (globalThis.MCLScheduleBuilder) {
      try { await globalThis.MCLScheduleBuilder.start({ shadow, setStatus }); }
      catch (error) { setStatus('Schedule planner could not start: ' + (error?.message || error), 'warn'); }
    }
    if (state.autoRestore && state.lastAppliedId) {
      const last = state.presets.find(p => p.id === state.lastAppliedId);
      if (last) {
        state.selectedId = last.id;
        render();
        await wait(AUTO_RESTORE_DELAY);
        await applySelected(true);
      }
    }
  }
  init().catch(error => console.warn('[Miami Course List Presets] Failed to initialize:', error));
})();
