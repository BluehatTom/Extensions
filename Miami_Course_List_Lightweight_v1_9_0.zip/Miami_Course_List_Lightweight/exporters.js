/* Offline export helpers for Miami Course List Lightweight. No external libraries or network. */
(() => {
  'use strict';
  const COLS = [
    ['term', 'Term'], ['course', 'Course'], ['title', 'Course Title'],
    ['section', 'Section'], ['crn', 'CRN'], ['campus', 'Campus'],
    ['modality', 'Modality'], ['instructor', 'Instructor'],
    ['meeting', 'Days / Time'], ['credits', 'Credit Hours'],
    ['status', 'Status / Seats'], ['details', 'Additional Details']
  ];
  const text = v => String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, ' ').trim();
  function sourceColumns(row) {
    if (Array.isArray(row.columns) && row.columns.length) {
      return row.columns.slice(0, 48).map((c, i) => ({
        label: text(c?.label || `Column ${i + 1}`).slice(0, 90),
        value: text(c?.value).slice(0, 650)
      }));
    }
    // Old v1.5 selections lack original columns. Preserve their compatibility;
    // newly checked courses export their real, original columns instead.
    return COLS.map(([key, label]) => ({ label, value: text(row[key]) }));
  }
  function columnKey(label, occurrence) { return label.toLowerCase() + '\u001f' + occurrence; }
  function schema(rows) {
    // First selected row establishes its exact source column order. When later
    // searches use different layouts, append any new headings in encounter order.
    const columns = [], seen = new Set();
    for (const row of rows) {
      const counts = new Map();
      for (const col of sourceColumns(row)) {
        const label = col.label;
        const occurrence = (counts.get(label.toLowerCase()) || 0) + 1;
        counts.set(label.toLowerCase(), occurrence);
        const key = columnKey(label, occurrence);
        if (!seen.has(key)) { seen.add(key); columns.push({ label, key }); }
      }
    }
    return columns;
  }
  function table(rows) {
    const cols = schema(rows);
    const data = rows.map(row => {
      const counts = new Map(), values = new Map();
      for (const col of sourceColumns(row)) {
        const label = col.label.toLowerCase();
        const occurrence = (counts.get(label) || 0) + 1;
        counts.set(label, occurrence);
        values.set(columnKey(col.label, occurrence), col.value);
      }
      return cols.map(col => values.get(col.key) || '');
    });
    return [cols.map(c => c.label), ...data];
  }
  const xml = v => text(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
  const encoder = new TextEncoder();

  function csv(rows) {
    // BOM helps Excel decode Unicode correctly; neutralize formula injection in text cells.
    const data = table(rows).map((row, index) => row.map(value => {
      const safe = index > 0 && /^[\s\u0000-\u001f]*[=+@\-]/.test(value) ? "'" + value : value;
      return '"' + safe.replace(/"/g, '""') + '"';
    }).join(',')).join('\r\n') + '\r\n';
    return new Blob(['\ufeff', data], { type: 'text/csv;charset=utf-8' });
  }

  const CRC_TABLE = (() => {
    const out = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let i = 0; i < 8; i++) c = (c & 1) ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      out[n] = c >>> 0;
    }
    return out;
  })();
  function crc32(bytes) {
    let crc = 0xffffffff;
    for (const b of bytes) crc = CRC_TABLE[(crc ^ b) & 255] ^ (crc >>> 8);
    return (crc ^ 0xffffffff) >>> 0;
  }
  function zip(files) {
    const pieces = [], central = [];
    let offset = 0;
    const u16 = (v, arr) => { arr.push(v & 255, (v >>> 8) & 255); };
    const u32 = (v, arr) => { u16(v & 65535, arr); u16((v >>> 16) & 65535, arr); };
    for (const [name, data] of files) {
      const filename = encoder.encode(name);
      const bytes = encoder.encode(data);
      const crc = crc32(bytes);
      const local = [];
      u32(0x04034b50, local); u16(20, local); u16(0x0800, local); u16(0, local);
      u16(0, local); u16(0, local); u32(crc, local); u32(bytes.length, local); u32(bytes.length, local);
      u16(filename.length, local); u16(0, local);
      pieces.push(new Uint8Array(local), filename, bytes);
      const entry = [];
      u32(0x02014b50, entry); u16(20, entry); u16(20, entry); u16(0x0800, entry); u16(0, entry);
      u16(0, entry); u16(0, entry); u32(crc, entry); u32(bytes.length, entry); u32(bytes.length, entry);
      u16(filename.length, entry); u16(0, entry); u16(0, entry); u16(0, entry); u16(0, entry);
      u32(0, entry); u32(offset, entry);
      central.push(new Uint8Array(entry), filename);
      offset += local.length + filename.length + bytes.length;
    }
    const centralSize = central.reduce((sum, item) => sum + item.length, 0);
    const end = [];
    u32(0x06054b50, end); u16(0, end); u16(0, end);
    u16(files.length, end); u16(files.length, end);
    u32(centralSize, end); u32(offset, end); u16(0, end);
    return new Blob([...pieces, ...central, new Uint8Array(end)],
      { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }
  function excelCol(n) {
    let s = '';
    for (let x = n + 1; x > 0; x = Math.floor((x - 1) / 26)) s = String.fromCharCode(65 + ((x - 1) % 26)) + s;
    return s;
  }
  function xlsx(rows) {
    const data = table(rows);
    const last = excelCol(data[0].length - 1);
    const widths = data[0].map((label, i) => {
      const sample = data.slice(1, 35).map(row => String(row[i] || '').length);
      return Math.min(58, Math.max(12, Math.min(36, label.length + 4), Math.min(58, Math.max(0, ...sample) + 2)));
    });
    const cells = data.map((values, rowIndex) => {
      const style = rowIndex === 0 ? 1 : rowIndex % 2 === 0 ? 2 : 0;
      const cs = values.map((value, i) => {
        const address = excelCol(i) + (rowIndex + 1);
        // Inline strings deliberately prevent interpreting course values as formulas.
        return `<c r="${address}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${xml(value)}</t></is></c>`;
      }).join('');
      return `<row r="${rowIndex + 1}"${rowIndex === 0 ? ' ht="27" customHeight="1"' : ''}>${cs}</row>`;
    }).join('');
    const sheet = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:${last}${data.length}"/><sheetViews><sheetView showGridLines="0" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="17"/><cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>${cells}</sheetData><autoFilter ref="A1:${last}${data.length}"/><pageMargins left="0.3" right="0.3" top="0.5" bottom="0.5" header="0.2" footer="0.2"/></worksheet>`;
    const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Aptos"/><color rgb="FF243041"/></font><font><b/><sz val="11"/><name val="Aptos"/><color rgb="FFFFFFFF"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFB31B34"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF2F5F9"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1" applyNumberFormat="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="49" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1" applyNumberFormat="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="49" fontId="0" fillId="3" borderId="0" xfId="0" applyAlignment="1" applyNumberFormat="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
    const types = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>`;
    const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const workbook = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Selected Courses" sheetId="1" r:id="rId1"/></sheets></workbook>`;
    const workbookRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
    return zip([
      ['[Content_Types].xml', types], ['_rels/.rels', rels],
      ['xl/workbook.xml', workbook], ['xl/_rels/workbook.xml.rels', workbookRels],
      ['xl/worksheets/sheet1.xml', sheet], ['xl/styles.xml', styles]
    ]);
  }

  function printable(v) {
    // Standard PDF fonts use WinAnsi; replace unsupported glyphs gracefully.
    return text(v).replace(/[\u2010\u2011\u2012\u2013\u2014]/g, '-').replace(/[\u2018\u2019]/g, "'")
      .replace(/[\u201c\u201d]/g, '"').replace(/\u2026/g, '...').replace(/\u00a0/g, ' ')
      .replace(/[\u2022\u25cf]/g, '*').replace(/[^\u0020-\u007e\u00a0-\u00ff]/g, '?');
  }
  function pdfQuoted(v) {
    return printable(v).replace(/[\\()]/g, '\\$&').replace(/[\u007f-\u00ff]/g, c => '\\' + c.charCodeAt(0).toString(8).padStart(3, '0'));
  }
  function wrap(v, max) {
    const s = printable(v);
    if (!s) return [];
    const words = s.split(/\s+/), lines = [];
    let line = '';
    for (let word of words) {
      if (word.length > max) {
        if (line) { lines.push(line); line = ''; }
        while (word.length > max) { lines.push(word.slice(0, max)); word = word.slice(max); }
      }
      if (!line) line = word;
      else if ((line + ' ' + word).length <= max) line += ' ' + word;
      else { lines.push(line); line = word; }
    }
    if (line) lines.push(line);
    return lines;
  }
  function pdf(rows) {
    // Use EXACTLY the same schema and data matrix as CSV and Excel. The only
    // PDF-specific transformation is wrapping/flowing cells onto printed pages.
    const matrix = table(rows);
    const headings = matrix[0] || [];
    const records = matrix.slice(1);
    const W = 1191, H = 842, M = 37; // A3 landscape; readable source-order tables.
    const FONT = 9, LINE = 12, BOTTOM = 43, MAX_GROUP = 7;
    const pages = [];
    const PAGE_HEADER = 106;
    let operations = [], y = 0, groupStart = 0, groupEnd = 0, activeStart = 0, activeEnd = 0, widths = [], xs = [];
    const stroke = (x1, y1, x2, y2, color = '0.83 0.86 0.90') =>
      operations.push(`${color} RG 0.65 w ${x1.toFixed(2)} ${y1.toFixed(2)} m ${x2.toFixed(2)} ${y2.toFixed(2)} l S`);
    const fill = (x, bottom, width, height, color) =>
      operations.push(`${color} rg ${x.toFixed(2)} ${bottom.toFixed(2)} ${width.toFixed(2)} ${height.toFixed(2)} re f`);
    const txt = (v, x, atY, size = FONT, bold = false, color = '0.15 0.18 0.24') => {
      operations.push(`${color} rg BT /${bold ? 'F2' : 'F1'} ${size} Tf 1 0 0 1 ${x.toFixed(2)} ${atY.toFixed(2)} Tm (${pdfQuoted(v)}) Tj ET`);
    };
    const charLimit = width => Math.max(9, Math.floor((width - 14) / (FONT * .53)));
    const printableLines = (value, width) => wrap(value, charLimit(width));
    const flushPage = () => {
      if (operations.length) pages.push({ stream: operations.join('\n') + '\n', start: activeStart, end: activeEnd });
      operations = [];
    };
    const startPage = () => {
      flushPage();
      activeStart = groupStart; activeEnd = groupEnd;
      txt('MIAMI UNIVERSITY  /  COURSE LIST', M, H - 38, 10, true, '0.70 0.10 0.20');
      txt('Selected course rows', M, H - 67, 18, true);
      txt(`${records.length} selected  |  Source columns ${groupStart + 1}-${groupEnd} of ${headings.length}  |  ${new Date().toLocaleDateString('en-US')}`,
        M, H - 85, 9);
      stroke(M, H - 94, W - M, H - 94);
      y = H - PAGE_HEADER;
      const headLines = headings.slice(groupStart, groupEnd).map((heading, i) => printableLines(heading, widths[i]));
      const headHeight = Math.max(27, Math.max(0, ...headLines.map(lines => lines.length)) * LINE + 12);
      fill(M, y - headHeight, W - M * 2, headHeight, '0.69 0.11 0.20');
      for (let i = 0; i < headLines.length; i++) {
        headLines[i].forEach((line, j) => txt(line, xs[i] + 7, y - 15 - j * LINE, FONT, true, '1 1 1'));
      }
      y -= headHeight;
      stroke(M, y, W - M, y, '0.69 0.11 0.20');
    };
    for (groupStart = 0; groupStart < headings.length; groupStart += MAX_GROUP) {
      groupEnd = Math.min(headings.length, groupStart + MAX_GROUP);
      const count = groupEnd - groupStart;
      const usable = W - M * 2;
      const weights = headings.slice(groupStart, groupEnd).map((heading, j) => {
        const index = groupStart + j;
        const sample = records.slice(0, 80).map(row => String(row[index] || '').length);
        const long = sample.sort((a, b) => a - b)[Math.floor(sample.length * .76)] || 0;
        return Math.min(275, Math.max(90, String(heading).length * 4 + 28, Math.min(long, 75) * 3.6 + 42));
      });
      const total = weights.reduce((sum, item) => sum + item, 0) || count;
      widths = weights.map(weight => usable * weight / total);
      xs = []; let cursor = M;
      for (const width of widths) { xs.push(cursor); cursor += width; }
      startPage();
      for (let r = 0; r < records.length; r++) {
        const values = records[r].slice(groupStart, groupEnd);
        const lines = values.map((value, i) => printableLines(value, widths[i]));
        const longest = Math.max(1, ...lines.map(a => a.length));
        let from = 0;
        while (from < longest) {
          let fit = Math.floor((y - BOTTOM - 17) / LINE);
          if (fit < 1) { startPage(); fit = Math.floor((y - BOTTOM - 17) / LINE); }
          const take = Math.min(fit, longest - from);
          const height = take * LINE + 13;
          if (r % 2 === 0) fill(M, y - height, usable, height, '0.955 0.968 0.983');
          for (let c = 0; c < lines.length; c++) {
            const chunk = lines[c].slice(from, from + take);
            chunk.forEach((line, j) => txt(line, xs[c] + 7, y - 14 - j * LINE));
            if (c > 0) stroke(xs[c], y, xs[c], y - height, '0.89 0.91 0.94');
          }
          y -= height;
          stroke(M, y, W - M, y);
          from += take;
          if (from < longest) startPage(); // Continue this same source row on the next page.
        }
      }
    }
    flushPage();
    const objects = [''];
    const add = entry => { objects.push(entry); return objects.length - 1; };
    const pagesId = add('');
    const fontId = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    const boldId = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    const pageIds = [];
    for (let p = 0; p < pages.length; p++) {
      const page = pages[p];
      const footer = `0.38 0.43 0.52 rg BT /F1 8 Tf 1 0 0 1 ${M} 25 Tm (Miami Course List - original data columns ${page.start + 1}-${page.end}) Tj ET\n` +
        `0.38 0.43 0.52 rg BT /F1 8 Tf 1 0 0 1 ${W - M - 87} 25 Tm (Page ${p + 1} of ${pages.length}) Tj ET\n`;
      const stream = page.stream + footer;
      const contentId = add(`<< /Length ${encoder.encode(stream).length} >>\nstream\n${stream}endstream`);
      pageIds.push(add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 ${fontId} 0 R /F2 ${boldId} 0 R >> >> /Contents ${contentId} 0 R >>`));
    }
    objects[pagesId] = `<< /Type /Pages /Count ${pageIds.length} /Kids [${pageIds.map(p => `${p} 0 R`).join(' ')}] >>`;
    const catalog = add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);
    let output = '%PDF-1.4\n% Course List source-order table\n';
    const offsets = [0];
    for (let i = 1; i < objects.length; i++) {
      offsets[i] = output.length;
      output += `${i} 0 obj\n${objects[i]}\nendobj\n`;
    }
    const xref = output.length;
    output += `xref\n0 ${objects.length}\n0000000000 65535 f \n`;
    for (let i = 1; i < objects.length; i++) output += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
    output += `trailer\n<< /Size ${objects.length} /Root ${catalog} 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
    return new Blob([output], { type: 'application/pdf' });
  }
  globalThis.MCLCourseExporters = Object.freeze({ csv, xlsx, pdf, COLS });
})();
