# Miami Course List Lightweight - v1.8.2

A Chrome/Edge extension for Miami University's Course List. **Version 1.8.2 reads dates and meeting times from the rightmost course-results column and checks schedule conflicts against both weekly meeting times and actual date ranges.** The v1.8.1 accordion, Reset export checkboxes, and course-first labels are retained. The sidebar remains docked and the search form/results use the remaining browser width. Your saved filters, editable presets, major/minor searches, Modality, original-order Excel/CSV/PDF exports, and Build Schedule remain intact. Schedule exports still clear the draft schedule after a successful save.

**Website:** https://www.apps.miamioh.edu/courselist/

## Update an existing extension without losing presets

1. Open Course List with your existing extension installed. If possible, use **Backup & restore > Export backup** to save your current presets first.
2. Extract `Miami_Course_List_Lightweight_v1_8_1.zip` somewhere temporary.
3. Copy the new **`content.js`, `results.js`, `exporters.js`, `scheduler.js`, `manifest.json`, and `README.md`** files into the **same folder currently used by your loaded extension**, replacing the older files. Do **not** uninstall the existing extension.
4. In `chrome://extensions` (or `edge://extensions`), select **Reload** for the extension.
5. Refresh Course List. Your saved presets should remain intact.

**Why this matters:** Chrome/Edge may assign a new extension identity if you load the extension from a different folder. This version retains the original Chrome storage key (`mcl_lite_presets_v1`), original preset format, and backup schema 1. Normal in-place updates retain saved presets. You can import a backup JSON file if you reinstall or use another computer.

### New installation

1. Extract the ZIP to a permanent folder.
2. Open `chrome://extensions` or `edge://extensions`.
3. Enable **Developer mode**, click **Load unpacked**, and choose the extracted `Miami_Course_List_Lightweight` folder containing `manifest.json`.
4. Visit https://www.apps.miamioh.edu/courselist/ and refresh if necessary.

## Docked sidebar - new in v1.8.0

- The extension sits flush against the **right edge** by default. Course List's main content is sized to fit **beside** it, not underneath it. The sidebar uses at most 320 pixels and becomes narrower on smaller windows.
- The **Move** (double arrow) control switches the dock to the left side and shifts the Course List page accordingly.
- The **Minimize** (minus) control collapses the dock to a **44-pixel-wide strip** with an arrow. Click that arrow to reopen it. The main Course List page expands automatically when collapsed.
- The sidebar fills the browser height and **scrolls independently** of the university page. The university page still scrolls normally.
- Side preference and collapsed state are stored with the other panel settings. Existing presets are not changed by this layout update.
- On unusually narrow windows or fixed-width university tables, the website may require horizontal scrolling. This extension does not change the university's search or registration systems.

**Live-page note:** Tested in an isolated Chrome browser with representative search fields and results, including left/right docking, collapse/expand, resizing, and all existing extension export and schedule tests. Final live-site appearance still needs checking against Miami's actual Course List markup.

## New in v1.8.1: compact accordion and clearer controls

- Sections are collapsible. **Quick instructions** start closed. **Saved filters** and **Select & export courses** start open; **Save current search as**, **Major or minor**, **Modality**, **Backup & restore**, and **Build schedule** start closed. A previously populated schedule opens automatically when you return. You may keep more than one section open at a time.
- The existing export **Clear all** operation has been renamed **Reset checkboxes** for clarity. It unchecks **all selected export rows across searches**, but **does not** remove sections already added to Build schedule, delete any filter presets, or change the Course List search form.
- **Delete selected preset** now sits next to your saved-filter buttons, rather than under the Save form. The saved-presets count appears in that section's header instead of being repeated.
- **Refresh result checkboxes** remains available under the small **Results troubleshooting** disclosure, because checkbox detection normally refreshes automatically.
- The Schedule Builder now identifies course codes using the Course field, or combined Subject and Course Number fields. **Building and Room are secondary location information**, not the course title. This also corrects previously saved schedule entries when their original column data is available.
- A compact status message stays at the bottom of the sidebar while the section list scrolls independently. Existing Filter Reset, Find, Export, Backup and Schedule features are unchanged.

## Select course rows and export (PDF UPDATED in v1.7.0)

1. Run a search on the Miami Course List site, using its **Find** button or the extension's **Find courses**, **Major or minor**, or **Modality** controls.
2. In the **search results**, check **Export** beside each actual row you want. Result rows are recognized even if only the first section in a group repeats the course code. You can also click **Select all shown** in the side panel. If results load slowly, open **Results troubleshooting** and click **Refresh result checkboxes**.
3. The panel displays a running count of checked courses. You can run another search and select more courses; **previous selections stay on your export list**. Repeating a section with the same CRN and term does not create a duplicate.
4. Click **Excel**, **CSV**, or **PDF** under **Select & export courses**. Only the selected courses are downloaded.
5. To review or remove individual courses, expand **Review selected courses**; use the × control beside an item. Use **Reset checkboxes** (with confirmation for multiple selections) to uncheck every exported-course pick. It does **not** clear your draft schedule or filter presets.

**Output columns and ordering:** Excel and CSV copy the actual column headings and each selected result row's values **in exactly the order displayed on Course List**, excluding the extension's Export checkbox. Rows are exported in **selection order**, not alphabetically sorted. When selections come from search views with different column layouts, the first selected view determines column order and any new headings are appended at the end; cells missing from a particular row are blank. PDF now uses the same unified tabular data and exact heading sequence as the CSV and Excel files. For wide tables, PDF prints consecutive groups of columns on separate landscape pages, keeping row and column order. A rowspan cell (such as a course code shared by several sections) is repeated for each exported section row.

**Output format details:** Excel creates a native, formatted `.xlsx` file with frozen column headings and autofilters. CSV opens in Excel and most data tools. The PDF presents a paginated, landscape table with column headings, row-by-row data and wrapped cells, using the same table matrix as Excel/CSV. The university's **Show Details / Hide Details** link text is ignored in exports but the links still work on the page. All three formats are generated locally and downloaded directly; the extension does not send course data to any other service.

**Persistence:** Selected courses are stored separately in local extension storage and usually remain across searches, page refreshes, and in-place extension updates. The **Backup & restore** JSON files contain saved filter presets and panel preferences, **not** selected course exports; download the Excel/CSV/PDF file to keep your selected course collection permanently or transfer it to another computer.

**Live-page compatibility:** Course List search results are dynamic. The selection tool scans all data rows in recognized result tables and course cards, including sections without repeated course codes, and re-scans on DOM and visibility changes. The university's actual post-search markup was not accessible to the build environment, so the final on-site behavior must be verified in your browser. If you see a search result with no Export checkbox, open **Results troubleshooting** and use **Refresh result checkboxes** and, if still missing, share a screenshot of that results layout so its structure can be supported. The export controls never invent missing course details.

## Build and export a weekly schedule (updated v1.8.2)

The **Build schedule** accordion is the last workflow section, below Backup & restore. Expand it to add, view, remove, or export sections. An existing saved schedule opens automatically when the page loads.

1. Choose **Term and Campus**, then run a search using any saved filter, Major or minor selection, or Modality control.
2. Check the course **sections** you want to consider. Find the **Build schedule** section and choose **Add checked courses**.
3. Change filters, click **Find**, and check additional sections. Choose **Add checked courses** again. Previous schedule entries remain; already-added sections are updated but not duplicated.
4. Review the **day-by-day schedule**, grouped by term, with course code and number first, then section/CRN, title, meeting time **and class meeting dates**, followed by building/room or campus. The extension checks the far-right course-results column for combined meeting dates and times, including headings such as **Meeting Dates and Times**, **Schedule**, or generic column headings that contain recognizable day/time/date patterns. Time blocks are sorted by start time.
5. **Potential schedule conflicts are highlighted** when two different sections in the same term meet on the same weekday at overlapping times **and** their published date ranges overlap on at least one occurrence of that weekday. Back-to-back times and non-overlapping half-term/sprint dates are not conflicts. Conflicting cards identify the other course(s), and the schedule lists a brief conflict summary. If the date range is missing or cannot be interpreted safely, overlapping day/time is labeled a **potential** conflict with a date-verification warning instead of silently ignoring it.
6. Classes without a reliable scheduled day and time, including **online asynchronous** sections, are listed separately as **No confirmed meeting time**. The extension does not invent start or end times.
7. When ready, click **Excel**, **CSV**, or **PDF** in the **Export schedule & start fresh** area below the schedule actions. The file contains the sections actually added to the schedule (not merely checked course rows), with source Course List headings and data in their original order. The file is named `Miami_Course_List_Schedule_YYYY-MM-DD.xlsx`, `.csv`, or `.pdf`.
8. **After a successful schedule export:** the draft schedule is cleared, its saved schedule storage is emptied, and checkboxes for the exported sections are unchecked. Any checked sections **not** in the schedule remain selected. Saved filters, Term, Campus, major/minor, and Modality settings are unchanged.
9. If the browser's save dialog is canceled or writing the file fails, the schedule is **not** cleared. Chrome/Edge may ask where to save. On browsers without the file-save dialog API, the extension falls back to the normal direct download and clears the schedule when that download has been initiated.
10. You can also use **×** beside an entry to remove it, or **Clear schedule** to discard the whole draft manually. Manual schedule clearing does not uncheck ordinary export selections.

**Important:** This is a **planning aid**, not registration or an official degree-audit schedule. Confirm meeting times, dates, locations, sections, and availability on Miami Course List before using it for enrollment. It understands common Miami weekday codes (e.g., MWF, TR), AM/PM or clearly formatted 24-hour clock ranges, and standard numeric or month-name date ranges. Unrecognized or incomplete meeting information is shown for manual verification rather than invented.

**Persistence:** The draft schedule is saved automatically in the browser's local extension storage (`mcl_lite_schedule_v1`) and should survive a normal in-place update. The **Backup & restore** JSON covers named presets and panel preferences, not your draft schedule. **Export schedule** to save the actual scheduled sections before clearing them. **Select & export courses** (higher in the panel) remains a separate feature: exporting those checked rows **does not clear the draft schedule**.

## Edit an existing saved filter

1. Find the preset under **Saved filters** at the top of the side panel.
2. Click **Edit** immediately to the right of that preset's button (not the preset name itself).
3. The extension restores the saved filters onto the Course List page and fills in the current preset name. It does **not** run Find.
4. Change any Course List filter on the university page (e.g., Term, Campus, Subject, Course Number, or Instructor). You can also rename the saved preset in the panel.
5. Click **Save changes**. The existing preset button is updated, not duplicated. The preset keeps its original ID, including its auto-restore selection.

Click **Cancel editing** to leave the saved preset unchanged. Cancel does not reset the filter values currently displayed on Course List. If you choose a different saved filter while editing, the extension confirms before discarding unsaved edits. Renaming to an existing preset name is blocked rather than overwriting a different preset.

**Note:** The Edit button applies to **your saved filter presets**, not the built-in major/minor course lists. To customize a program search, select that program, adjust the site's filters, then save it as a named preset. If you use the separate Modality dropdown while editing, it will continue to trigger Find as usual.

## Major or minor dropdown

Select **Term** and **Campus** on the actual Course List page first. Next, select a program under **Major or minor** in the side panel. The extension updates the site's **Subject** and **Course Number** controls, verifies the changes, and presses the site's **Find** button automatically.

**Term and Campus are not changed by the program selector.** Modality and other filters also remain in place, allowing a program search to be narrowed by modality or instructor. If a filter is already restrictive, it can reduce the results.

| Program | Searchable courses |
| --- | --- |
| Small Business Management Major | CMR 242, 263, 301, 361, 442, 446 |
| Sales Management Major | CMR 261, 263, 301, 362, 363, 461 |
| Sales Management Minor | CMR 105, 261, 263, 362, 363, 461 |
| Digital Commerce Major | CMR 242, 286, 341, 449, plus CMR 281 **or** IMS 392, and CMR 285 **or** IMS 414 |
| Digital Commerce Minor | CMR 105, 281, 285, 286, 341, 442 |
| Commerce Minor | CMR 105, 111, 302, plus **choose three** from CMR 101, 108, 207, 211, 244, 282, 495 |

These course groups were specified for this extension; verify actual program requirements with the applicable university catalog. This is **not a degree audit** and does not enforce prerequisites or count credits.

### Digital Commerce Major - either/or substitutions

Two extra dropdowns let you choose for each requirement:

- **CMR 281 or IMS 392:** Show both options (default), CMR 281 only, or IMS 392 only.
- **CMR 285 or IMS 414:** Show both options (default), CMR 285 only, or IMS 414 only.

A third dropdown, **Search subject**, switches between **CMR courses** and **IMS alternatives**. When there are no IMS options left, the IMS group is disabled. Every change applies the corresponding group to the Course List page and runs Find automatically.

**Why two searches?** Miami Course List allows comma-delimited course numbers and multiple subjects. Searching CMR and IMS together would apply **every number** to both subjects, potentially returning irrelevant combinations such as CMR 392 and IMS 242. Separate searches prevent those false matches while still allowing both alternatives to be reviewed.

### Commerce Minor - choose three electives

The default search includes CMR 105, 111, 302 and **all seven eligible elective options** so you can compare which are offered.

Change **Elective options (choose 3)** to **Filter to my 3 selected electives** to display checkboxes for CMR 101, 108, 207, 211, 244, 282, and 495. Select any three. Once three are selected, Course Number contains the three required courses **plus exactly those three electives**. If fewer than three are selected, the search temporarily shows all seven candidates. The panel prevents selecting a fourth. Each valid change updates filters and runs Find.

## Panel layout and Reset fields

The docked panel is now a series of compact accordion sections, in this order: **(1) Quick instructions; (2) Saved filters; (3) Save current search as; (4) Auto-restore toggle; (5) Major or minor; (6) Modality; (7) Select & export courses; (8) Backup & restore; (9) Build schedule.** The status message stays visible in a small footer. Open multiple sections together when comparing filters with a schedule.

**Reset fields**, located at the top of the panel, clears current Course List search criteria such as Subject, Course Number, Advanced Search fields and delivery-type selections. **It preserves Term and Campus**, all named saved presets, and the export course selections. It does not click Find or change the auto-restore preference. It does not automatically save changes to a named preset; use Save changes if intentionally editing one. Reset conservatively refuses to act if it cannot identify the page's search form.

## Other controls retained

- **Quick instructions** are first, closed by default. Choose the section heading to expand or collapse it.
- **Saved filters** have a recall button, a small **Edit** button and a separate **Delete selected preset** control. Clicking the preset name restores the saved site's filter values **without** running Find. The program dropdown clears when recalling a preset to avoid implying that the chosen program is still active.
- **Find courses** runs the website's native Find action.
- **Modality** sets one of the eight site's Alternative Delivery Types (or clears delivery filtering) and runs Find automatically.
- **Save current search as** captures the site's existing filter values (including Subject and Course Number that the program selector just populated). Name and save presets for future one-click recall.
- **Auto-restore** restores the last applied saved preset on a future visit. It does not run Find automatically.
- **Backup & restore** exports JSON backup files and imports them in **replace** or **merge** mode. Backups include named presets and panel preferences, but not the separate selected-course collection. Program picks are reflected in backups **only if saved as a named filter preset first**.
- **Move panel / Minimize** are unchanged.

## Reliability, privacy, and compatibility

- Runs only on `https://www.apps.miamioh.edu/courselist/` and `https://apps.miamioh.edu/courselist/`.
- Keeps browser data locally through `chrome.storage.local`; it neither connects to an outside server nor requests a password/API key.
- Program filters work with standard multiple-selects, some site-style multiselect dropdowns, or a labeled Subject checkbox fieldset. If Subject or Course Number cannot be identified or verified, the extension **does not automatically run Find** and displays an error rather than potentially searching the wrong courses.
- Uses the website's own Find control; results, course availability, and registration conditions come from the university page.
- **Local browser testing:** Earlier versions were checked for preset, program, modality, editing and backup behaviors. The v1.7.0 build passed local browser tests for saved presets, multiple search-result formats, grouped table sections, source-order PDF/CSV/Excel equivalence, removing Show Details labels from exports, schedule building across multiple searches, time-overlap detection, asynchronous/no-time handling, section removal, and reload persistence. The PDF also passed a 115-record, multi-page export test. **Live-site results markup has not yet been verified**, and the checkbox injection may need adjustment if the university uses a different result layout.

## Version history

- **v1.8.2:** Read the rightmost results column for meeting days/times and date ranges; display meeting dates in the weekly schedule; detect and explain potential conflicts only when time slots and actual date ranges overlap; mark missing-date cases for review. Stored schedules and export data remain compatible.
- **v1.8.1:** Accordion sections and sticky status footer; reset all export checkboxes without affecting the draft schedule; course-first schedule headings (including repaired legacy entries); move preset deletion beside saved filters; hide manual checkbox refresh in Results troubleshooting.
- **v1.8.0:** Dock the panel rather than overlay Course List; reserve page width, enable left/right docking, and collapse to a slim reopen strip.

- v1.0: Course List-only filter preset buttons and side panel.
- v1.0.1: Quick instructions moved to the top.
- v1.1.0: Modality dropdown with automatic Find; removed saved preset dropdown.
- v1.2.0: Portable backup export/import, replacement or merge restore.
- **v1.3.0:** Six major/minor options, Digital Commerce alternates, and Commerce Minor elective selection.
- **v1.4.0:** Edit existing saved filters in place; rename or change page filters, Save changes / Cancel editing, protect against name collisions and failed saves.

- **v1.5.0:** Select course sections directly from search results, retain selections across searches, export checked rows to genuine Excel/CSV/PDF, review/remove selections.

- **v1.6.0:** Every data row in recognized course results receives a checkbox (even when its course code is omitted); Excel/CSV preserve original heading and cell order and selections retain check order; PDF preserves the same field sequence; panel reordered with Instructions initially closed and Reset fields at the top.

- **v1.7.0:** Ignore Show Details link text in row data; print PDF in the same column/row matrix as CSV and Excel, paginating columns when needed; add a local, persistent weekly schedule builder with collision highlighting.

**Upgrade note for existing v1.5 selected courses:** Earlier v1.5 selections saved only a standardized set of fields. If you selected courses before upgrading, re-open the results and check those rows again (or clear and reselect) to capture each row's exact original columns. Your saved filter presets and backups remain compatible.
