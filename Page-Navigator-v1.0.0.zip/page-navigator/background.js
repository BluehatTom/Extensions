'use strict';

// The active tab ID and messaging API do not require the "tabs" permission.
// Every page action stays inside the statically declared, top-frame content script.
const VALID_COMMANDS = new Set([
  'top', 'middle', 'end', 'toggle', 'page-up', 'page-down',
  'previous-heading', 'next-heading', 'previous-spot',
  'save-spot', 'restore-spot', 'outline', 'open-search'
]);

chrome.commands.onCommand.addListener(async (command) => {
  if (!VALID_COMMANDS.has(command)) return;
  let tabId;
  try {
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    if (!tab?.id) return;
    tabId = tab.id;
    const result = await chrome.tabs.sendMessage(
      tabId,
      {type: 'PN_ACTION', action: command, source: 'command'},
      {frameId: 0}
    );
    if (!result?.ok) {
      throw new Error(result?.error || result?.message || 'Enable Page Navigator for this page to use this shortcut.');
    }
    await Promise.all([
      chrome.action.setBadgeText({tabId, text: ''}),
      chrome.action.setTitle({tabId, title: 'Page Navigator'})
    ]);
  } catch (error) {
    if (!tabId) return;
    const expected = error?.message;
    const title = /receiving end|establish connection|message port|tab was closed/i.test(expected || '')
      ? 'Page Navigator: refresh a normal webpage. Chrome system pages and the built-in PDF viewer are not supported.'
      : `Page Navigator: ${expected || 'Refresh the page and try again.'}`;
    // A tab may close while the shortcut is in flight. Do not leave an unhandled rejection.
    await Promise.allSettled([
      chrome.action.setBadgeBackgroundColor({tabId, color: '#9a3412'}),
      chrome.action.setBadgeText({tabId, text: '!'}),
      chrome.action.setTitle({tabId, title})
    ]);
  }
});
