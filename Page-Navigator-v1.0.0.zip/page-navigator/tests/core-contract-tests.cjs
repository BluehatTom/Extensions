'use strict';
// Deterministic logic tests, not a browser or DOM integration test.
// Every function under test is extracted from the actual production content.js.
// Browser geometry, scrolling, and storage are the only mocked boundaries.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert/strict');
const source = fs.readFileSync(path.join(__dirname,'../content.js'),'utf8');
const report = [];
function sourceFunction(name) {
  const pattern = new RegExp('^  (?:async )?function '+name+'\\([^\\n]*\\) \\{[\\s\\S]*?^  \\}', 'm');
  const match = source.match(pattern);
  assert.ok(match,`Production function ${name} could not be extracted`);
  return match[0];
}
function fixture() {
  const doc = {scrollHeight:9000,clientHeight:1000,scrollTop:0,scrollLeft:0,isConnected:true};
  const storage = {};
  const state = { renders:0, scrollCalls:[], messages:[], reducedMotion:false, inputsActive:false };
  const ui = {value:'',textContent:'',focus(){}};
  const c = vm.createContext({
    URL,Number,Math,Date,console,Promise,Set,Array,Object,String,Boolean,
    DEFAULTS:{enabled:true,smooth:true,position:'bottom-right',showProgress:true,avoidTyping:true},
    SPOT_PREFIX:'pnSpot:',SETTINGS_KEY:'pnSettings',
    settings:{enabled:true,smooth:false,position:'bottom-right',showProgress:true,avoidTyping:true},
    history:[],jumpToken:0,location:{href:'https://example.test/article?edition=1',hostname:'example.test'},
    pageIdentity:'https://example.test/article?edition=1',savedSpot:null,
    manualRoot:null,recentRoot:null,activeRoot:doc,disabledSites:[],temporarilyHidden:false,
    forcedVisible:false,collapsed:false,panelOpen:false,scanNeeded:false,headingsDirty:false,lastHeading:null,lastHeadingDestination:null,headingJumpAt:0,
    document:{documentElement:{clientHeight:1000},querySelector:()=>null},innerHeight:1000,
    window:{scrollTo(options){state.scrollCalls.push({...options,page:true});doc.scrollTop=options.top;}},
    pageRoot:()=>doc,isPage:el=>el===doc,
    resolveRoot:()=>c.manualRoot||c.activeRoot||doc,
    enabled:()=>c.settings.enabled&&!c.disabledSites.includes(c.location.hostname),
    matchMedia:()=>({matches:state.reducedMotion}),
    queueRender:()=>{state.renders++;},render:()=>{state.renders++;},
    announce:msg=>{state.messages.push(msg);},
    checkRoute:async()=>{},clearSearch:()=>{},typing:()=>state.inputsActive,
    navigateHeading:()=>{},headings:()=>[],stickyOffset:()=>0,selectorFor:()=>null,
    headingTop:item=>item.top,scrollable:()=>true,
    showPanel:open=>{c.panelOpen=open;},permittedVisibility:()=>!c.temporarilyHidden,
    $:()=>ui,storeCollapsed:async()=>{},renderAreas:()=>{},
    chrome:{storage:{local:{
      async set(values){Object.assign(storage,values);},
      async get(key){if(typeof key==='string')return {[key]:storage[key]};return {...storage};},
      async remove(key){delete storage[key];}
    }}},
  });
  for(const name of ['identity','metrics','remember','scroll','saveReadingSpot','validSpot','restoreReadingSpot','action','normalizeSettings']) {
    vm.runInContext("'use strict';\n"+sourceFunction(name),c,{filename:'production:'+name});
  }
  return {c,doc,storage,state,ui};
}
async function test(name,fn){try{await fn();report.push({name,passed:true});console.log('PASS',name);}catch(error){report.push({name,passed:false,error:error.message});console.error('FAIL',name,error.stack);}}
function gate(){let resolve,reject;const promise=new Promise((res,rej)=>{resolve=res;reject=rej;});return {promise,resolve,reject};}
async function waitFor(predicate){for(let i=0;i<30;i++){if(predicate())return;await Promise.resolve();}assert.ok(predicate(),'Deferred storage was not reached');}
(async()=>{
 await test('Top/Middle/End use 0%, 50%, and 100% of scrollable distance',async()=>{
   const {c,doc}=fixture();
   doc.scrollTop=300;await c.action('top');assert.equal(doc.scrollTop,0);
   await c.action('middle');assert.equal(doc.scrollTop,4000);
   await c.action('end');assert.equal(doc.scrollTop,8000);
 });
 await test('Short pages clamp to zero; percentages never overshoot',async()=>{
   const {c,doc}=fixture();doc.scrollHeight=700;doc.clientHeight=1000;doc.scrollTop=0;
   await c.action('end');assert.equal(doc.scrollTop,0);assert.equal(c.metrics(doc).max,0);
   doc.scrollHeight=9000;await c.action('percent',250);assert.equal(doc.scrollTop,8000);
   await c.action('percent',-50);assert.equal(doc.scrollTop,0);
 });
 await test('Screen steps use 88% of viewport with boundary clamping',async()=>{
   const {c,doc}=fixture();await c.action('page-down');assert.equal(doc.scrollTop,880);
   await c.action('page-down');assert.equal(doc.scrollTop,1760);await c.action('page-up');assert.equal(doc.scrollTop,880);
   await c.action('page-up');assert.equal(doc.scrollTop,0);await c.action('page-up');assert.equal(doc.scrollTop,0);
   doc.scrollTop=7900;await c.action('page-down');assert.equal(doc.scrollTop,8000);
 });
 await test('Previous spot unwinds jump history without adding another entry',async()=>{
   const {c,doc}=fixture();await c.action('middle');await c.action('end');assert.equal(c.history.length,2);
   await c.action('previous-spot');assert.equal(doc.scrollTop,4000);assert.equal(c.history.length,1);assert.equal(c.manualRoot,null,'Automatic root selection must remain automatic');
   await c.action('previous-spot');assert.equal(doc.scrollTop,0);assert.equal(c.history.length,0);
 });
 await test('History is bounded, ignores duplicate positions, skips detached roots',async()=>{
   const {c,doc}=fixture();c.remember(doc);c.remember(doc);assert.equal(c.history.length,1);
   for(let i=1;i<45;i++){doc.scrollTop=i*10;c.remember(doc);}assert.equal(c.history.length,30);
   c.history.push({root:{isConnected:false},top:999});await c.action('previous-spot');assert.equal(doc.scrollTop,440);
 });
 await test('Nested panel receives scrolling without moving document',async()=>{
   const {c,doc,state}=fixture();const panel={scrollHeight:6000,clientHeight:600,scrollTop:0,scrollLeft:3,isConnected:true,scrollTo(opts){state.scrollCalls.push({...opts,page:false});this.scrollTop=opts.top;}};
   c.activeRoot=panel;await c.action('middle');assert.equal(panel.scrollTop,2700);assert.equal(doc.scrollTop,0);
   await c.action('end');assert.equal(panel.scrollTop,5400);await c.action('page-up');assert.equal(panel.scrollTop,4872);
   assert.equal(state.scrollCalls.at(-1).left,3);
 });
 await test('Reduced motion wins over smooth scrolling settings',async()=>{
   const {c,doc,state}=fixture();c.settings.smooth=true;state.reducedMotion=true;await c.action('end');assert.equal(state.scrollCalls.at(-1).behavior,'instant');
   state.reducedMotion=false;await c.action('top');assert.equal(state.scrollCalls.at(-1).behavior,'smooth');
   c.settings.smooth=false;await c.action('end');assert.equal(state.scrollCalls.at(-1).behavior,'instant');
 });
 await test('Typing blocks keyboard commands without blocking toolbar actions',async()=>{
   const {c,doc,state}=fixture();state.inputsActive=true;const failure=await c.action('end',undefined,'command');assert.ok(failure?.error);assert.equal(doc.scrollTop,0);
   await c.action('end',undefined,'toolbar');assert.equal(doc.scrollTop,8000);
 });
 await test('Site and global disabling reject navigation',async()=>{
   const {c,doc}=fixture();c.disabledSites=['example.test'];assert.ok((await c.action('end'))?.error);assert.equal(doc.scrollTop,0);
   c.disabledSites=[];c.settings.enabled=false;assert.ok((await c.action('end'))?.error);assert.equal(doc.scrollTop,0);
 });
 await test('Saved reading spot writes position, route, and metadata',async()=>{
   const {c,doc,storage}=fixture();doc.scrollTop=2000;assert.equal(await c.action('save-spot'),null);
   const value=storage['pnSpot:'+c.pageIdentity];assert.equal(value.top,2000);assert.equal(value.percent,25);assert.equal(value.max,8000);assert.equal(value.page,c.pageIdentity);assert.equal(value.rootIsPage,true);assert.ok(value.savedAt>0);
   await c.action('end');await c.action('restore-spot');assert.equal(doc.scrollTop,2000);
 });
 await test('Saved spot fallback scales after content height changes',async()=>{
   const {c,doc}=fixture();doc.scrollTop=2000;await c.action('save-spot');doc.scrollHeight=17000;await c.action('restore-spot');assert.equal(doc.scrollTop,4000);
 });
 await test('Stable heading anchor keeps place when content is inserted above',async()=>{
   const {c,doc}=fixture();const heading={el:{id:'chapter-3'},label:'Chapter 3',top:1900};c.headings=()=>[heading];doc.scrollTop=2000;await c.action('save-spot');assert.equal(c.savedSpot.anchor.delta,-100);
   heading.top=2500;doc.scrollHeight=9600;await c.action('restore-spot');assert.equal(doc.scrollTop,2600);
 });
 await test('Failed save returns an error instead of reporting success',async()=>{
   const {c}=fixture();c.chrome.storage.local.set=async()=>{throw new Error('Storage full');};const result=await c.action('save-spot');assert.ok(result?.error,'save action incorrectly reported success');assert.equal(c.savedSpot,null);
 });
 await test('Failed clear preserves saved spot and returns an error',async()=>{
   const {c,doc}=fixture();doc.scrollTop=2000;await c.action('save-spot');const prior=c.savedSpot;c.chrome.storage.local.remove=async()=>{throw new Error('Storage blocked');};const result=await c.action('clear-spot');assert.ok(result?.error,'clear action incorrectly reported success');assert.equal(c.savedSpot,prior);
 });
 await test('Save completion on an old route cannot overwrite the new route spot',async()=>{
   const {c}=fixture();const deferred=gate();let writtenKey=null;c.chrome.storage.local.set=values=>{writtenKey=Object.keys(values)[0];return deferred.promise;};
   const oldPage=c.pageIdentity;const saving=c.action('save-spot');await waitFor(()=>writtenKey!==null);
   c.pageIdentity='https://example.test/new';const current={version:1,page:c.pageIdentity,top:400,max:500,percent:80};c.savedSpot=current;deferred.resolve();await saving;
   assert.equal(writtenKey,'pnSpot:'+oldPage);assert.equal(c.savedSpot,current);
 });
 await test('Clear completion on an old route cannot erase the new route spot',async()=>{
   const {c}=fixture();const deferred=gate();let removedKey=null;c.savedSpot={version:1,page:c.pageIdentity,top:100,max:500,percent:20};c.chrome.storage.local.remove=key=>{removedKey=key;return deferred.promise;};
   const oldPage=c.pageIdentity;const clearing=c.action('clear-spot');await waitFor(()=>removedKey!==null);
   c.pageIdentity='https://example.test/new';const current={version:1,page:c.pageIdentity,top:400,max:500,percent:80};c.savedSpot=current;deferred.resolve();await clearing;
   assert.equal(removedKey,'pnSpot:'+oldPage);assert.equal(c.savedSpot,current);
 });
 await test('Page identity shares ordinary anchors but preserves SPA routes and query strings',async()=>{
   const {c}=fixture();c.location.href='https://example.test/a?q=1#chapter';assert.equal(c.identity(),'https://example.test/a?q=1');
   c.location.href='https://example.test/a?q=2#chapter';assert.equal(c.identity(),'https://example.test/a?q=2');
   c.location.href='https://example.test/a#/conversation/1';assert.equal(c.identity(),'https://example.test/a#/conversation/1');
   c.location.href='https://example.test/a#!/conversation/2';assert.equal(c.identity(),'https://example.test/a#!/conversation/2');
 });
 await test('A route change clears previous history, root overrides, and heading filter',async()=>{
   const {c,doc,ui}=fixture();c.manualRoot=doc;c.recentRoot=doc;c.history.push({root:doc,top:42});c.savedSpot={page:c.pageIdentity};c.temporarilyHidden=true;c.forcedVisible=true;c.lastHeading={};ui.value='old chapter';let loads=0;c.loadSpot=async()=>{loads++;};
   vm.runInContext("'use strict';\n"+sourceFunction('checkRoute'),c);c.location.href='https://example.test/another';await c.checkRoute();
   assert.equal(c.pageIdentity,c.location.href);assert.equal(c.history.length,0);assert.equal(c.savedSpot,null);assert.equal(c.manualRoot,null);assert.equal(c.recentRoot,null);assert.equal(c.temporarilyHidden,false);assert.equal(c.forcedVisible,false);assert.equal(ui.value,'');assert.equal(loads,1);
 });
 await test('Stored spots cannot cross page identities or contain non-finite coordinates',async()=>{
   const {c}=fixture();assert.equal(c.validSpot({version:1,page:'https://other.test',top:1,max:10}),null);
   assert.equal(c.validSpot({version:1,page:c.pageIdentity,top:Infinity,max:10}),null);
   const value={version:1,page:c.pageIdentity,top:1,max:10};assert.equal(c.validSpot(value),value);
 });
 await test('Quirks mode uses viewport height rather than document content height',async()=>{
   const {c,doc}=fixture();c.document.compatMode='BackCompat';c.document.documentElement.clientHeight=9000;c.innerHeight=1000;
   assert.equal(c.metrics(doc).view,1000);assert.equal(c.metrics(doc).max,8000);
   await c.action('middle');assert.equal(doc.scrollTop,4000);await c.action('end');assert.equal(doc.scrollTop,8000);
 });
 await test('Heading sequence advances when multiple final headings share the clamped bottom',async()=>{
   const {c,doc,state}=fixture();doc.scrollHeight=2000;
   const list=[{el:{id:'a',isConnected:true},label:'A',top:900},{el:{id:'b',isConnected:true},label:'B',top:1600},{el:{id:'c',isConnected:true},label:'C',top:1750}];
   c.headings=()=>{assert.equal(c.headingsDirty,true,'Explicit heading navigation must refresh the list');return list;};
   vm.runInContext("'use strict';\n"+sourceFunction('jumpHeading')+'\n'+sourceFunction('navigateHeading'),c);
   await c.action('next-heading');assert.equal(c.lastHeading,list[0].el);assert.equal(doc.scrollTop,900);
   await c.action('next-heading');assert.equal(c.lastHeading,list[1].el);assert.equal(doc.scrollTop,1000);
   await c.action('next-heading');assert.equal(c.lastHeading,list[2].el);assert.equal(doc.scrollTop,1000);
   await c.action('next-heading');assert.equal(c.lastHeading,list[2].el);assert.match(state.messages.at(-1),/No more headings below/);
   await c.action('previous-heading');assert.equal(c.lastHeading,list[1].el);assert.equal(doc.scrollTop,1000);
   await c.action('previous-heading');assert.equal(c.lastHeading,list[0].el);assert.equal(doc.scrollTop,900);
 });
 await test('Previous position preserves an explicitly chosen scrolling area',async()=>{
   const {c,doc,state}=fixture();const panel={scrollHeight:6000,clientHeight:600,scrollTop:0,scrollLeft:0,isConnected:true,scrollTo(opts){this.scrollTop=opts.top;}};
   c.manualRoot=panel;c.activeRoot=panel;await c.action('middle');await c.action('end');await c.action('previous-spot');
   assert.equal(c.manualRoot,panel);assert.equal(panel.scrollTop,2700);assert.equal(doc.scrollTop,0);
 });
 await test('Unknown actions return a useful error',async()=>{const {c}=fixture();assert.ok((await c.action('not-an-action'))?.error);});
 const result={kind:'deterministic Node VM logic tests; no real browser/DOM',testedSource:'content.js',passed:report.filter(r=>r.passed).length,failed:report.filter(r=>!r.passed).length,tests:report};
 fs.writeFileSync(path.join(__dirname,'core-contract-results.json'),JSON.stringify(result,null,2)+'\n');
 console.log(`\n${result.passed} passed, ${result.failed} failed. Browser integration not executed.`);process.exitCode=result.failed?1:0;
})().catch(error=>{console.error(error);process.exitCode=1;});
